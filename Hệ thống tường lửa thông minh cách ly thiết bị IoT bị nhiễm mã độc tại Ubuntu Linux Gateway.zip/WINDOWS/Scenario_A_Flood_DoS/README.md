# Scenario A – Flood/DoS

## Mục đích
Tạo lưu lượng UDP bằng iperf3 từ máy Windows đến Ubuntu Gateway để kiểm tra khả năng phát hiện bất thường theo B/s, cách ly thiết bị và phục hồi.

## Thành phần
- Windows: iperf3 client.
- Ubuntu Gateway: iperf3 server, detector `flood_realtime_mitigation.py`, recovery watcher và resource monitor.
- Ngưỡng theo cấu hình thực nghiệm đã cung cấp: `Z_THRESHOLD = 2.0`.
- Thời lượng gửi theo lệnh mẫu: 120 giây, tốc độ mục tiêu 1 Mbit/s.

## Yêu cầu
- Windows và Ubuntu kết nối đúng mạng thí nghiệm.
- Kiểm tra IP Gateway trước khi chạy; hướng dẫn đang dùng `10.42.0.1`.
- Trên Ubuntu cần có `iperf3`, Python 3 và các thành phần hệ thống của Gateway.
- Trên Windows cần cài **iperf3 cho Windows** (không cài bằng pip).
- Sau khi cài, mở PowerShell/CMD mới và kiểm tra:
  ```powershell
  iperf3 --version
  ```
- Nếu Windows báo không nhận diện lệnh `iperf3`, hãy thêm thư mục chứa `iperf3.exe` vào biến môi trường `PATH`, sau đó mở lại PowerShell.
- Trạng thái ban đầu phải là `NORMAL`, không còn luật DROP cũ của MAC thiết bị.

## Cài đặt iperf3 trên Windows

1. Tải bản phát hành iperf3 dành cho Windows từ trang phát hành chính thức hoặc nguồn phân phối đáng tin cậy.
2. Giải nén và đặt `iperf3.exe` trong một thư mục cố định, ví dụ `C:\\iperf3\\`.
3. Thêm thư mục chứa `iperf3.exe` vào biến môi trường `Path` của Windows.
4. Đóng và mở lại PowerShell, chạy:
   ```powershell
   iperf3 --version
   ```
5. Khi lệnh hiển thị phiên bản iperf3, Windows đã sẵn sàng chạy lệnh trong `commands.txt`.

`iperf3` là công cụ dòng lệnh độc lập, không phải thư viện Python. Vì vậy, không thêm `iperf3` vào `requirements.txt` và không dùng `pip install iperf3` để cài công cụ này.

## Trình tự thực hiện
1. Ubuntu: kiểm tra thiết bị Wi-Fi bằng `iw dev ap0 station dump`.
2. Ubuntu: kiểm tra `sudo iptables -L FORWARD -n -v --line-numbers`.
3. Windows: kiểm tra kết nối trước thử nghiệm bằng `ping 8.8.8.8`.
4. Ubuntu: chạy resource monitor.
5. Ubuntu: chạy `iperf3 -s`.
6. Ubuntu: chạy detector Flood/DoS với ngưỡng Z=2.0.
7. Chờ ít nhất 3 cửa sổ NORMAL theo cấu hình detector.
8. Ghi marker `ATTACK_START` trên Ubuntu, sau đó chạy lệnh iperf3 client trên Windows.
9. Kiểm tra log detector và luật DROP trong chain FORWARD.
10. Sau khi BLOCKED, kiểm tra ping Internet từ Windows.
11. Thực hiện disconnect/reconnect Wi-Fi theo quy trình recovery của hệ thống.
12. Xác nhận luật DROP biến mất, state trở về NORMAL và ping hoạt động lại.
13. Dừng resource monitor; lưu CSV và tính CPU/RAM AVG/MAX.

## Lưu ý
- Lệnh iperf3 dưới đây tạo UDP traffic đến Gateway. Nó không phải lưu lượng TCP.
- `ATTACK_START` được ghi thủ công, nên độ trễ đo được có sai số thao tác giữa hai máy.
- Chỉ kết luận cách ly thành công khi có bằng chứng state/firewall và kiểm tra kết nối phù hợp.
- Không chạy thử nghiệm trên mạng hoặc thiết bị không thuộc quyền kiểm soát của bạn.
