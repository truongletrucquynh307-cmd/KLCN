import socket
import os
import time

TARGET_IP = "10.42.0.1"
TARGET_PORT = 9999

RATE_BPS = 1024 * 1024
CHUNK_SIZE = 64 * 1024
DURATION = 120

print("=" * 60)
print("SCENARIO C - CONTINUOUS GARBAGE DATA")
print("=" * 60)
print("Target   :", f"{TARGET_IP}:{TARGET_PORT}")
print("Rate     :", RATE_BPS, "bytes/s")
print("Duration :", DURATION, "seconds")
print("=" * 60)

sock = socket.socket(
    socket.AF_INET,
    socket.SOCK_STREAM
)

sock.connect(
    (TARGET_IP, TARGET_PORT)
)

payload = os.urandom(CHUNK_SIZE)

start = time.time()
total = 0

try:

    while time.time() - start < DURATION:

        second_start = time.time()
        sent_this_second = 0

        while sent_this_second < RATE_BPS:

            remaining = (
                RATE_BPS - sent_this_second
            )

            data = payload[
                :min(CHUNK_SIZE, remaining)
            ]

            sock.sendall(data)

            sent = len(data)

            sent_this_second += sent
            total += sent

        elapsed = time.time() - second_start

        if elapsed < 1.0:
            time.sleep(1.0 - elapsed)

        print(
            f"Sent: {total / 1024 / 1024:.2f} MiB",
            end="\r"
        )

except KeyboardInterrupt:
    print("\nStopped.")

finally:

    sock.close()

print()
print(
    f"Total sent: "
    f"{total / 1024 / 1024:.2f} MiB"
)