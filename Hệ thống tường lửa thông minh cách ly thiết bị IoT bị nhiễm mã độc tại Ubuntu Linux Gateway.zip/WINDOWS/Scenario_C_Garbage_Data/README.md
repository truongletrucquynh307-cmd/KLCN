# Scenario C – Garbage Data

## Mục đích

Tạo lưu lượng TCP chứa dữ liệu rác với dung lượng lớn từ máy Windows đến Ubuntu Gateway thông qua port 9999, kết hợp lưu lượng telemetry bình thường để kiểm tra khả năng phát hiện dị thường theo TCP payload B/s, tự động cách ly thiết bị và phục hồi kết nối.

## Thành phần

- **Windows:**
  - `normal_telemetry_sender.py`: gửi dữ liệu IoT bình thường đến Gateway.
  - `garbage_sender.py`: gửi dữ liệu ngẫu nhiên liên tục với dung lượng lớn.
- **Ubuntu Gateway:**
  - Detector: `garbage_realtime_mitigation.py` (cần xác nhận đúng tên file trong phiên bản source sử dụng).
  - Thành phần đo lưu lượng: `garbage_measure.py` (nếu được detector sử dụng).
  - Recovery watcher.
  - Resource monitor: `monitor_gateway_resources_garbage.py` (nếu sử dụng riêng cho kịch bản C).
- **Địa chỉ đích:** `10.42.0.1:9999`.
- **Giao thức:** TCP.
- **Garbage sender:** tốc độ mục tiêu 1 MiB/s, thời lượng 120 giây.
- **Normal telemetry sender:** gửi 1 bản tin/giây, thời lượng 660 giây.
- **Ngưỡng Z-score:** sử dụng theo cấu hình Baseline và detector riêng của kịch bản C; không mặc định sử dụng ngưỡng Z=2.0 của kịch bản A.

## Yêu cầu

- Windows và Ubuntu kết nối đúng mạng thí nghiệm.
- Kiểm tra IP Gateway trước khi chạy; hướng dẫn đang sử dụng `10.42.0.1`.
- Ubuntu cần có Python 3, Scapy (nếu detector sử dụng), các thành phần hệ thống của Gateway và quyền quản trị để điều khiển `iptables`.
- Windows cần cài Python 3.
- Không cần cài thêm thư viện Python bên ngoài cho hai sender hiện tại vì chỉ sử dụng thư viện chuẩn.
- Trên Ubuntu phải có dịch vụ hoặc chương trình nhận TCP tại port `9999`, phù hợp với cơ chế đo TCP payload của detector.
- Trạng thái ban đầu phải là `NORMAL`, không còn luật DROP cũ của MAC thiết bị.
- Đảm bảo MAC thiết bị thí nghiệm được giữ cố định: `ac:36:1b:ef:41:8e`.

## Trình tự thực hiện

1. Ubuntu: kiểm tra thiết bị Wi-Fi bằng `iw dev ap0 station dump`.
2. Ubuntu: kiểm tra Firewall bằng `sudo iptables -L FORWARD -n -v --line-numbers`.
3. Windows: kiểm tra kết nối trước thử nghiệm bằng `ping 8.8.8.8`.
4. Windows: kiểm tra khả năng kết nối TCP đến Gateway port 9999 bằng:
   `Test-NetConnection 10.42.0.1 -Port 9999`.
5. Ubuntu: chạy resource monitor và lưu kết quả vào file CSV riêng của kịch bản C.
6. Ubuntu: khởi động Recovery watcher theo cấu hình hệ thống.
7. Ubuntu: chạy detector Garbage Data với Baseline và ngưỡng Z-score tương ứng.
8. Chờ ít nhất 3 cửa sổ NORMAL theo cấu hình detector để xác nhận hệ thống chưa phát hiện bất thường trước khi gửi dữ liệu rác.
9. Ghi marker `ATTACK_START` trên Ubuntu:
   `date '+ATTACK_START,%Y-%m-%d %H:%M:%S.%3N'`.
10. Trên Windows, chạy `normal_telemetry_sender.py` ở giai đoạn kiểm tra lưu lượng bình thường nếu cần thu thập dữ liệu đối chứng.
11. Dừng sender NORMAL khi chuyển sang giai đoạn tạo Garbage Data, nếu quy trình thực nghiệm yêu cầu hai giai đoạn tách biệt.
12. Trên Windows, chạy `garbage_sender.py` để gửi dữ liệu ngẫu nhiên liên tục đến Gateway port 9999.
13. Theo dõi log detector để ghi nhận cửa sổ bất thường, Z-score, thời điểm phát hiện và thời điểm BLOCKED.
14. Kiểm tra luật DROP trong chain FORWARD bằng `sudo iptables -L FORWARD -n -v --line-numbers`.
15. Sau khi BLOCKED, kiểm tra kết nối Internet từ Windows bằng `ping 8.8.8.8`.
16. Sau khoảng 20–30 giây ở trạng thái BLOCKED, thực hiện disconnect/reconnect Wi-Fi theo quy trình Recovery của hệ thống.
17. Xác nhận Recovery watcher ghi nhận DISCONNECTED, RECONNECTED và UNBLOCKED; kiểm tra luật DROP đã biến mất và state trở về NORMAL.
18. Windows: kiểm tra lại kết nối bằng `ping 8.8.8.8` và xác nhận thiết bị có thể truy cập Internet trở lại.
19. Sau Recovery, tiếp tục duy trì giám sát khoảng 20 giây ở trạng thái NORMAL.
20. Dừng resource monitor; lưu CSV và tính CPU/RAM AVG/MAX.

## Lưu ý

- `normal_telemetry_sender.py` tạo các bản tin JSON mô phỏng dữ liệu IoT bình thường; `garbage_sender.py` gửi dữ liệu ngẫu nhiên bằng TCP, không phải UDP.
- Garbage sender sử dụng `os.urandom()` để tạo payload ngẫu nhiên, với tốc độ mục tiêu 1 MiB/s trong 120 giây.
- Detector cần đo đúng TCP payload đến port 9999; không đồng nhất TCP payload B/s với tổng lưu lượng mạng B/s.
- Không sử dụng `flood_realtime_mitigation.py` của kịch bản A thay cho detector Garbage Data.
- Không tự áp dụng ngưỡng Z=2.0 của kịch bản A cho kịch bản C. Cần sử dụng Baseline, μ, σ và ngưỡng đã xác lập riêng cho Garbage Data.
- Trước khi chạy, cần xác nhận chương trình nhận TCP port 9999 đang hoạt động và tương thích với cách detector thu thập dữ liệu.
- `ATTACK_START` được ghi thủ công, nên độ trễ đo được có sai số thao tác giữa hai máy.
- Chỉ kết luận cách ly thành công khi có bằng chứng state/firewall và kiểm tra kết nối phù hợp.
- Recovery thành công không đồng nghĩa với việc mã độc đã được loại bỏ khỏi thiết bị.
- Không chạy thử nghiệm trên mạng hoặc thiết bị không thuộc quyền kiểm soát của bạn.