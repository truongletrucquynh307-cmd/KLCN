#!/usr/bin/env python3

import socket
import time
import random
import json
from datetime import datetime

# ==========================================
# SCENARIO C - NORMAL IOT TELEMETRY SENDER
# ==========================================

GATEWAY_IP = "10.42.0.1"
GATEWAY_PORT = 9999

# Chạy 660 giây = 11 phút
# Đủ để Ubuntu thu 60 windows x 10 giây
DURATION = 660

# Gửi 1 bản tin mỗi giây
INTERVAL = 1.0

# Mô phỏng dữ liệu IoT bình thường
MIN_PADDING = 50
MAX_PADDING = 250

CONNECT_TIMEOUT = 5

random.seed()

def now():
    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S.%f"
    )[:-3]


def create_telemetry(sequence):

    temperature = round(
        random.uniform(24.0, 32.0), 2
    )

    humidity = round(
        random.uniform(45.0, 75.0), 2
    )

    padding_size = random.randint(
        MIN_PADDING,
        MAX_PADDING
    )

    payload = {
        "device_id": "iot-windows-01",
        "timestamp": now(),
        "sequence": sequence,
        "temperature": temperature,
        "humidity": humidity,
        "status": "NORMAL",
        "padding": "X" * padding_size
    }

    return (
        json.dumps(payload) + "\n"
    ).encode("utf-8")


def main():

    print("=" * 65)
    print("SCENARIO C - NORMAL IOT TELEMETRY")
    print("=" * 65)

    print("Target   :", f"{GATEWAY_IP}:{GATEWAY_PORT}")
    print("Duration :", DURATION, "seconds")
    print("Interval :", INTERVAL, "second")
    print("Mode     : NORMAL")
    print("=" * 65)

    total_bytes = 0
    messages = 0

    start = time.monotonic()
    end_time = start + DURATION

    sock = None

    try:

        sock = socket.create_connection(
            (GATEWAY_IP, GATEWAY_PORT),
            timeout=CONNECT_TIMEOUT
        )

        sock.settimeout(10)

        print("CONNECTED:", now())

        while time.monotonic() < end_time:

            cycle_start = time.monotonic()

            data = create_telemetry(messages + 1)

            sock.sendall(data)

            total_bytes += len(data)
            messages += 1

            print(
                f"{now()} | "
                f"Message={messages} | "
                f"Bytes={len(data)} | "
                f"Total={total_bytes}"
            )

            remaining = (
                INTERVAL -
                (time.monotonic() - cycle_start)
            )

            if remaining > 0:
                time.sleep(remaining)

    except KeyboardInterrupt:
        print("\nStopped by user.")

    except (OSError, socket.timeout) as e:
        print("\nCONNECTION ERROR:", e)

    finally:

        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_WR)
            except OSError:
                pass

            try:
                sock.close()
            except OSError:
                pass

        elapsed = time.monotonic() - start

        print()
        print("=" * 65)
        print("NORMAL TELEMETRY FINISHED")
        print("=" * 65)
        print("Messages :", messages)
        print("Bytes    :", total_bytes)
        print(f"Elapsed  : {elapsed:.2f} seconds")
        print("End time :", now())


if __name__ == "__main__":
    main()