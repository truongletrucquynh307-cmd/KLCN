ĐÁNH GIÁ THAM KHẢO UNSW-LIFX

1. Cài Python 3.10 trở lên từ trang python.org. Khi cài đặt, chọn tùy chọn Add Python to PATH.
2. Giải nén đầy đủ thư mục UNSW_LIFX; không cần PCAP để chạy quy trình hiện tại.
3. Mở PowerShell tại thư mục này và cài thư viện:
   py -3 -m pip install -r requirements.txt
4. Chạy chương trình bằng cách nhấp đúp CHAY_TREN_WINDOWS.bat hoặc chạy:
   py -3 khao_sat_lifx.py
5. Mở thư mục KET_QUA_LIFX để xem kết quả:
   - 01_baseline_summary.csv: μ, σ và số lượng cửa sổ.
   - 02_normal_baseline_60pct.csv: các cửa sổ dùng để xây dựng baseline.
   - 03_normal_test_40pct.csv: các cửa sổ NORMAL dùng đánh giá FPR.
   - 04_attack_evaluation.csv: các cửa sổ ATTACK tham khảo.
   - 05_bang_DR_FPR_theo_nguong.csv: bảng TP, FN, FP, TN, DR và FPR.
   - 06_BAO_CAO_KET_QUA.txt: tóm tắt kết quả và giới hạn.

PHƯƠNG PHÁP VÀ GIỚI HẠN

- NORMAL: dùng 60% dữ liệu đầu để tính baseline, 40% còn lại để đánh giá FPR.
- ATTACK: chuỗi 121 cửa sổ có byte dương liên tục được xuất sau khi lọc một
  khoảng UDP attack theo annotation. Loại hai cửa sổ biên, còn 119 cửa sổ lõi.
- Chưa kiểm chứng đồng bộ thời gian tuyệt đối UTC ở cấp từng cửa sổ; vì vậy
  phần ATTACK là kết quả PROXY, không phải căn chỉnh thời gian đã xác thực.
- DR là tỷ lệ cửa sổ trong khoảng ATTACK có Z-score vượt ngưỡng; không đồng
  nghĩa với tỷ lệ phát hiện gói tin độc hại và không chứng minh khả năng phát
  hiện malware trên thiết bị Tapo L520E.
- Các cửa sổ 0 B/s được giữ trong NORMAL theo giả định capture liên tục.
