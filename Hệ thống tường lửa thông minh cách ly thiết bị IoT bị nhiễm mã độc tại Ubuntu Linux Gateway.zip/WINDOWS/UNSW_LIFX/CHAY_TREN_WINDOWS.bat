@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 -m pip install --upgrade pandas numpy matplotlib
if errorlevel 1 (
  echo Khong cai duoc thu vien. Kiem tra Python da cai va chon Add to PATH.
  pause
  exit /b 1
)
py -3 khao_sat_lifx.py
if errorlevel 1 (
  echo Da xay ra loi. Hay chup man hinh va gui de kiem tra.
  pause
  exit /b 1
)
echo.
echo THANH CONG: Mo thu muc KET_QUA_LIFX de xem bang CSV va hinh PNG.
pause
