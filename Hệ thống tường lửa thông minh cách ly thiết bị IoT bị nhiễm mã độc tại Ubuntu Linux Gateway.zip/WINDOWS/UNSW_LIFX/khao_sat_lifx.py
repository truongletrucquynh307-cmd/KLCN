# -*- coding: utf-8 -*-
"""Khao sat Z-score LIFX UNSW tren Windows; xuat bang/anh cho muc 4.3.2-4.3.4.
   Python 3.10+, pandas, numpy, matplotlib. Khong can PCAP hay Wireshark.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, csv, zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MAC = 'd0:73:d5:01:83:08'
ANNOTATION_FILE = 'annotations/d073d5018308.csv'
ATTACK_KIND = 'UdpDevice1L2D'
WINDOW_SEC = 5
THRESHOLDS = [2.0, 2.5, 3.0, 3.5, 4.0]


def read_iograph(path):
    df = pd.read_csv(path, encoding='utf-8-sig')
    needed = ['Interval start', 'Filtered packets']
    if not set(needed).issubset(df.columns):
        raise ValueError(f'{path.name}: thieu cot {needed}; dang co {list(df.columns)}')
    df = df[needed].copy()
    df.columns = ['start_s', 'bytes_5s']
    df = df.apply(pd.to_numeric, errors='raise')
    if df.isna().any().any() or (df['bytes_5s'] < 0).any():
        raise ValueError(f'{path.name}: du lieu am hoac thieu')
    if not np.allclose(np.diff(df.start_s), WINDOW_SEC):
        raise ValueError(f'{path.name}: interval khong deu {WINDOW_SEC}s')
    df['bps'] = df['bytes_5s'] / WINDOW_SEC
    return df


def annotation_event(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        lines = z.read(ANNOTATION_FILE).decode('utf-8-sig').splitlines()
    records = list(csv.reader(lines))
    events = [{'start_epoch': int(r[0]), 'end_epoch': int(r[1]),
               'features': r[2], 'attack': r[3]} for r in records if len(r) >= 4]
    matches = [r for r in events if r['attack'] == ATTACK_KIND]
    if len(matches) != 1:
        raise ValueError(f'Can 1 nhan {ATTACK_KIND}, thay {len(matches)}')
    return matches[0], events


def main():
    p = argparse.ArgumentParser(description='Khao sat Z-score LIFX cho Windows')
    p.add_argument('--folder', type=Path, default=Path(__file__).resolve().parent,
                   help='Thu muc chua CSV va annotations.zip')
    p.add_argument('--attack-origin-epoch', type=float, default=None,
                   help='Unix timestamp UTC tai goc Interval start=0 cua CSV ATTACK. '
                        'Neu khong biet, script dung 119 cua so loi voi nhan PROXY.')
    args = p.parse_args()
    folder = args.folder.resolve()
    out = folder / 'KET_QUA_LIFX'
    out.mkdir(exist_ok=True)
    normal = read_iograph(folder / 'LIFX_NORMAL_5s.csv')
    attack = read_iograph(folder / 'LIFX_ATTACK_5s.csv')
    event, events = annotation_event(folder / 'annotations.zip')
    if len(normal) < 10:
        raise ValueError('Khong du NORMAL de chia baseline/kiem thu')

    cut = int(len(normal) * 0.6)
    train = normal.iloc[:cut].copy()
    test = normal.iloc[cut:].copy()
    mu = float(train.bps.mean())
    sigma = float(train.bps.std(ddof=0))  # std tong the, nhat quan mu/sigma
    if sigma <= 0:
        raise ValueError('sigma = 0, khong the tinh Z-score theo cong thuc thong thuong')
    train['z'] = (train.bps - mu) / sigma
    test['z'] = (test.bps - mu) / sigma

    if args.attack_origin_epoch is not None:
        # Chon moi cua so nam HOAN TOAN trong [event_start,event_end].
        start_epoch = args.attack_origin_epoch + attack.start_s
        end_epoch = start_epoch + WINDOW_SEC
        mask = ((start_epoch >= event['start_epoch']) &
                (end_epoch <= event['end_epoch']))
        atk = attack.loc[mask].copy()
        method = 'EXACT: xac nhan Unix epoch tai start_s=0, chi lay cua so nam tron trong nhan ATTACK'
    else:
        # Wireshark voi filter thoi gian xuat hang nghin zero TRUOC event.
        # 121 cua so co byte lien tuc; loai 2 bin bien de tao 119 bin loi.
        active = attack.loc[attack.bytes_5s > 0].copy()
        if len(active) < 3 or not np.allclose(np.diff(active.start_s), WINDOW_SEC):
            raise ValueError('ATTACK khong co day bin duong lien tuc; '
                             'can cung cap --attack-origin-epoch va kiem tra file')
        if active.start_s.max() - active.start_s.min() > event['end_epoch'] - event['start_epoch'] + WINDOW_SEC:
            raise ValueError('Thoi gian active vuot qua khoang annotation, can kiem tra lai')
        atk = active.iloc[1:-1].copy()
        method = ('PROXY: 119 bin loi tu chuoi duong lien tuc sau khi loai 2 bin bien; '
                  'CHUA dong bo thoi gian tuyet doi voi annotation; khong coi la DR chinh thuc')
    if atk.empty:
        raise ValueError('Khong co cua so ATTACK trong nhan, kiem tra attack-origin-epoch')
    atk['z'] = (atk.bps - mu) / sigma

    pd.DataFrame([{'source': 'UNSW IoT Attack Traces', 'device': 'LIFX Smart Bulb',
                   'mac': MAC, 'window_s': WINDOW_SEC, 'n_normal_total': len(normal),
                   'n_baseline_train': len(train), 'n_normal_test': len(test),
                   'n_attack_eval': len(atk), 'mean_bps': mu,
                   'sigma_population_bps': sigma, 'attack_label': ATTACK_KIND,
                   'attack_start_utc': datetime.fromtimestamp(event['start_epoch'],timezone.utc).isoformat(),
                   'attack_end_utc': datetime.fromtimestamp(event['end_epoch'],timezone.utc).isoformat(),
                   'attack_selection': method}]).to_csv(out/'01_baseline_summary.csv',index=False,encoding='utf-8-sig')

    train.to_csv(out/'02_normal_baseline_60pct.csv',index=False,encoding='utf-8-sig')
    test.to_csv(out/'03_normal_test_40pct.csv',index=False,encoding='utf-8-sig')
    atk.to_csv(out/'04_attack_evaluation.csv',index=False,encoding='utf-8-sig')

    results = []
    for k in THRESHOLDS:
        fp = int((test.z > k).sum())
        tn = len(test)-fp
        tp = int((atk.z > k).sum())
        fn = len(atk)-tp
        results.append({'threshold_Z_gt': k, 'threshold_Bps': mu+k*sigma,
                        'TP_attack_window': tp, 'FN_attack_window': fn,
                        'FP_normal_window': fp, 'TN_normal_window': tn,
                        'attack_windows': len(atk), 'normal_test_windows': len(test),
                        'Detection_Rate_percent': 100*tp/(tp+fn),
                        'FPR_percent':100*fp/(fp+tn),
                        'Miss_Rate_percent':100*fn/(tp+fn), 'label_method':method})
    summary = pd.DataFrame(results)
    summary.to_csv(out/'05_bang_DR_FPR_theo_nguong.csv',index=False,encoding='utf-8-sig')

    plt.figure(figsize=(10,4.8))
    plt.plot(train.start_s/3600,train.bps,linewidth=.45)
    plt.axhline(mu,color='black',linestyle='--',label=f'Baseline mean = {mu:.2f} B/s')
    plt.title('LIFX NORMAL: du lieu dung xay dung baseline (60%)')
    plt.xlabel('Thoi gian tu dau PCAP (gio)')
    plt.ylabel('Luu luong (B/s)')
    plt.legend();plt.tight_layout()
    plt.savefig(out/'Hinh_4_3_2_Baseline_NORMAL.png',dpi=180);plt.close()

    plt.figure(figsize=(9,5))
    plt.plot(summary.threshold_Z_gt,summary.Detection_Rate_percent,'o-',label='Detection Rate (%)')
    plt.plot(summary.threshold_Z_gt,summary.FPR_percent,'s-',label='FPR (%)')
    plt.xticks(THRESHOLDS);plt.xlabel('Nguong Z-Score (Z > k)')
    plt.ylabel('Ty le (%)');plt.title('Khao sat nguong Z-Score - LIFX (UNSW)')
    plt.grid(alpha=.3);plt.legend();plt.tight_layout()
    plt.savefig(out/'Hinh_4_3_3_DR_FPR_theo_nguong.png',dpi=180);plt.close()

    plt.figure(figsize=(10,4.7))
    plt.plot(atk.start_s,atk.bps,marker='.',linewidth=1,label='LIFX B/s (ATTACK window)')
    plt.axhline(mu+3*sigma,color='black',linestyle='--',label='Z > 3 threshold')
    plt.xlabel('Interval start (s, tu dau capture)');plt.ylabel('B/s')
    plt.title('Cua so luu luong LIFX trong khoang UDP attack (tham khao)')
    plt.grid(alpha=.3);plt.legend();plt.tight_layout()
    plt.savefig(out/'Hinh_4_3_4_ATTACK_Bps_vs_Z3.png',dpi=180);plt.close()

    z3=summary.loc[summary.threshold_Z_gt==3.0].iloc[0]
    report = f'''KET QUA DANH GIA THAM KHAO - LIFX (UNSW)\n\nMuc 4.3.2 - Xay dung Baseline:\n  Tong NORMAL: {len(normal)} cua so; train 60% = {len(train)}; test 40% = {len(test)}.\n  Window = {WINDOW_SEC}s; B/s = byte / 5s.\n  mu = {mu:.6f} B/s; sigma (ddof=0) = {sigma:.6f} B/s.\n\nMuc 4.3.3 - Khao sat nguong:\n{summary.to_string(index=False,formatters={'Detection_Rate_percent':lambda v:f'{v:.2f}', 'FPR_percent':lambda v:f'{v:.2f}'})}\n\nMuc 4.3.4 - DR va FPR (Z>3):\n  TP={int(z3.TP_attack_window)}, FN={int(z3.FN_attack_window)}, FP={int(z3.FP_normal_window)}, TN={int(z3.TN_normal_window)}\n  DR={z3.Detection_Rate_percent:.2f}%; FPR={z3.FPR_percent:.2f}%.\n  Annotation: {ATTACK_KIND}, {datetime.fromtimestamp(event['start_epoch'],timezone.utc)} den {datetime.fromtimestamp(event['end_epoch'],timezone.utc)}.\n  Cach lay attack: {method}\n\nCANH BAO KHOA HOC:\n  DR o day la ty le cua so trong khoang gan nhan attack vuot nguong,\n  KHONG PHAI ty le goi tin doc hai duoc phat hien hoac phat hien botnet.\n  MAC filter = eth.addr: tinh ca gui/nhan, khong the suy ra LIFX la nguon tan cong.\n  0 byte trong NORMAL duoc coi la hop le, can xac minh khoang capture lien tuc.\n  Neu can nhan EXACT, lay UTC epoch cho moc Interval start=0 cua capture ATTACK\n  tu Wireshark Frame > Arrival Time va chay --attack-origin-epoch.\n'''
    (out/'06_BAO_CAO_KET_QUA.txt').write_text(report,encoding='utf-8-sig')
    print(report)
    print('Da xuat:',out)


if __name__=='__main__':
    main()
