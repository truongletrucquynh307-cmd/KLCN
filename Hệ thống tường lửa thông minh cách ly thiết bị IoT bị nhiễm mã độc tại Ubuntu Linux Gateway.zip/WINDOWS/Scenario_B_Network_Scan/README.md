# Scenario B – Network Scan

## Mục đích
Dùng Nmap trên Windows tạo hoạt động TCP connect scan đến Ubuntu Gateway, sau đó đánh giá detector dựa trên số lượng TCP destination ports duy nhất trong mỗi cửa sổ 10 giây.

## Cấu hình thực nghiệm đã cung cấp
- Detector: `scan_realtime_mitigation.py`.
- Ngưỡng: `Z_THRESHOLD = 4.0`.
- Feature: `unique_dst_ports / 10 s`.
- Baseline: μ = 0.2500, σ = 0.4739.
- Địa chỉ đích trong lệnh mẫu: `10.42.0.1`.
- Dải cổng quét: TCP 1–1000.
- Windows dùng Nmap; kịch bản này không cần `iperf3 -s`.

## Yêu cầu
- Cài Nmap trên Windows và bảo đảm lệnh `nmap` chạy được trong PowerShell.
- Ubuntu có detector, `recovery_watcher.py`, resource monitor riêng cho Scan và các thành phần Gateway.
- Trước lượt đo: state phải là `NORMAL`, không còn DROP cũ của MAC thiết bị.
- Xác nhận đúng IP/MAC và đúng ngưỡng trong file detector trước khi chạy.

## Trình tự thực hiện
1. Ubuntu: kiểm tra state, station Wi-Fi và firewall.
2. Windows: ping Internet trước thử nghiệm.
3. Ubuntu: chạy resource monitor riêng cho kịch bản B.
4. Ubuntu: chạy `recovery_watcher.py`.
5. Ubuntu: kiểm tra `Z_THRESHOLD = 4.0`, sau đó chạy `scan_realtime_mitigation.py`.
6. Chờ ít nhất 3 cửa sổ NORMAL; không chạy Nmap trước thời điểm này.
7. Ghi marker `ATTACK_START` trên Ubuntu, sau đó chạy Nmap từ Windows.
8. Kiểm tra log ANOMALY/DETECTED/BLOCKED và luật DROP.
9. Kiểm tra ping Internet từ Windows sau BLOCK.
10. Disconnect/reconnect Wi-Fi theo quy trình recovery.
11. Xác nhận UNBLOCKED, state NORMAL, DROP biến mất và detector tiếp tục thu thập.
12. Dừng monitor sau giai đoạn NORMAL bổ sung; tính CPU/RAM AVG/MAX.

## Lưu ý
- Nmap quét địa chỉ Gateway `10.42.0.1`; luật DROP ở chain FORWARD có thể chỉ chặn traffic được chuyển tiếp, không đồng nghĩa chặn truy cập trực tiếp đến chính Gateway.
- Dùng ping `8.8.8.8` để kiểm tra đường truyền Internet được chuyển tiếp từ Windows, không dùng kết quả Nmap scan đến Gateway làm bằng chứng duy nhất cho việc cách ly.
- Marker được ghi thủ công trên Ubuntu, còn lệnh Nmap được khởi chạy trên Windows; độ trễ có sai số thao tác.
- Chỉ chạy scan trong mạng thí nghiệm bạn được phép kiểm thử.
