# CODE – Mã nguồn và dữ liệu thực nghiệm đề tài IoT

Thư mục `CODE` chứa mã nguồn, cấu hình Gateway, chương trình tạo lưu lượng từ Windows, bộ phân tích dữ liệu UNSW–LIFX và các kết quả thực nghiệm liên quan đến đề tài.

Dự án được chia theo **môi trường thực thi**:

- `UBUNTU/`: mã nguồn chạy trên Ubuntu Gateway, cấu hình mạng, hệ thống giám sát/phát hiện bất thường, cách ly và phục hồi.
- `WINDOWS/`: công cụ/lệnh tạo lưu lượng từ máy Windows và bộ phân tích dữ liệu UNSW–LIFX.
- `WINDOWS/UNSW_LIFX/`: bộ phân tích tham khảo độc lập, giữ riêng trong Windows vì script và dữ liệu của bộ này được chạy/xử lý trên Windows.

> **Lưu ý về phạm vi:** các kịch bản A, B, C là thử nghiệm giữa máy Windows và Ubuntu Gateway. Windows tạo lưu lượng; Ubuntu chạy detector, monitor và recovery. Không nhầm vị trí thực thi của một script với thư mục đang chứa bản sao của nó. Các script Gateway chính thức được chia theo từng kịch bản trong `UBUNTU/iot-project/scripts/Scenario_A_Flood_DoS/`, `Scenario_B_Network_Scan/` và `Scenario_C_Garbage_Data/`; hướng dẫn chung nằm trong `UBUNTU/iot-project/README.md`.

---

## 1. Cấu trúc thư mục

```text
CODE/
│
├── README.md
│
├── UBUNTU/
│   ├── requirements.txt
│   ├── GATEWAY/                         # Cấu hình Wi-Fi Access Point/Hotspot
│   ├── TAPO/                            # Gateway Tapo L520E, Dashboard, SQLite, Evaluation
│   └── iot-project/
│       ├── README.md                    # Hướng dẫn ba kịch bản phía Gateway
│       ├── scripts/
│       │   ├── Scenario_A_Flood_DoS/
│       │   ├── Scenario_B_Network_Scan/
│       │   └── Scenario_C_Garbage_Data/
│       ├── logs/                        # CSV kết quả của ba kịch bản
│       └── state/                       # Trạng thái thiết bị dùng chung
│
└── WINDOWS/
    ├── requirements.txt                 # Thư viện Python chung phía Windows (hiện không có)
    ├── Scenario_A_Flood_DoS/             # Hướng dẫn/lệnh chạy từ Windows
    ├── Scenario_B_Network_Scan/          # Hướng dẫn/lệnh chạy từ Windows
    ├── Scenario_C_Garbage_Data/          # Sender chạy trên Windows
    └── UNSW_LIFX/
        ├── requirements.txt              # Thư viện riêng của bộ phân tích LIFX
        ├── CHAY_TREN_WINDOWS.bat
        ├── khao_sat_lifx.py
        ├── annotations.zip
        ├── LIFX_ATTACK_5s.csv
        ├── LIFX_NORMAL_5s.csv
        └── KET_QUA_LIFX/                 # Kết quả CSV/báo cáo/hình sau khi chạy
```

### Vai trò các thành phần

| Thư mục | Vai trò |
|---|---|
| `UBUNTU/GATEWAY/` | Cấu hình và script hỗ trợ thiết lập Wi-Fi Hotspot trên Gateway |
| `UBUNTU/iot-project/scripts/` | Script Gateway được chia thành ba thư mục Scenario A/B/C; xem `iot-project/README.md` |
| `UBUNTU/iot-project/logs/` | Dữ liệu thu thập, CSV phân tích và log thực nghiệm |
| `UBUNTU/iot-project/state/` | File trạng thái thiết bị dùng trong quá trình phát hiện/cách ly/phục hồi |
| `UBUNTU/TAPO/` | Hệ thống giám sát Tapo L520E, Dashboard, SQLite và dữ liệu Evaluation |
| `WINDOWS/Scenario_A_Flood_DoS/` | Hướng dẫn và lệnh tạo UDP Flood bằng iperf3 từ Windows |
| `WINDOWS/Scenario_B_Network_Scan/` | Hướng dẫn và lệnh TCP Connect Scan bằng Nmap từ Windows |
| `WINDOWS/Scenario_C_Garbage_Data/` | Chương trình gửi telemetry bình thường và dữ liệu rác từ Windows |
| `WINDOWS/UNSW_LIFX/` | Phân tích tham khảo dữ liệu UNSW–LIFX bằng Z-Score |

---

## 2. Chuẩn bị môi trường

### 2.1. Ubuntu Gateway

**Yêu cầu đề xuất**

- Ubuntu Linux (Gateway của môi trường thực nghiệm).
- Python 3 và `venv`.
- Quyền `sudo` để capture lưu lượng và thao tác Firewall.
- Các công cụ hệ thống được kịch bản sử dụng: `iptables`, `iw`, `iperf3`, `tcpdump`; phần cấu hình Access Point có thể cần `hostapd` và `dnsmasq`.
- Gateway đã cấu hình Wi-Fi Access Point/Hotspot và các interface đúng với môi trường thử nghiệm.

Cài công cụ hệ thống (tên package có thể khác tùy phiên bản Ubuntu):

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip iptables iw iperf3 tcpdump hostapd dnsmasq
```

Cài thư viện Python:

```bash
cd CODE/UBUNTU
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Thư viện Python được khai báo trong `UBUNTU/requirements.txt`:

- `scapy`: capture/phân tích gói tin trong các script Gateway.
- `Flask`: chạy Dashboard Tapo.

Một số script chỉ dùng thư viện chuẩn Python nên không cần khai báo thêm package. `iptables`, `iw`, `iperf3`, `tcpdump`, `hostapd`, `dnsmasq` là công cụ hệ thống, **không cài bằng pip**.

**Thiết lập đường dẫn**

Các lệnh mẫu và đường dẫn trong script đang sử dụng `/home/ubuntu/iot-project/...`. Đặt thư mục `iot-project` tại `/home/ubuntu/iot-project/` hoặc sửa lại các đường dẫn trong script và `commands.txt` nếu dùng vị trí khác. Hướng dẫn chi tiết từng kịch bản nằm trong `UBUNTU/iot-project/README.md`.

Không chạy lệnh mẫu khi chưa kiểm tra lại interface, IP Gateway, MAC thiết bị, ngưỡng phát hiện và đường dẫn CSV/log.

### 2.2. Windows – ba kịch bản thực nghiệm

**Yêu cầu**

- Windows 10/11.
- **Scenario A – Flood/DoS:** cài `iperf3` trực tiếp trên Windows. Sau khi cài, mở PowerShell/CMD và kiểm tra bằng `iperf3 --version`. Bảo đảm Windows gọi được lệnh `iperf3` từ terminal.
- **Scenario B – Network Scan:** cài Nmap trực tiếp trên Windows. Kiểm tra bằng `nmap --version`.
- **Scenario C – Garbage Data:** cài Python 3; hai sender hiện sử dụng thư viện chuẩn có sẵn của Python.
- Windows và Ubuntu phải kết nối đúng mạng thử nghiệm.

`WINDOWS/requirements.txt` chỉ ghi chú các yêu cầu phía Windows; hiện không có package Python bên ngoài cần cài chung. **Không thể cài iperf3 bằng pip** vì đây là chương trình hệ thống độc lập, không phải thư viện Python. Nmap cũng được cài riêng, không cài bằng `pip`.

### 2.3. Windows – UNSW–LIFX

Bộ UNSW–LIFX là phần phân tích dữ liệu riêng, không phải sender của ba kịch bản Gateway.

**Yêu cầu**

- Python 3.10 trở lên.
- Các thư viện trong `WINDOWS/UNSW_LIFX/requirements.txt`: `numpy`, `pandas`, `matplotlib`.
- Giữ các file đầu vào cùng thư mục với `khao_sat_lifx.py`: `LIFX_NORMAL_5s.csv`, `LIFX_ATTACK_5s.csv` và `annotations.zip`.

Cài thư viện bằng PowerShell:

```powershell
cd WINDOWS\UNSW_LIFX
py -3 -m pip install -r requirements.txt
```

Chạy phân tích:

```powershell
py -3 khao_sat_lifx.py
```

Hoặc nhấp đúp `CHAY_TREN_WINDOWS.bat`. Script xuất CSV, báo cáo TXT và hình PNG vào `KET_QUA_LIFX/`.

**Lưu ý phương pháp:** nếu không cung cấp `--attack-origin-epoch`, phần ATTACK được gắn nhãn `PROXY`; chưa đồng bộ thời gian tuyệt đối theo UTC ở từng cửa sổ. Không diễn giải Detection Rate này thành tỷ lệ phát hiện gói tin độc hại hoặc khả năng phát hiện malware trên Tapo L520E. Xem `WINDOWS/UNSW_LIFX/README.txt` và `KET_QUA_LIFX/06_BAO_CAO_KET_QUA.txt` để biết chi tiết.

---

## 3. Chạy ba kịch bản Windows ↔ Ubuntu

Ba kịch bản phải được thực hiện trong mạng thử nghiệm do người thực hiện quản lý. Trước mỗi lượt chạy, xác nhận thiết bị ở trạng thái `NORMAL`, không còn luật DROP cũ và các thông số IP/MAC/interface khớp với cấu hình hiện tại.

### Scenario A – Flood/DoS

**Mục tiêu:** Windows tạo UDP traffic bằng iperf3; Ubuntu Gateway đo lưu lượng, phát hiện bất thường, cách ly thiết bị và theo dõi phục hồi.

- **Windows:** `iperf3` client.
- **Ubuntu:** iperf3 server, `flood_realtime_mitigation.py`, resource monitor và recovery watcher.
- **Hướng dẫn/lệnh:** `WINDOWS/Scenario_A_Flood_DoS/README.md` và `commands.txt`.
- **Script Gateway:** `UBUNTU/iot-project/scripts/Scenario_A_Flood_DoS/` và `UBUNTU/iot-project/README.md`.

Trình tự rút gọn:

1. Ubuntu kiểm tra station Wi-Fi, state và Firewall.
2. Ubuntu khởi động resource monitor và `iperf3 -s`.
3. Ubuntu chạy `flood_realtime_mitigation.py`; chờ các cửa sổ NORMAL theo hướng dẫn.
4. Windows chạy lệnh iperf3 UDP trong `commands.txt`.
5. Kiểm tra log, state và luật Firewall sau phát hiện.
6. Thực hiện disconnect/reconnect theo quy trình Recovery; xác nhận UNBLOCK và kết nối hoạt động lại.

### Scenario B – Network Scan

**Mục tiêu:** Windows dùng Nmap tạo TCP Connect Scan; Ubuntu Gateway theo dõi số lượng cổng đích duy nhất, phát hiện bất thường và thực hiện quy trình cách ly/phục hồi.

- **Windows:** Nmap.
- **Ubuntu:** `scan_realtime_mitigation.py`, `recovery_watcher.py` và resource monitor dành cho Scan.
- **Hướng dẫn/lệnh:** `WINDOWS/Scenario_B_Network_Scan/README.md` và `commands.txt`.
- **Script Gateway:** `UBUNTU/iot-project/scripts/Scenario_B_Network_Scan/` và `UBUNTU/iot-project/README.md`.

Trình tự rút gọn:

1. Ubuntu kiểm tra state, station Wi-Fi và Firewall.
2. Ubuntu khởi động resource monitor và detector Scan.
3. Chờ các cửa sổ NORMAL; kiểm tra ngưỡng/baseline trong đúng phiên bản script.
4. Windows chạy lệnh Nmap trong `commands.txt`.
5. Kiểm tra log phát hiện và luật DROP.
6. Sau khi detector ghi state `BLOCKED`, Ubuntu chạy recovery watcher; thực hiện Recovery và xác nhận state NORMAL, Firewall đã gỡ luật cách ly.

### Scenario C – Garbage Data

**Mục tiêu:** Windows gửi telemetry bình thường hoặc payload ngẫu nhiên qua TCP port `9999`; Ubuntu Gateway đo TCP payload, phát hiện bất thường, cách ly và phục hồi.

- **Windows:** `normal_telemetry_sender.py`, `garbage_sender.py`.
- **Ubuntu:** `garbage_receiver.py`, `garbage_measure.py`, `garbage_realtime_mitigation.py`, `garbage_recovery_watcher.py`, resource monitor và firewall script theo quy trình.
- **Hướng dẫn/lệnh:** `WINDOWS/Scenario_C_Garbage_Data/README.md` và `commands.txt`.
- **Script Gateway:** `UBUNTU/iot-project/scripts/Scenario_C_Garbage_Data/` và `UBUNTU/iot-project/README.md`.

Trình tự rút gọn:

1. Ubuntu khởi động receiver/detector và các thành phần giám sát cần thiết.
2. Kiểm tra TCP port `9999` có dịch vụ nhận dữ liệu.
3. Windows chạy sender NORMAL nếu cần thu thập đối chứng.
4. Windows chạy `garbage_sender.py` trong giai đoạn tấn công theo kịch bản.
5. Ubuntu kiểm tra log, Z-Score, state và Firewall.
6. Thực hiện Recovery và xác nhận kết nối trở lại.

> Các bước trên chỉ là tóm tắt. Dùng `commands.txt` của từng kịch bản làm trình tự thao tác chi tiết; không tự ý bỏ qua bước kiểm tra trạng thái hoặc Recovery.

---

## 4. Chạy hệ thống Gateway Tapo L520E và Dashboard

Phần này nằm trong `UBUNTU/TAPO/`. Đọc `UBUNTU/TAPO/README.md` trước khi chạy vì tài liệu đó chứa tham số, lệnh và quy trình Evaluation cụ thể.

Tóm tắt:

1. Cài package Ubuntu theo `UBUNTU/requirements.txt`.
2. Đảm bảo Gateway đã cấu hình interface Wi-Fi AP (ví dụ `ap0`) và Tapo L520E kết nối đúng mạng.
3. Chạy Dashboard từ thư mục `UBUNTU/TAPO/` theo README riêng.
4. Chạy chương trình giám sát/Evaluation trong terminal riêng.
5. Chỉ bật chế độ `--enable-block` khi đã xác nhận đúng thiết bị, IP/MAC, interface và hiểu tác động của Firewall.
6. Theo dõi Dashboard, CSV Evaluation và lịch sử SQLite.

Các thông số IP/MAC, baseline, ngưỡng Z-Score, tên interface và chain Firewall trong tài liệu là thông số của lần thử nghiệm đã thực hiện. Cần đối chiếu với môi trường thực tế trước khi chạy.

---

## 5. Dữ liệu và kết quả thực nghiệm

- `UBUNTU/iot-project/logs/`: chỉ giữ CSV kết quả liên quan đến ba kịch bản A/B/C; hướng dẫn nằm trong `UBUNTU/iot-project/README.md`.
- `UBUNTU/TAPO/evaluation/` và các thư mục `evaluation_*`: kết quả các phiên Evaluation.
- `UBUNTU/TAPO/baseline_scapy/`: dữ liệu baseline/test Scapy.
- `UBUNTU/TAPO/runtime/`: trạng thái gần nhất và cơ sở dữ liệu lịch sử Firewall.
- `WINDOWS/UNSW_LIFX/KET_QUA_LIFX/`: kết quả phân tích UNSW–LIFX.

Trong bản mã nguồn tinh gọn này, `iot-project/logs/` chỉ giữ các CSV kết quả liên quan trực tiếp đến ba kịch bản Windows A/B/C. Các script khảo sát, hiệu chỉnh ngưỡng và thử nghiệm trung gian không được đóng gói trong `iot-project/scripts/`; nếu cần lưu hồ sơ nghiên cứu đầy đủ, hãy lưu chúng ở kho lưu trữ riêng.

Các file runtime như SQLite, JSON trạng thái và log có thể thay đổi khi chạy. Nếu đây là bản nộp cần tái lập kết quả, giữ lại dữ liệu kết quả cần thiết nhưng rà soát thông tin nhạy cảm trước khi chia sẻ công khai.

---

## 6. Kiểm tra trước khi nộp

- [ ] `CODE/README.md` mô tả cấu trúc và hướng dẫn tổng thể.
- [ ] `UBUNTU/requirements.txt` chỉ chứa package Python cần cho Ubuntu.
- [ ] `WINDOWS/requirements.txt` không khai báo package Python không cần thiết.
- [ ] `WINDOWS/UNSW_LIFX/requirements.txt` chứa package riêng của LIFX.
- [ ] Windows có đủ sender/công cụ cần cho từng kịch bản.
- [ ] `UBUNTU/iot-project/` chỉ có README, ba nhóm script A/B/C, logs kết quả và state; Ubuntu có đủ detector, receiver, monitor, recovery và firewall script tương ứng.
- [ ] Đường dẫn trong `commands.txt` khớp với vị trí giải nén thực tế.
- [ ] Không đưa `.venv/`, `__pycache__/`, file `.pyc` hoặc bí mật cấu hình vào ZIP.
- [ ] Đã kiểm tra các file CSV/log cần nộp và không xóa nhầm dữ liệu minh chứng.

## 7. An toàn và giới hạn

- Chỉ chạy Flood/DoS, Network Scan và Garbage Data trong mạng lab hoặc hệ thống bạn được phép kiểm thử.
- Các script có thể cần quyền `sudo` và có thể thay đổi luật `iptables`; kiểm tra luật trước/sau khi chạy.
- Không dùng `iptables -F` để xóa toàn bộ Firewall của máy.
- Khi dừng chương trình bằng `Ctrl+C`, không mặc định rằng luật cách ly đã được gỡ. Hãy kiểm tra state và Firewall.
- Kết quả thực nghiệm chỉ phản ánh cấu hình, thiết bị, baseline và điều kiện đã kiểm thử; không tự động chứng minh khả năng tổng quát trên mọi thiết bị IoT.
