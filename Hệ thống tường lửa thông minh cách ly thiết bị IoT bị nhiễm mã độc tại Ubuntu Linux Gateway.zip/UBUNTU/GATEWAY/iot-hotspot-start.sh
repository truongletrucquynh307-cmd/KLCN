#!/bin/bash

UPLINK_IF="wlp2s0"
AP_IF="ap0"
AP_IP="10.42.0.1/24"
HOSTAPD_CONF="/etc/hostapd/hostapd.conf"

echo "=== IoT Gateway AUTO mode ==="

# Chờ NetworkManager ổn định một chút
sleep 8

# Bật IP forwarding
sysctl -w net.ipv4.ip_forward=1

# -------------------------------------------------
# 1. Xác định channel cần dùng
# -------------------------------------------------

FREQ=$(iw dev "$UPLINK_IF" link 2>/dev/null | awk '/freq:/ {printf "%d\n", $2}')

CHANNEL=1
MODE="offline"

if [ -n "$FREQ" ]; then

    case "$FREQ" in
        2412) CHANNEL=1 ;;
        2417) CHANNEL=2 ;;
        2422) CHANNEL=3 ;;
        2427) CHANNEL=4 ;;
        2432) CHANNEL=5 ;;
        2437) CHANNEL=6 ;;
        2442) CHANNEL=7 ;;
        2447) CHANNEL=8 ;;
        2452) CHANNEL=9 ;;
        2457) CHANNEL=10 ;;
        2462) CHANNEL=11 ;;
        2467) CHANNEL=12 ;;
        2472) CHANNEL=13 ;;
        *)
            echo "Uplink đang không ở 2.4 GHz: $FREQ MHz"
            echo "Fallback sang offline channel 1"

            # Ngắt uplink để radio có thể dùng channel 1
            nmcli device disconnect "$UPLINK_IF" 2>/dev/null || true

            CHANNEL=1
            MODE="offline"
            ;;
    esac

    if [ "$FREQ" -ge 2412 ] 2>/dev/null && [ "$FREQ" -le 2472 ] 2>/dev/null; then
        MODE="online"
    fi
fi

echo "Mode: $MODE"
echo "Frequency: ${FREQ:-none}"
echo "AP Channel: $CHANNEL"

# -------------------------------------------------
# 2. Cập nhật hostapd
# -------------------------------------------------

sed -i "s/^channel=.*/channel=$CHANNEL/" "$HOSTAPD_CONF"

# Đảm bảo luôn là 2.4 GHz
if grep -q "^hw_mode=" "$HOSTAPD_CONF"; then
    sed -i "s/^hw_mode=.*/hw_mode=g/" "$HOSTAPD_CONF"
else
    echo "hw_mode=g" >> "$HOSTAPD_CONF"
fi

# -------------------------------------------------
# 3. Dừng các dịch vụ trước khi dựng lại AP
# -------------------------------------------------

systemctl stop dnsmasq 2>/dev/null || true
systemctl stop hostapd 2>/dev/null || true

# Xóa AP cũ nếu còn
iw dev "$AP_IF" del 2>/dev/null || true

sleep 1

# -------------------------------------------------
# 4. Tạo AP ảo
# -------------------------------------------------

iw dev "$UPLINK_IF" interface add "$AP_IF" type __ap

nmcli device set "$AP_IF" managed no 2>/dev/null || true

ip link set "$AP_IF" down
iw dev "$AP_IF" set type __ap
ip link set "$AP_IF" up

ip addr flush dev "$AP_IF"
ip addr add "$AP_IP" dev "$AP_IF"

sleep 2

# -------------------------------------------------
# 5. Khởi động Wi-Fi AP
# -------------------------------------------------

systemctl restart hostapd

sleep 3

systemctl restart dnsmasq

# -------------------------------------------------
# 6. NAT
# -------------------------------------------------

iptables -t nat -D POSTROUTING -s 10.42.0.0/24 -o "$UPLINK_IF" -j MASQUERADE 2>/dev/null || true
iptables -D FORWARD -i "$AP_IF" -o "$UPLINK_IF" -j ACCEPT 2>/dev/null || true
iptables -D FORWARD -i "$UPLINK_IF" -o "$AP_IF" -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || true

if [ "$MODE" = "online" ]; then

    iptables -t nat -A POSTROUTING -s 10.42.0.0/24 -o "$UPLINK_IF" -j MASQUERADE

    iptables -A FORWARD -i "$AP_IF" -o "$UPLINK_IF" -j ACCEPT

    iptables -A FORWARD -i "$UPLINK_IF" -o "$AP_IF" \
        -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT

fi

echo "=== IoT Gateway ready ==="
