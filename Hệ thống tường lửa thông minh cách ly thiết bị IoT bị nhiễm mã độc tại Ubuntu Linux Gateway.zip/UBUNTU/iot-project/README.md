# iot-project – Mã nguồn Gateway cho 3 kịch bản Windows

Thư mục này chỉ giữ các thành phần chạy trên **Ubuntu Gateway** để phối hợp với ba kịch bản được phát động từ Windows: Flood/DoS, Network Scan và Garbage Data. Các chương trình tạo traffic từ Windows được giữ riêng trong `CODE/WINDOWS/`.

## 1. Cấu trúc

```text
iot-project/
├── README.md
├── scripts/
│   ├── Scenario_A_Flood_DoS/
│   ├── Scenario_B_Network_Scan/
│   └── Scenario_C_Garbage_Data/
├── logs/
└── state/
    └── device_state.txt
```

- `scripts/Scenario_A_Flood_DoS/`: detector Flood/DoS, resource monitor và các script block/unblock/recovery.
- `scripts/Scenario_B_Network_Scan/`: detector Scan, resource monitor và recovery watcher riêng của kịch bản B.
- `scripts/Scenario_C_Garbage_Data/`: TCP receiver, bộ đo TCP payload, detector, recovery watcher, firewall và resource monitor.
- `logs/`: CSV kết quả của ba kịch bản. Khi chạy lại, một số script sẽ ghi đè file CSV có cùng tên.
- `state/device_state.txt`: trạng thái dùng chung; trước lượt thử mới phải xác nhận `NORMAL` và không còn luật DROP cũ.

## 2. Chuẩn bị Ubuntu Gateway

Cài công cụ hệ thống cần thiết:

```bash
sudo apt update
sudo apt install -y python3 python3-pip iptables iw iperf3 tcpdump
```

Cài thư viện Python theo `CODE/UBUNTU/requirements.txt` ở thư mục gốc của bộ mã nguồn. Các script dùng Scapy cần được chạy bằng đúng môi trường Python đã cài Scapy.

Kiểm tra trước khi chạy:

```bash
cat /home/ubuntu/iot-project/state/device_state.txt
iw dev ap0 station dump
sudo iptables -L FORWARD -n -v --line-numbers
```

Đường dẫn trong các script hiện đặt theo `/home/ubuntu/iot-project/`. Nếu cài ở vị trí khác, cần sửa các hằng đường dẫn trong script và lệnh chạy tương ứng. Kiểm tra lại interface `ap0`, IP Gateway `10.42.0.1` và MAC thử nghiệm `ac:36:1b:ef:41:8e` trước khi chạy.

## 3. Kịch bản A – Flood/DoS

**Thành phần Ubuntu:**
- `scripts/Scenario_A_Flood_DoS/monitor_gateway_resources.py`
- `scripts/Scenario_A_Flood_DoS/flood_realtime_mitigation.py`
- `scripts/Scenario_A_Flood_DoS/recovery_watcher.py`
- `block_test_node.sh`, `unblock_test_node.sh`
- iperf3 server (cài bằng apt, không phải package Python)

**Trình tự:**

1. Terminal 1 – theo dõi tài nguyên:
   ```bash
   python3 /home/ubuntu/iot-project/scripts/Scenario_A_Flood_DoS/monitor_gateway_resources.py
   ```
2. Terminal 2 – khởi động iperf3 server:
   ```bash
   iperf3 -s
   ```
3. Terminal 3 – chạy detector:
   ```bash
   sudo python3 -u /home/ubuntu/iot-project/scripts/Scenario_A_Flood_DoS/flood_realtime_mitigation.py
   ```
4. Chờ ít nhất 3 cửa sổ NORMAL, sau đó chạy lệnh iperf3 client từ Windows theo `CODE/WINDOWS/Scenario_A_Flood_DoS/commands.txt`.
5. Khi state chuyển `BLOCKED`, mở Terminal 4 và chạy recovery watcher:
   ```bash
   sudo python3 -u /home/ubuntu/iot-project/scripts/Scenario_A_Flood_DoS/recovery_watcher.py
   ```
6. Thực hiện disconnect/reconnect Wi-Fi từ Windows theo hướng dẫn. Kiểm tra state và firewall sau khi watcher hoàn tất.

Ngưỡng detector trong phiên bản này là `Z_THRESHOLD = 2.0`. CSV được ghi vào `logs/flood_realtime_mitigation.csv`, `logs/gateway_resources_z20.csv` và `logs/flood_recovery.csv`.

## 4. Kịch bản B – Network Scan

**Thành phần Ubuntu:**
- `scripts/Scenario_B_Network_Scan/scan_realtime_mitigation.py`
- `scripts/Scenario_B_Network_Scan/monitor_gateway_resources_scan.py`
- `scripts/Scenario_B_Network_Scan/recovery_watcher.py`
- `scripts/Scenario_B_Network_Scan/unblock_test_node.sh`

**Trình tự:**

1. Terminal 1 – resource monitor:
   ```bash
   python3 /home/ubuntu/iot-project/scripts/Scenario_B_Network_Scan/monitor_gateway_resources_scan.py
   ```
2. Terminal 2 – detector:
   ```bash
   sudo python3 -u /home/ubuntu/iot-project/scripts/Scenario_B_Network_Scan/scan_realtime_mitigation.py
   ```
3. Chờ ít nhất 3 cửa sổ NORMAL rồi chạy Nmap từ Windows theo `CODE/WINDOWS/Scenario_B_Network_Scan/commands.txt`.
4. Chỉ sau khi detector đã ghi state `BLOCKED`, mở Terminal 3 và chạy recovery watcher:
   ```bash
   sudo python3 -u /home/ubuntu/iot-project/scripts/Scenario_B_Network_Scan/recovery_watcher.py
   ```
5. Disconnect/reconnect Wi-Fi từ Windows và xác nhận watcher gỡ DROP, state trở về `NORMAL`.

Cấu hình detector hiện có `Z_THRESHOLD = 4.0`, cửa sổ 10 giây, baseline μ = 0.2500 và σ = 0.4739. Resource CSV: `logs/gateway_resources_scan_z40.csv`; recovery CSV: `logs/scan_recovery.csv`.

## 5. Kịch bản C – Garbage Data

**Thành phần Ubuntu:**
- `scripts/Scenario_C_Garbage_Data/garbage_receiver.py`
- `scripts/Scenario_C_Garbage_Data/garbage_measure.py`
- `scripts/Scenario_C_Garbage_Data/garbage_realtime_mitigation.py`
- `scripts/Scenario_C_Garbage_Data/garbage_recovery_watcher.py`
- `scripts/Scenario_C_Garbage_Data/garbage_firewall.sh`
- `scripts/Scenario_C_Garbage_Data/monitor_gateway_resources_garbage.py`

**Trình tự:**

1. Terminal 1 – TCP receiver trên `10.42.0.1:9999`:
   ```bash
   sudo python3 -u /home/ubuntu/iot-project/scripts/Scenario_C_Garbage_Data/garbage_receiver.py
   ```
2. Terminal 2 – resource monitor:
   ```bash
   python3 /home/ubuntu/iot-project/scripts/Scenario_C_Garbage_Data/monitor_gateway_resources_garbage.py
   ```
3. Terminal 3 – detector:
   ```bash
   sudo python3 -u /home/ubuntu/iot-project/scripts/Scenario_C_Garbage_Data/garbage_realtime_mitigation.py
   ```
4. Chờ trạng thái NORMAL ổn định, sau đó chạy `normal_telemetry_sender.py` hoặc `garbage_sender.py` trên Windows theo đúng giai đoạn trong `CODE/WINDOWS/Scenario_C_Garbage_Data/commands.txt`.
5. Khi state chuyển `BLOCKED`, mở Terminal 4 và chạy recovery watcher:
   ```bash
   sudo python3 -u /home/ubuntu/iot-project/scripts/Scenario_C_Garbage_Data/garbage_recovery_watcher.py
   ```
6. Thực hiện disconnect/reconnect Wi-Fi từ Windows và xác nhận state, firewall, kết nối sau phục hồi.

Detector dùng TCP payload B/s và ngưỡng riêng của kịch bản C; không thay bằng detector A/B hoặc tự áp ngưỡng của kịch bản khác. CSV được ghi vào `logs/garbage_realtime.csv` và `logs/gateway_resources_garbage.csv`.

## 6. Lưu ý

- Các script A/B/C đều có thể thay đổi `iptables`; chỉ chạy trong mạng lab do bạn quản lý.
- Không chạy recovery watcher A/B/C trước khi state tương ứng là `BLOCKED`; các watcher hiện tại kiểm tra điều kiện này khi khởi động.
- Không kết luận cách ly thành công chỉ từ một dòng log. Đối chiếu state, luật DROP và kiểm tra kết nối từ Windows.
- Các CSV đang có trong `logs/` là dữ liệu kết quả đã giữ lại cho ba kịch bản. Sao lưu trước khi chạy lại vì một số script mở CSV ở chế độ ghi mới.
