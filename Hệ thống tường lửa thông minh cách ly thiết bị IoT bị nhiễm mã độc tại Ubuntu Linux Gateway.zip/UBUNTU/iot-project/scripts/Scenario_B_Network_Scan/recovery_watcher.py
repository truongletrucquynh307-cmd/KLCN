import subprocess
import time
import os
import csv
from datetime import datetime


# ============================================================
# CONFIG
# ============================================================

MAC = "ac:36:1b:ef:41:8e"

INTERFACE = "ap0"

CHECK_INTERVAL = 0.5

UNBLOCK_SCRIPT = (
    "/home/ubuntu/iot-project/scripts/Scenario_B_Network_Scan/unblock_test_node.sh"
)

OUTPUT_FILE = (
    "/home/ubuntu/iot-project/logs/scan_recovery.csv"
)

# Shared state dùng chung với detector
STATE_FILE = (
    "/home/ubuntu/iot-project/state/"
    "device_state.txt"
)


# ============================================================
# TIME
# ============================================================

def now():
    return datetime.now()


def ts(t=None):

    if t is None:
        t = now()

    return t.strftime(
        "%Y-%m-%d %H:%M:%S.%f"
    )[:-3]


# ============================================================
# SHARED STATE
# ============================================================

VALID_STATES = {
    "NORMAL",
    "BLOCKED",
    "RECOVERY_WAIT",
    "RECOVERY_CHECK"
}


def read_shared_state():

    try:

        with open(
            STATE_FILE,
            "r"
        ) as f:

            state = (
                f.read()
                .strip()
                .upper()
            )

        if state in VALID_STATES:
            return state

    except FileNotFoundError:
        pass

    return "NORMAL"


def write_shared_state(state):

    state = state.upper()

    if state not in VALID_STATES:

        raise ValueError(
            f"Invalid shared state: {state}"
        )

    os.makedirs(
        os.path.dirname(
            STATE_FILE
        ),
        exist_ok=True
    )

    temp_file = (
        STATE_FILE
        + ".tmp"
    )

    with open(
        temp_file,
        "w"
    ) as f:

        f.write(
            state + "\n"
        )

        f.flush()

        os.fsync(
            f.fileno()
        )

    os.replace(
        temp_file,
        STATE_FILE
    )


# ============================================================
# CHECK STATION
# ============================================================

def station_present():

    result = subprocess.run(
        [
            "iw",
            "dev",
            INTERFACE,
            "station",
            "dump"
        ],
        capture_output=True,
        text=True
    )

    return (
        MAC.lower()
        in result.stdout.lower()
    )


# ============================================================
# UNBLOCK DEVICE
# ============================================================

def unblock():

    start = now()

    result = subprocess.run(
        [UNBLOCK_SCRIPT],
        capture_output=True,
        text=True
    )

    end = now()

    return (
        start,
        end,
        result.returncode,
        result.stdout,
        result.stderr
    )


# ============================================================
# PREPARE
# ============================================================

os.makedirs(
    os.path.dirname(
        OUTPUT_FILE
    ),
    exist_ok=True
)


# ============================================================
# START
# ============================================================

print("=" * 70)
print("RECOVERY WATCHER")
print("=" * 70)

print(
    f"Target MAC : {MAC}"
)

print(
    f"Interface  : {INTERFACE}"
)

initial_state = (
    read_shared_state()
)

print(
    f"Initial state: "
    f"{initial_state}"
)

print()


# ============================================================
# SAFETY CHECK
# ============================================================

if initial_state != "BLOCKED":

    print(
        "ERROR: Recovery watcher "
        "requires shared state BLOCKED."
    )

    print(
        f"Current shared state: "
        f"{initial_state}"
    )

    print(
        "Recovery watcher stopped."
    )

    raise SystemExit(1)


print(
    "Waiting for device "
    "to DISCONNECT..."
)

print("=" * 70)


# ============================================================
# STATE 1:
# BLOCKED
# Wait until station disappears
# ============================================================

disconnect_time = None

while True:

    if not station_present():

        disconnect_time = now()

        # ----------------------------------------
        # Shared state:
        # BLOCKED -> RECOVERY_WAIT
        # ----------------------------------------

        write_shared_state(
            "RECOVERY_WAIT"
        )

        print()

        print(
            f"DISCONNECTED : "
            f"{ts(disconnect_time)}"
        )

        print(
            "STATE        : "
            "RECOVERY_WAIT"
        )

        print()

        print(
            "Waiting for same MAC "
            "to reconnect..."
        )

        break

    time.sleep(
        CHECK_INTERVAL
    )


# ============================================================
# STATE 2:
# RECOVERY_WAIT
# Wait until same station returns
# ============================================================

reconnect_time = None

while True:

    if station_present():

        reconnect_time = now()

        # ----------------------------------------
        # Shared state:
        # RECOVERY_WAIT -> RECOVERY_CHECK
        # ----------------------------------------

        write_shared_state(
            "RECOVERY_CHECK"
        )

        print()

        print(
            f"RECONNECTED  : "
            f"{ts(reconnect_time)}"
        )

        print(
            "STATE        : "
            "RECOVERY_CHECK"
        )

        break

    time.sleep(
        CHECK_INTERVAL
    )


# ============================================================
# STATE 3:
# UNBLOCK
# ============================================================

(
    unblock_start,
    unblock_end,
    rc,
    stdout,
    stderr

) = unblock()


unblock_ms = (
    unblock_end
    - unblock_start
).total_seconds() * 1000


# ============================================================
# UNBLOCK SUCCESS
# ============================================================

if rc == 0:

    # --------------------------------------------
    # Chỉ chuyển NORMAL sau khi iptables
    # unblock thành công
    # --------------------------------------------

    write_shared_state(
        "NORMAL"
    )

    print(
        f"UNBLOCKED    : "
        f"{ts(unblock_end)}"
    )

    print(
        f"UNBLOCK TIME : "
        f"{unblock_ms:.3f} ms"
    )

    print(
        "STATE        : NORMAL"
    )

    state = "NORMAL"


# ============================================================
# UNBLOCK FAILED
# ============================================================

else:

    print(
        "UNBLOCK FAILED"
    )

    print(stdout)

    print(stderr)

    # Không được chuyển NORMAL nếu firewall chưa unblock.
    # Giữ trạng thái để biểu thị recovery chưa hoàn tất.

    write_shared_state(
        "RECOVERY_CHECK"
    )

    state = (
        "UNBLOCK_FAILED"
    )


# ============================================================
# LOG
# ============================================================

file_exists = (
    os.path.exists(
        OUTPUT_FILE
    )
)

with open(
    OUTPUT_FILE,
    "a",
    newline=""
) as f:

    writer = csv.writer(f)

    if not file_exists:

        writer.writerow([
            "disconnect_timestamp",
            "reconnect_timestamp",
            "unblock_timestamp",
            "reconnect_detection_delay_ms",
            "unblock_execution_ms",
            "state"
        ])

    reconnect_detection_delay_ms = (
        unblock_start
        - reconnect_time
    ).total_seconds() * 1000

    writer.writerow([
        ts(
            disconnect_time
        ),
        ts(
            reconnect_time
        ),
        ts(
            unblock_end
        ),
        round(
            reconnect_detection_delay_ms,
            3
        ),
        round(
            unblock_ms,
            3
        ),
        state
    ])


# ============================================================
# END
# ============================================================

print()

print("=" * 70)

print(
    "RECOVERY WATCHER FINISHED"
)

print(
    f"Shared state: "
    f"{read_shared_state()}"
)

print("=" * 70)
