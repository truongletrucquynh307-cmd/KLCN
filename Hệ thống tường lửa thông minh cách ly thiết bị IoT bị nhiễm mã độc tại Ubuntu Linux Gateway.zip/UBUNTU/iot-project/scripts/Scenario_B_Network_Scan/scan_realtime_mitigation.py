import subprocess
import os
import time
from datetime import datetime

# ============================================================
# CONFIG
# ============================================================

INTERFACE = "ap0"
TARGET_MAC = "ac:36:1b:ef:41:8e"

WINDOW_SECONDS = 10

MU = 0.2500
SIGMA = 0.4739

Z_THRESHOLD = 4.0

STATE_FILE = "/home/ubuntu/iot-project/state/device_state.txt"

# ============================================================


def now():
    return datetime.now()


def ts(t=None):
    if t is None:
        t = now()

    return t.strftime(
        "%Y-%m-%d %H:%M:%S.%f"
    )[:-3]


def read_state():

    try:
        with open(STATE_FILE) as f:
            return f.read().strip()

    except FileNotFoundError:
        return "NORMAL"


def write_state(state):

    os.makedirs(
        os.path.dirname(STATE_FILE),
        exist_ok=True
    )

    with open(STATE_FILE, "w") as f:
        f.write(state)


def capture_window():

    bpf_filter = (
        f"ether src {TARGET_MAC} and "
        "tcp[tcpflags] & tcp-syn != 0"
    )

    cmd = [
        "timeout",
        str(WINDOW_SECONDS),
        "tcpdump",
        "-i",
        INTERFACE,
        "-n",
        "-l",
        "-q",
        bpf_filter
    ]

    result = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    packets = 0
    ports = set()

    for line in result.stdout.splitlines():

        if " IP " not in line:
            continue

        try:

            right = line.split(
                " > ", 1
            )[1]

            destination = right.split(
                ":", 1
            )[0]

            port = int(
                destination.rsplit(
                    ".", 1
                )[1]
            )

            packets += 1
            ports.add(port)

        except (IndexError, ValueError):
            continue

    return packets, ports


def firewall_rule_exists():

    result = subprocess.run(
        [
            "iptables",
            "-C",
            "FORWARD",
            "-i",
            INTERFACE,
            "-m",
            "mac",
            "--mac-source",
            TARGET_MAC,
            "-j",
            "DROP"
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    return result.returncode == 0


def block_device():

    if firewall_rule_exists():
        return 0.0

    start = time.perf_counter()

    result = subprocess.run(
        [
            "iptables",
            "-I",
            "FORWARD",
            "1",
            "-i",
            INTERFACE,
            "-m",
            "mac",
            "--mac-source",
            TARGET_MAC,
            "-j",
            "DROP"
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    end = time.perf_counter()

    if result.returncode != 0:

        print(
            "[ERROR] iptables:",
            result.stderr
        )

        return None

    return (end - start) * 1000


# ============================================================
# START
# ============================================================

#write_state("NORMAL")

print("=" * 72)
print("SCENARIO B - REALTIME NETWORK SCAN DETECTION")
print("=" * 72)

print(f"Interface       : {INTERFACE}")
print(f"Target MAC      : {TARGET_MAC}")

print(
    f"Baseline        : "
    f"mu={MU:.4f}, sigma={SIGMA:.4f}"
)

print(
    f"Z threshold     : {Z_THRESHOLD}"
)

print(
    f"Window          : {WINDOW_SECONDS}s"
)

print(
    f"Initial state   : {read_state()}"
)

print("=" * 72)

window_id = 0
attack_start = None


while True:

    # Đồng bộ state với recovery watcher
    state = read_state()

    if state != "NORMAL":

        print()
        print(
            f"[{ts()}] STATE={state} "
            "- detector waiting..."
        )

        time.sleep(2)
        continue

    window_id += 1

    print()
    print("-" * 72)

    print(
        f"WINDOW #{window_id} "
        f"- capturing {WINDOW_SECONDS}s..."
    )

    packets, ports = capture_window()

    unique_ports = len(ports)

    z = (
        (unique_ports - MU)
        / SIGMA
    )

    detected_time = now()

    print(
        f"TCP SYN packets  : {packets}"
    )

    print(
        f"Unique dst ports : {unique_ports}"
    )

    print(
        f"Z-score          : {z:.4f}"
    )

    if ports:

        print(
            f"Ports sample     : "
            f"{sorted(ports)[:20]}"
        )

    # ========================================================
    # ANOMALY
    # ========================================================

    if z >= Z_THRESHOLD:

        print()
        print(
            "*** ANOMALY: NETWORK SCAN DETECTED ***"
        )

        print(
            f"DETECTED         : "
            f"{ts(detected_time)}"
        )

        # attack_start approximated by beginning
        # of current 10-second observation window
        attack_start = (
            detected_time.timestamp()
            - WINDOW_SECONDS
        )

        print(
            f"Z               : {z:.4f}"
        )

        print(
            f"Unique ports    : {unique_ports}"
        )

        overhead = block_device()

        blocked_time = now()

        if overhead is not None:

            write_state("BLOCKED")

            print(
                f"BLOCKED          : "
                f"{ts(blocked_time)}"
            )

            print(
                f"iptables overhead: "
                f"{overhead:.3f} ms"
            )

            print(
                "STATE             : BLOCKED"
            )

    else:

        print(
            "RESULT            : NORMAL"
        )

        print(
            "STATE             : NORMAL"
        )
