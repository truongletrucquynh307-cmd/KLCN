#!/usr/bin/env python3

import time
import csv
import os
from datetime import datetime

OUTPUT = "/home/ubuntu/iot-project/logs/gateway_resources_scan_z40.csv"
INTERVAL = 1.0


def read_cpu():

    with open("/proc/stat", "r") as f:
        fields = f.readline().split()

    values = list(map(int, fields[1:]))

    idle = values[3]

    if len(values) > 4:
        idle += values[4]

    total = sum(values)

    return total, idle


def read_memory():

    data = {}

    with open("/proc/meminfo", "r") as f:

        for line in f:

            key, value = line.split(":", 1)

            data[key] = int(
                value.strip().split()[0]
            )

    total = data["MemTotal"]
    available = data["MemAvailable"]

    used = total - available

    ram_percent = (
        used / total * 100
    )

    return total, used, ram_percent


os.makedirs(
    os.path.dirname(OUTPUT),
    exist_ok=True
)

print("=" * 70)
print("SCENARIO B - GATEWAY RESOURCE MONITOR")
print("=" * 70)

print("Output:", OUTPUT)
print("Sampling interval:", INTERVAL, "second")
print("Press Ctrl+C to stop.")

print("=" * 70)
print()

previous_total, previous_idle = read_cpu()


with open(
    OUTPUT,
    "w",
    newline=""
) as f:

    writer = csv.writer(f)

    writer.writerow([
        "timestamp",
        "cpu_percent",
        "ram_used_kb",
        "ram_total_kb",
        "ram_percent"
    ])

    f.flush()

    try:

        while True:

            time.sleep(INTERVAL)

            total, idle = read_cpu()

            total_delta = (
                total - previous_total
            )

            idle_delta = (
                idle - previous_idle
            )

            if total_delta > 0:

                cpu_percent = (
                    100.0 *
                    (total_delta - idle_delta) /
                    total_delta
                )

            else:

                cpu_percent = 0.0

            previous_total = total
            previous_idle = idle

            ram_total, ram_used, ram_percent = (
                read_memory()
            )

            timestamp = (
                datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S.%f"
                )[:-3]
            )

            writer.writerow([
                timestamp,
                f"{cpu_percent:.2f}",
                ram_used,
                ram_total,
                f"{ram_percent:.2f}"
            ])

            f.flush()

            print(
                f"{timestamp} | "
                f"CPU={cpu_percent:.2f}% | "
                f"RAM={ram_percent:.2f}%"
            )

    except KeyboardInterrupt:

        print()
        print("Monitor stopped.")
        print("Saved:", OUTPUT)
