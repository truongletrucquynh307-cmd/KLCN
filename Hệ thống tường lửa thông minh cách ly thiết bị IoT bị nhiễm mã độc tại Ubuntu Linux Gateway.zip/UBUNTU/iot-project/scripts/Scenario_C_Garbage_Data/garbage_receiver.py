#!/usr/bin/env python3

import socket
from datetime import datetime

HOST = "10.42.0.1"
PORT = 9999

total_bytes = 0


def ts():
    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S.%f"
    )[:-3]


server = socket.socket(
    socket.AF_INET,
    socket.SOCK_STREAM
)

server.setsockopt(
    socket.SOL_SOCKET,
    socket.SO_REUSEADDR,
    1
)

server.bind((HOST, PORT))
server.listen(5)

print("=" * 70)
print("SCENARIO C - GARBAGE DATA RECEIVER")
print("=" * 70)
print(f"Listening : {HOST}:{PORT}")
print("Press Ctrl+C to stop.")
print("=" * 70)

try:

    while True:

        conn, addr = server.accept()

        print(
            f"[{ts()}] CONNECTED: "
            f"{addr[0]}:{addr[1]}"
        )

        connection_bytes = 0

        try:

            while True:

                data = conn.recv(65536)

                if not data:
                    break

                size = len(data)

                connection_bytes += size
                total_bytes += size

        except ConnectionResetError:
            pass

        finally:

            conn.close()

            print(
                f"[{ts()}] DISCONNECTED | "
                f"connection_bytes={connection_bytes} | "
                f"total_bytes={total_bytes}"
            )

except KeyboardInterrupt:

    print()
    print("Receiver stopped.")

finally:

    server.close()
