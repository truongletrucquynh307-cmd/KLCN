#!/usr/bin/env python3

from scapy.all import sniff, TCP, Raw
from datetime import datetime

INTERFACE = "ap0"
TARGET_MAC = "ac:36:1b:ef:41:8e"
GATEWAY_IP = "10.42.0.1"
PORT = 9999

WINDOW_SECONDS = 10

BPF = (
    f"ether src {TARGET_MAC} "
    f"and tcp "
    f"and dst host {GATEWAY_IP} "
    f"and dst port {PORT}"
)


def timestamp():
    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S.%f"
    )[:-3]


def measure_window(seconds=WINDOW_SECONDS):

    packets = 0
    payload_bytes = 0

    def process(pkt):
        nonlocal packets, payload_bytes

        if TCP not in pkt:
            return

        packets += 1

        if Raw in pkt:
            payload_bytes += len(bytes(pkt[Raw].load))

    sniff(
        iface=INTERFACE,
        filter=BPF,
        prn=process,
        store=False,
        timeout=seconds
    )

    rate = payload_bytes / seconds

    return {
        "timestamp": timestamp(),
        "packets": packets,
        "payload_bytes": payload_bytes,
        "bytes_per_second": rate
    }


def calculate_z(rate, mu, sigma):
    if sigma <= 0:
        raise ValueError(
            "Sigma must be greater than zero."
        )

    return (rate - mu) / sigma
