#!/usr/bin/env python3

import os
import sys
import time
import subprocess
from datetime import datetime

# Import bộ đo TCP payload V2
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from garbage_measure import measure_window, calculate_z


# ==========================================================
# SCENARIO C - Z-SCORE RECOVERY WATCHER V2
# ==========================================================

MAC = "ac:36:1b:ef:41:8e"
IFACE = "ap0"

MU = 334.16833333333335
SIGMA = 42.74385917558477
Z_THRESHOLD = 5.0

REQUIRED_NORMAL_WINDOWS = 2
POLL_INTERVAL = 0.5

STATE_FILE = (
    "/home/ubuntu/iot-project/state/device_state.txt"
)

FIREWALL_SCRIPT = (
    "/home/ubuntu/iot-project/scripts/Scenario_C_Garbage_Data/garbage_firewall.sh"
)


def now():
    return datetime.now()


def ts(value=None):
    if value is None:
        value = now()

    return value.strftime(
        "%Y-%m-%d %H:%M:%S.%f"
    )[:-3]


def read_state():
    with open(STATE_FILE, "r") as f:
        return f.read().strip()


def write_state(value):
    with open(STATE_FILE, "w") as f:
        f.write(value + "\n")


def run_command(args):
    return subprocess.run(
        args,
        capture_output=True,
        text=True
    )


def station_connected():

    result = run_command([
        "iw", "dev", IFACE, "station", "dump"
    ])

    if result.returncode != 0:
        raise RuntimeError(
            "Cannot read Wi-Fi station list: "
            + result.stderr
        )

    return MAC.lower() in result.stdout.lower()


def firewall_rules(chain):

    result = run_command([
        "iptables", "-S", chain
    ])

    if result.returncode != 0:
        raise RuntimeError(
            "Cannot inspect iptables "
            + chain
            + ": "
            + result.stderr
        )

    return result.stdout.splitlines()


def mac_drop_exists():

    for chain in ("INPUT", "FORWARD"):

        for rule in firewall_rules(chain):

            if "-j DROP" not in rule:
                continue

            if MAC.lower() in rule.lower():
                return True

    return False


def tcp9999_drop_exists():

    for rule in firewall_rules("INPUT"):

        if "-j DROP" not in rule:
            continue

        if "--dport 9999" in rule:
            return True

    return False


def firewall_action(action):

    result = run_command([
        "bash",
        FIREWALL_SCRIPT,
        action
    ])

    if result.stdout:
        print(result.stdout.strip())

    if result.returncode != 0:
        raise RuntimeError(
            "Firewall action failed: "
            + action
            + "\n"
            + result.stderr
        )


def capture_window():

    result = measure_window()

    rate = result["bytes_per_second"]

    z = calculate_z(
        rate,
        MU,
        SIGMA
    )

    return (
        result["packets"],
        result["payload_bytes"],
        rate,
        z
    )


def main():

    print("=" * 70)
    print("SCENARIO C - Z-SCORE RECOVERY WATCHER V2")
    print("=" * 70)

    print("Target MAC :", MAC)
    print("Interface  :", IFACE)
    print("Baseline mu:", MU)
    print("Baseline sd:", SIGMA)
    print("Threshold  :", Z_THRESHOLD)
    print("Initial state:", read_state())

    if read_state() != "BLOCKED":
        raise SystemExit(
            "ERROR: Recovery requires BLOCKED state."
        )

    if not mac_drop_exists() and not tcp9999_drop_exists():
        raise SystemExit(
            "ERROR: BLOCKED state but no matching DROP found."
        )

    print()
    print("Waiting for device to DISCONNECT...")

    while station_connected():
        time.sleep(POLL_INTERVAL)

    disconnected_at = now()

    write_state("RECOVERY_WAIT")

    print("DISCONNECTED :", ts(disconnected_at))
    print("STATE        : RECOVERY_WAIT")
    print()
    print("Waiting for same MAC to reconnect...")

    while not station_connected():
        time.sleep(POLL_INTERVAL)

    reconnected_at = now()

    write_state("RECOVERY_CHECK")

    print("RECONNECTED :", ts(reconnected_at))
    print("STATE       : RECOVERY_CHECK")

    # Tạm cho phép INPUT TCP/9999 trong giai đoạn
    # kiểm tra recovery.
    #
    # Lưu ý: Việc này phụ thuộc firewall.sh unblock_input
    # hoặc cách quản lý INPUT của firewall hiện tại.
    # Nếu script firewall không hỗ trợ action này,
    # hãy dùng cấu hình firewall tương ứng.

    temporary_rule = [
        "iptables", "-I", "INPUT", "1",
        "-i", IFACE,
        "-m", "mac", "--mac-source", MAC,
        "-p", "tcp",
        "--dport", "9999",
        "-j", "ACCEPT"
    ]

    delete_temporary_rule = [
        "iptables", "-D", "INPUT",
        "-i", IFACE,
        "-m", "mac", "--mac-source", MAC,
        "-p", "tcp",
        "--dport", "9999",
        "-j", "ACCEPT"
    ]

    inserted = False
    recovery_passed = False

    try:

        result = run_command(temporary_rule)

        if result.returncode != 0:
            raise RuntimeError(
                "Cannot insert temporary INPUT ACCEPT: "
                + result.stderr
            )

        inserted = True

        print("INPUT TCP/9999 temporarily allowed")

        consecutive_normal = 0
        window_id = 0

        while consecutive_normal < REQUIRED_NORMAL_WINDOWS:

            window_id += 1

            print()
            print("-" * 70)
            print(
                f"RECOVERY WINDOW #{window_id} "
                "- capturing 10s..."
            )

            packets, payload_bytes, rate, z = capture_window()

            print("Packets       :", packets)
            print("Payload bytes :", payload_bytes)
            print(f"Rate          : {rate:.2f} B/s")
            print(f"Z-score       : {z:.4f}")

            if z < Z_THRESHOLD:

                consecutive_normal += 1

                print("RESULT        : NORMAL CANDIDATE")

            else:

                consecutive_normal = 0

                print("RESULT        : ANOMALY")

            print(
                "Consecutive normal windows:",
                f"{consecutive_normal}/{REQUIRED_NORMAL_WINDOWS}"
            )

        recovery_passed = True

    finally:

        if inserted:

            result = run_command(delete_temporary_rule)

            if result.returncode != 0:
                print(
                    "WARNING: Cannot remove temporary "
                    "INPUT ACCEPT rule."
                )
                print(result.stderr)

                recovery_passed = False

    if not recovery_passed:
        raise RuntimeError(
            "Recovery verification not completed."
        )

    print()
    print("=" * 70)
    print("Z-SCORE RECOVERY VERIFICATION PASSED")
    print("=" * 70)

    start = time.perf_counter()

    firewall_action("unblock")

    unblock_ms = (
        time.perf_counter() - start
    ) * 1000

    # Xác nhận firewall đã sạch trước khi NORMAL.
    if mac_drop_exists() or tcp9999_drop_exists():

        print("ERROR: DROP rules still exist.")
        print("State remains RECOVERY_CHECK.")

        raise RuntimeError(
            "Firewall unblock verification failed."
        )

    unblocked_at = now()

    write_state("NORMAL")

    print("UNBLOCKED   :", ts(unblocked_at))
    print(f"UNBLOCK TIME: {unblock_ms:.3f} ms")
    print("STATE       : NORMAL")

    print()
    print("=" * 70)
    print("RECOVERY WATCHER FINISHED")
    print("=" * 70)


if __name__ == "__main__":

    try:
        main()

    except KeyboardInterrupt:
        print()
        print("Recovery stopped by Ctrl+C.")

    except Exception as e:
        print()
        print("RECOVERY ERROR:", e)
        print("Current state:", read_state())
        raise
