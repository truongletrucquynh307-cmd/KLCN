#!/bin/bash
set -euo pipefail

MAC="ac:36:1b:ef:41:8e"
IFACE="ap0"
PORT="9999"

STATE="/home/ubuntu/iot-project/state/device_state.txt"

ACTION="${1:-status}"

# Rule cô lập Internet
FORWARD_RULE=(
    -i "$IFACE"
    -m mac --mac-source "$MAC"
    -j DROP
)

# Rule chặn garbage TCP vào chính Gateway
INPUT_RULE=(
    -i "$IFACE"
    -p tcp --dport "$PORT"
    -m mac --mac-source "$MAC"
    -j DROP
)

# Rule FORWARD cũ của A/B, không có -i ap0
OLD_FORWARD_RULE=(
    -m mac --mac-source "$MAC"
    -j DROP
)

remove_all() {
    while iptables -C FORWARD "${FORWARD_RULE[@]}" 2>/dev/null; do
        iptables -D FORWARD "${FORWARD_RULE[@]}"
    done

    while iptables -C FORWARD "${OLD_FORWARD_RULE[@]}" 2>/dev/null; do
        iptables -D FORWARD "${OLD_FORWARD_RULE[@]}"
    done

    while iptables -C INPUT "${INPUT_RULE[@]}" 2>/dev/null; do
        iptables -D INPUT "${INPUT_RULE[@]}"
    done
}

case "$ACTION" in

    block)
        if ! iptables -C FORWARD "${FORWARD_RULE[@]}" 2>/dev/null; then
            iptables -I FORWARD 1 "${FORWARD_RULE[@]}"
        fi

        if ! iptables -C INPUT "${INPUT_RULE[@]}" 2>/dev/null; then
            iptables -I INPUT 1 "${INPUT_RULE[@]}"
        fi

        echo "BLOCKED"
        ;;

    unblock)
        remove_all

        # Chỉ cập nhật state khi cả hai rule đã biến mất.
        if iptables -C FORWARD "${FORWARD_RULE[@]}" 2>/dev/null ||
           iptables -C FORWARD "${OLD_FORWARD_RULE[@]}" 2>/dev/null ||
           iptables -C INPUT "${INPUT_RULE[@]}" 2>/dev/null; then

            echo "ERROR: DROP rule still exists"
            exit 1
        fi

        echo "NORMAL" > "$STATE"
        echo "UNBLOCKED"
        ;;

    status)
        echo "=== INPUT ==="
        iptables -L INPUT -n -v --line-numbers

        echo "=== FORWARD ==="
        iptables -L FORWARD -n -v --line-numbers

        echo "=== SHARED STATE ==="
        cat "$STATE"
        ;;

    *)
        echo "Usage: $0 block|unblock|status"
        exit 1
        ;;
esac
