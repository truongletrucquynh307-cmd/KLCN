#!/usr/bin/env python3

import os
import re
import csv
import time
import signal
import subprocess

from datetime import datetime
from garbage_measure import measure_window

# ============================================================
# SCENARIO C - REALTIME GARBAGE DATA DETECTION
# ============================================================

INTERFACE = "ap0"
TARGET_MAC = "ac:36:1b:ef:41:8e"

WINDOW_SECONDS = 10

MU = 238.8050
SIGMA = 628.9700
Z_THRESHOLD = 5.0

STATE_FILE = (
    "/home/ubuntu/iot-project/state/"
    "device_state.txt"
)

FIREWALL_SCRIPT = (
    "/home/ubuntu/iot-project/scripts/Scenario_C_Garbage_Data/garbage_firewall.sh"
)

OUTPUT = (
    "/home/ubuntu/iot-project/logs/garbage_realtime.csv"
)

# ============================================================
# UTILITIES
# ============================================================

def now():
    return datetime.now()


def ts(value=None):
    if value is None:
        value = now()

    return value.strftime(
        "%Y-%m-%d %H:%M:%S.%f"
    )[:-3]


def read_state():
    try:
        with open(STATE_FILE) as f:
            return f.read().strip()
    except FileNotFoundError:
        return "UNKNOWN"


def write_state(state):
    temp = STATE_FILE + ".tmp"

    with open(temp, "w") as f:
        f.write(state + "\n")

    os.replace(temp, STATE_FILE)


def rule_exists(chain, args):
    result = subprocess.run(
        ["iptables", "-C", chain] + args,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    return result.returncode == 0


def firewall_blocked():
    mac_rule = [
        "-i", INTERFACE,
        "-m", "mac",
        "--mac-source", TARGET_MAC,
        "-j", "DROP"
    ]

    old_rule = [
        "-m", "mac",
        "--mac-source", TARGET_MAC,
        "-j", "DROP"
    ]

    input_rule = [
        "-i", INTERFACE,
        "-p", "tcp",
        "--dport", "9999",
        "-m", "mac",
        "--mac-source", TARGET_MAC,
        "-j", "DROP"
    ]

    return (
        rule_exists("FORWARD", mac_rule)
        or rule_exists("FORWARD", old_rule)
        or rule_exists("INPUT", input_rule)
    )


def capture_window():
    result = measure_window()

    return (
        result["packets"],
        result["payload_bytes"],
        result["bytes_per_second"],
        10.0
    )


def apply_block():

    start = time.perf_counter()

    result = subprocess.run(
        ["bash", FIREWALL_SCRIPT, "block"],
        capture_output=True,
        text=True
    )

    overhead_ms = (
        time.perf_counter() - start
    ) * 1000

    if result.returncode != 0:
        raise RuntimeError(
            result.stderr or result.stdout
        )

    # Phải xác nhận rule thực sự tồn tại.
    if not firewall_blocked():
        raise RuntimeError(
            "Firewall block verification failed"
        )

    return overhead_ms


# ============================================================
# STARTUP VALIDATION
# ============================================================

os.makedirs(
    os.path.dirname(OUTPUT),
    exist_ok=True
)

print("=" * 70)
print("SCENARIO C - REALTIME GARBAGE MITIGATION")
print("=" * 70)

print("Interface :", INTERFACE)
print("MAC       :", TARGET_MAC)
print("Window    :", WINDOW_SECONDS, "seconds")
print("MU        :", MU)
print("SIGMA     :", SIGMA)
print("Threshold :", Z_THRESHOLD)
print("State     :", read_state())
print("=" * 70)

# Không tự ghi NORMAL lúc khởi động.
# Đây là cách tránh lỗi state NORMAL nhưng firewall vẫn DROP.

initial_state = read_state()

if initial_state == "NORMAL" and firewall_blocked():
    raise SystemExit(
        "ERROR: state NORMAL but firewall still BLOCKED. "
        "Repair firewall/state before starting."
    )

if initial_state != "NORMAL":
    raise SystemExit(
        f"ERROR: initial state is {initial_state}. "
        "Start detector only from NORMAL."
    )

# ============================================================
# CSV
# ============================================================

with open(OUTPUT, "w", newline="") as f:

    writer = csv.writer(f)

    writer.writerow([
        "timestamp",
        "window_id",
        "packets",
        "captured_bytes",
        "bytes_per_second",
        "z_score",
        "result",
        "state",
        "detected_time",
        "blocked_time",
        "firewall_overhead_ms"
    ])

    f.flush()

    window_id = 0
    previous_state = "NORMAL"

    try:

        while True:

            state = read_state()

            # Khi BLOCKED, watcher có thể chuyển sang
            # RECOVERY_WAIT / RECOVERY_CHECK / NORMAL.
            if state != "NORMAL":

                if state != previous_state:
                    print()
                    print("STATE:", state)

                previous_state = state

                time.sleep(0.5)
                continue

            if firewall_blocked():
                print(
                    "ERROR: state NORMAL but DROP rule exists."
                )
                print(
                    "Detector paused for safety."
                )
                time.sleep(1)
                continue

            if previous_state != "NORMAL":
                print()
                print("=" * 70)
                print("RECOVERY COMPLETED")
                print("STATE: NORMAL")
                print("Detector resumed.")
                print("=" * 70)

            previous_state = "NORMAL"

            window_id += 1

            print()
            print("-" * 70)
            print(
                f"WINDOW #{window_id} "
                f"- capturing {WINDOW_SECONDS}s..."
            )

            packets, captured_bytes, rate, elapsed = (
                capture_window()
            )

            z = (rate - MU) / SIGMA

            detected_time = ""
            blocked_time = ""
            overhead_ms = ""

            result = "NORMAL"

            # Recovery watcher có thể đã đổi state
            # trong lúc capture.
            if read_state() != "NORMAL":
                print("State changed during capture.")
                continue

            if z >= Z_THRESHOLD:

                result = "ANOMALY"

                detected_at = now()
                detected_time = ts(detected_at)

                print()
                print(
                    "*** ANOMALY: GARBAGE DATA DETECTED ***"
                )
                print("DETECTED :", detected_time)

                try:

                    overhead_ms = apply_block()

                    blocked_at = now()
                    blocked_time = ts(blocked_at)

                    write_state("BLOCKED")

                    print("BLOCKED  :", blocked_time)
                    print(
                        "iptables overhead:",
                        f"{overhead_ms:.3f} ms"
                    )

                except Exception as e:

                    print("BLOCK ERROR:", e)
                    print(
                        "Inspect firewall and state manually."
                    )
                    raise

            print("TCP/IP packets :", packets)
            print("Captured bytes :", captured_bytes)
            print(f"Rate           : {rate:.2f} B/s")
            print(f"Z-score        : {z:.4f}")
            print("RESULT         :", result)
            print("STATE          :", read_state())

            writer.writerow([
                ts(),
                window_id,
                packets,
                captured_bytes,
                f"{rate:.2f}",
                f"{z:.4f}",
                result,
                read_state(),
                detected_time,
                blocked_time,
                (
                    f"{overhead_ms:.3f}"
                    if overhead_ms != ""
                    else ""
                )
            ])

            f.flush()

    except KeyboardInterrupt:

        print()
        print("Detector stopped by Ctrl+C.")

print("Saved:", OUTPUT)
