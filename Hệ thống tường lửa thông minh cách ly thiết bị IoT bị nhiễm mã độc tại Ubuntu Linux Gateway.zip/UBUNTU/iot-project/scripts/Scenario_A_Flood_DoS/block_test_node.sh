#!/bin/bash

MAC="ac:36:1b:ef:41:8e"
IFACE="ap0"

echo "======================================"
echo "BLOCK TEST NODE"
echo "Time : $(date '+%Y-%m-%d %H:%M:%S.%3N')"
echo "MAC  : $MAC"
echo "======================================"

iptables -C FORWARD \
-i "$IFACE" \
-m mac --mac-source "$MAC" \
-j DROP 2>/dev/null

if [ $? -ne 0 ]; then

    iptables -I FORWARD 1 \
    -i "$IFACE" \
    -m mac --mac-source "$MAC" \
    -j DROP

fi

echo "BLOCK COMPLETED"
echo "Time : $(date '+%Y-%m-%d %H:%M:%S.%3N')"
