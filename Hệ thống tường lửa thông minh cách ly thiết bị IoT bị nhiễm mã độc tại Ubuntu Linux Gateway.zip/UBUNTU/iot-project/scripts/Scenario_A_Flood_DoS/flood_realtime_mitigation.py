import subprocess
import time
import csv
import os
from datetime import datetime


# ============================================================
# CONFIG
# ============================================================

MAC = "ac:36:1b:ef:41:8e"
INTERFACE = "ap0"

# Baseline NORMAL
MU = 7610.45
SIGMA = 47920.28

# Threshold chính thức của kịch bản A
Z_THRESHOLD = 2.0

SAMPLE_INTERVAL = 1
WINDOW_SIZE = 10

OUTPUT_FILE = (
    "/home/ubuntu/iot-project/logs/flood_realtime_mitigation.csv"
)

BLOCK_SCRIPT = (
    "/home/ubuntu/iot-project/scripts/Scenario_A_Flood_DoS/block_test_node.sh"
)

# Shared state giữa detector và recovery watcher
STATE_FILE = (
    "/home/ubuntu/iot-project/state/"
    "device_state.txt"
)


# ============================================================
# TIME FUNCTIONS
# ============================================================

def now():
    return datetime.now()


def timestamp(dt=None):
    if dt is None:
        dt = now()

    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


# ============================================================
# SHARED STATE
# ============================================================

VALID_STATES = {
    "NORMAL",
    "BLOCKED",
    "RECOVERY_WAIT",
    "RECOVERY_CHECK"
}


def read_shared_state():
    """
    Đọc trạng thái chung giữa detector và recovery watcher.
    Nếu file chưa tồn tại hoặc nội dung không hợp lệ,
    mặc định trả về NORMAL.
    """

    try:
        with open(STATE_FILE, "r") as f:
            state = f.read().strip().upper()

        if state in VALID_STATES:
            return state

    except FileNotFoundError:
        pass

    return "NORMAL"


def write_shared_state(state):
    """
    Ghi trạng thái theo kiểu atomic:
    ghi file tạm -> replace file chính.
    """

    state = state.upper()

    if state not in VALID_STATES:
        raise ValueError(
            f"Invalid shared state: {state}"
        )

    os.makedirs(
        os.path.dirname(STATE_FILE),
        exist_ok=True
    )

    temp_file = STATE_FILE + ".tmp"

    with open(temp_file, "w") as f:
        f.write(state + "\n")
        f.flush()
        os.fsync(f.fileno())

    os.replace(
        temp_file,
        STATE_FILE
    )


# ============================================================
# GET STATION TRAFFIC
# ============================================================

def get_station_bytes():

    result = subprocess.run(
        [
            "iw",
            "dev",
            INTERFACE,
            "station",
            "dump"
        ],
        capture_output=True,
        text=True
    )

    lines = result.stdout.splitlines()

    target_found = False
    rx_bytes = None
    tx_bytes = None

    for line in lines:

        stripped = line.strip()

        if stripped.startswith("Station "):

            parts = stripped.split()

            if len(parts) >= 2:
                station_mac = parts[1].lower()
                target_found = (
                    station_mac == MAC.lower()
                )

            continue

        if target_found:

            if stripped.startswith("rx bytes:"):

                rx_bytes = int(
                    stripped
                    .split(":", 1)[1]
                    .strip()
                )

            elif stripped.startswith("tx bytes:"):

                tx_bytes = int(
                    stripped
                    .split(":", 1)[1]
                    .strip()
                )

            if (
                rx_bytes is not None
                and tx_bytes is not None
            ):
                return rx_bytes, tx_bytes

    return None, None


# ============================================================
# BLOCK DEVICE
# ============================================================

def block_device():

    start = now()

    result = subprocess.run(
        [BLOCK_SCRIPT],
        capture_output=True,
        text=True
    )

    end = now()

    if result.returncode != 0:

        print("BLOCK SCRIPT STDOUT:")
        print(result.stdout)

        print("BLOCK SCRIPT STDERR:")
        print(result.stderr)

    return (
        start,
        end,
        result.returncode
    )


# ============================================================
# PREPARE CSV
# ============================================================

os.makedirs(
    os.path.dirname(OUTPUT_FILE),
    exist_ok=True
)

f = open(
    OUTPUT_FILE,
    "w",
    newline=""
)

writer = csv.writer(f)

writer.writerow([
    "timestamp",
    "window_id",
    "avg_Bps",
    "z_score",
    "state",
    "detection_timestamp",
    "block_start_timestamp",
    "block_end_timestamp",
    "mitigation_overhead_ms"
])

f.flush()


# ============================================================
# START
# ============================================================

print("=" * 75)
print(
    "SCENARIO A - REALTIME FLOOD "
    "DETECTION + MITIGATION"
)
print("=" * 75)

print(f"MAC          : {MAC}")
print(f"Interface    : {INTERFACE}")
print(f"Baseline mu  : {MU:.2f} B/s")
print(f"Baseline std : {SIGMA:.2f} B/s")
print(f"Threshold    : Z = {Z_THRESHOLD}")
print(
    f"Window       : "
    f"{WINDOW_SIZE} samples (~10 s)"
)
print(f"Output       : {OUTPUT_FILE}")
print(f"State file   : {STATE_FILE}")

print("=" * 75)


# ============================================================
# INITIAL SHARED STATE
# ============================================================

shared_state = read_shared_state()

print(
    f"Initial shared state : "
    f"{shared_state}"
)

print("=" * 75)


# ============================================================
# GET INITIAL COUNTERS
# ============================================================

previous_rx, previous_tx = (
    get_station_bytes()
)

if previous_rx is None:

    print(
        "ERROR: Target station "
        "not found."
    )

    f.close()

    raise SystemExit(1)


previous_time = time.time()

samples = []

window_id = 1


# ============================================================
# MAIN LOOP
# ============================================================

try:

    while True:

        time.sleep(
            SAMPLE_INTERVAL
        )

        # ----------------------------------------------------
        # Đồng bộ trạng thái từ shared state
        # ----------------------------------------------------

        shared_state = (
            read_shared_state()
        )

        blocked = (
            shared_state == "BLOCKED"
        )

        # ----------------------------------------------------
        # Đọc traffic
        # ----------------------------------------------------

        current_rx, current_tx = (
            get_station_bytes()
        )

        current_time = time.time()

        # ----------------------------------------------------
        # Station biến mất
        # Recovery watcher sẽ xử lý phần recovery
        # ----------------------------------------------------

        if current_rx is None:

            print(
                "Target station disappeared. "
                f"Shared state={shared_state}"
            )

            # Tránh dùng counter/time cũ sau reconnect
            previous_rx = None
            previous_tx = None
            previous_time = current_time
            samples = []

            continue

        # ----------------------------------------------------
        # Station vừa xuất hiện lại
        # Khởi tạo lại counter
        # ----------------------------------------------------

        if (
            previous_rx is None
            or previous_tx is None
        ):

            previous_rx = current_rx
            previous_tx = current_tx
            previous_time = current_time

            samples = []

            print(
                "Target station available again. "
                "Traffic counters resynchronized."
            )

            continue

        elapsed = (
            current_time
            - previous_time
        )

        if elapsed <= 0:
            continue

        delta_rx = (
            current_rx
            - previous_rx
        )

        delta_tx = (
            current_tx
            - previous_tx
        )

        # ----------------------------------------------------
        # Counter reset protection
        # ----------------------------------------------------

        if (
            delta_rx < 0
            or delta_tx < 0
        ):

            previous_rx = current_rx
            previous_tx = current_tx
            previous_time = current_time

            samples = []

            print(
                "Traffic counter reset detected. "
                "Window cleared."
            )

            continue

        total_Bps = (
            delta_rx + delta_tx
        ) / elapsed

        print(
            f"{timestamp()} | "
            f"Traffic="
            f"{total_Bps:10.2f} B/s"
        )

        samples.append(
            total_Bps
        )

        previous_rx = current_rx
        previous_tx = current_tx
        previous_time = current_time


        # ====================================================
        # WINDOW COMPLETE
        # ====================================================

        if len(samples) == WINDOW_SIZE:

            decision_time = now()

            avg_Bps = (
                sum(samples)
                / WINDOW_SIZE
            )

            z_score = (
                avg_Bps - MU
            ) / SIGMA

            # Đọc lại shared state ngay tại thời điểm quyết định
            shared_state = (
                read_shared_state()
            )

            blocked = (
                shared_state == "BLOCKED"
            )

            print("-" * 75)

            print(
                f"WINDOW #{window_id}"
            )

            print(
                f"AVG     : "
                f"{avg_Bps:.2f} B/s"
            )

            print(
                f"Z-SCORE : "
                f"{z_score:.3f}"
            )


            # ================================================
            # CASE 1:
            # NORMAL + Z > threshold
            # => ANOMALY => BLOCK
            # ================================================

            if (
                z_score > Z_THRESHOLD
                and shared_state == "NORMAL"
            ):

                detection_time = (
                    decision_time
                )

                print(
                    "STATE   : ANOMALY"
                )

                print(
                    f"DETECTED: "
                    f"{timestamp(detection_time)}"
                )

                (
                    block_start,
                    block_end,
                    return_code

                ) = block_device()

                overhead_ms = (
                    block_end
                    - block_start
                ).total_seconds() * 1000

                if return_code == 0:

                    # ----------------------------------------
                    # Quan trọng:
                    # cập nhật shared state cho watcher
                    # ----------------------------------------

                    write_shared_state(
                        "BLOCKED"
                    )

                    shared_state = "BLOCKED"

                    print(
                        f"BLOCKED : "
                        f"{timestamp(block_end)}"
                    )

                    print(
                        f"IPTABLES OVERHEAD: "
                        f"{overhead_ms:.3f} ms"
                    )

                    state = "BLOCKED"

                else:

                    print(
                        "ERROR: "
                        "iptables block failed"
                    )

                    state = (
                        "BLOCK_FAILED"
                    )

                writer.writerow([
                    timestamp(
                        decision_time
                    ),
                    window_id,
                    round(
                        avg_Bps,
                        2
                    ),
                    round(
                        z_score,
                        4
                    ),
                    state,
                    timestamp(
                        detection_time
                    ),
                    timestamp(
                        block_start
                    ),
                    timestamp(
                        block_end
                    ),
                    round(
                        overhead_ms,
                        3
                    )
                ])

                f.flush()


            # ================================================
            # CASE 2:
            # Không kích hoạt block mới
            # Trạng thái lấy từ shared state
            # ================================================

            else:

                shared_state = (
                    read_shared_state()
                )

                if shared_state == "BLOCKED":

                    state = "BLOCKED"

                elif shared_state == "RECOVERY_WAIT":

                    state = (
                        "RECOVERY_WAIT"
                    )

                elif shared_state == "RECOVERY_CHECK":

                    state = (
                        "RECOVERY_CHECK"
                    )

                else:

                    state = "NORMAL"

                print(
                    f"STATE   : {state}"
                )

                writer.writerow([
                    timestamp(
                        decision_time
                    ),
                    window_id,
                    round(
                        avg_Bps,
                        2
                    ),
                    round(
                        z_score,
                        4
                    ),
                    state,
                    "",
                    "",
                    "",
                    ""
                ])

                f.flush()


            print("-" * 75)

            samples = []

            window_id += 1


# ============================================================
# STOP
# ============================================================

except KeyboardInterrupt:

    print()

    print("=" * 75)

    print(
        "DETECTOR STOPPED"
    )

    print("=" * 75)


finally:

    f.close()
