#!/bin/bash

MAC="ac:36:1b:ef:41:8e"
IFACE="ap0"

echo "======================================"
echo "UNBLOCK TEST NODE"
echo "Time : $(date '+%Y-%m-%d %H:%M:%S.%3N')"
echo "MAC  : $MAC"
echo "======================================"

while iptables -C FORWARD \
-i "$IFACE" \
-m mac --mac-source "$MAC" \
-j DROP 2>/dev/null
do

    iptables -D FORWARD \
    -i "$IFACE" \
    -m mac --mac-source "$MAC" \
    -j DROP

done

echo "UNBLOCK COMPLETED"
echo "Time : $(date '+%Y-%m-%d %H:%M:%S.%3N')"
