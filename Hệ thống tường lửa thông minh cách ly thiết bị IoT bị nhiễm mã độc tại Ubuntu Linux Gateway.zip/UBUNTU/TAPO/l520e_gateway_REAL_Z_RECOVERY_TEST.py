#!/usr/bin/env python3
"""L520E Gateway: real packet Z-score, simulated xN input, MAC-source FORWARD DROP,
automatic Wi-Fi link-loss/rejoin observation; fail-closed recovery Z gate.
Wi-Fi station transitions cannot prove power loss by themselves.
"""
import argparse
import csv
import json
import tempfile
import sys
import datetime as datetime
import uuid
from pathlib import Path
import ipaddress
import os
import re
import subprocess
import threading
import time
from scapy.all import AsyncSniffer, IP

MU = 17.495681
SIGMA = 60.981802
THRESHOLD = 4.0
CHAIN = 'L520E_DROP'


def command(argv, check=True):
    return subprocess.run(argv, capture_output=True, text=True, check=check)


def iptables(*args, check=True):
    return command(['iptables', '-w', '3', *args], check=check)


def chain_exists():
    return iptables('-L', CHAIN, '-n', check=False).returncode == 0


def install_block(ip, mac, iface):
    if chain_exists():
        raise RuntimeError(f'{CHAIN} already exists: inspect it before running')
    iptables('-N', CHAIN)
    try:
        # Routed IPv4 packets FROM the bulb: identify by source MAC on ap0.
        iptables('-A', CHAIN, '-i', iface, '-m', 'mac', '--mac-source', mac, '-j', 'DROP')
        # Routed IPv4 packets TO the bulb: source MAC is not the bulb MAC.
        # Use destination IP here; iptables mac match supports source MAC only.
        iptables('-A', CHAIN, '-o', iface, '-d', ip, '-j', 'DROP')
        iptables('-I', 'FORWARD', '1', '-j', CHAIN)
    except Exception:
        remove_block()
        raise


def remove_block():
    while iptables('-C', 'FORWARD', '-j', CHAIN, check=False).returncode == 0:
        iptables('-D', 'FORWARD', '-j', CHAIN)
    if chain_exists():
        iptables('-F', CHAIN)
        iptables('-X', CHAIN)


def station_snapshot(iface, mac):
    """Return (present, inactive_ms, rx_packets, tx_packets).
    A station can remain listed after power loss, so presence alone is insufficient.
    """
    result = command(['iw', 'dev', iface, 'station', 'dump'])
    blocks = re.split(r'(?=^\s*Station\s+)', result.stdout, flags=re.MULTILINE)
    for block in blocks:
        match = re.search(r'^\s*Station\s+([0-9a-f:]{17})\b', block,
                          flags=re.MULTILINE | re.IGNORECASE)
        if not match or match.group(1).lower() != mac.lower():
            continue
        def field(name):
            found = re.search(r'^\s*' + re.escape(name) + r':\s*(\d+)',
                              block, flags=re.MULTILINE | re.IGNORECASE)
            return int(found.group(1)) if found else None
        return True, field('inactive time'), field('rx packets'), field('tx packets')
    return False, None, None, None


def wifi_station_present(iface, mac):
    return station_snapshot(iface, mac)[0]


def wait_for_unplug(iface, mac, timeout, consecutive, poll, inactive_ms, log_event,
                    allow_idle_inference=False):
    """Observe AP station loss automatically; inactivity is weak, opt-in evidence."""
    deadline = time.monotonic() + timeout
    streak = 0
    previous = station_snapshot(iface, mac)
    while time.monotonic() < deadline:
        present, idle, rx, tx = station_snapshot(iface, mac)
        new_rx = (present and previous[0] and rx is not None and
                  previous[2] is not None and rx > previous[2])
        absent = not present
        weak_idle = (allow_idle_inference and present and idle is not None
                     and idle >= inactive_ms and not new_rx)
        candidate = absent or weak_idle
        streak = streak + 1 if candidate else 0
        print(f'DISCONNECT_WAIT: station={"PRESENT" if present else "ABSENT"} '
              f'idle_ms={idle} rx={rx} evidence={"ABSENT" if absent else "IDLE_WEAK" if weak_idle else "NONE"} '
              f'confirmation={streak}/{consecutive}', flush=True)
        if streak >= consecutive:
            evidence = 'station absent' if absent else 'inactivity only (weak inference)'
            log_event('DISCONNECTED_INFERRED', evidence + '; NOT proof of physical power cycle')
            return True
        previous = (present, idle, rx, tx)
        time.sleep(min(poll, max(0, deadline - time.monotonic())))
    log_event('DISCONNECT_TIMEOUT', 'No sustained link-loss evidence; no automatic unblock')
    return False


def wait_for_replug(iface, mac, timeout, consecutive, poll, fresh_ms, log_event):
    """Require station activity after previously observed link-loss evidence."""
    deadline = time.monotonic() + timeout
    streak = 0
    last = station_snapshot(iface, mac)
    while time.monotonic() < deadline:
        present, idle, rx, tx = station_snapshot(iface, mac)
        new_rx = (present and rx is not None and last[2] is not None
                  and rx > last[2])
        fresh = present and idle is not None and idle <= fresh_ms
        candidate = fresh or new_rx
        streak = streak + 1 if candidate else 0
        print(f'RECONNECT_WAIT: station={"PRESENT" if present else "ABSENT"} '
              f'idle_ms={idle} rx={rx} confirmation={streak}/{consecutive}', flush=True)
        if streak >= consecutive:
            log_event('RECONNECTED_INFERRED', 'Wi-Fi station active after link loss; NOT proof of clean boot')
            return True
        last = (present, idle, rx, tx)
        time.sleep(min(poll, max(0, deadline - time.monotonic())))
    log_event('RECONNECT_TIMEOUT', 'No sustained new station activity')
    return False


def main():
    parser = argparse.ArgumentParser(description='L520E xN anomaly -> iptables -> automatic Wi-Fi recovery observation')
    parser.add_argument('--iface', default='ap0')
    parser.add_argument('--bulb-ip', required=True)
    parser.add_argument('--bulb-mac', required=True)
    parser.add_argument('--warmup', type=float, default=30)
    parser.add_argument('--inject', type=float, default=40)
    parser.add_argument('--injection-min-real', type=float, default=0.0,
                        help='Require real_Bps > this value before starting injection')
    parser.add_argument('--injection-wait-timeout', type=float, default=120.0,
                        help='Maximum seconds to wait for qualifying real traffic after warmup')
    parser.add_argument('--multiplier', type=float, default=10)
    parser.add_argument('--window', type=float, default=5)
    parser.add_argument('--disconnect-timeout', type=float, default=90)
    parser.add_argument('--recovery-wait', type=float, default=10)
    parser.add_argument('--reconnect-timeout', type=float, default=120)
    parser.add_argument('--recovery-check-timeout', type=float, default=90)
    parser.add_argument('--recovery-z-confirmations', type=int, default=3)
    parser.add_argument('--station-confirmations', type=int, default=3)
    parser.add_argument('--station-poll', type=float, default=2)
    parser.add_argument('--disconnect-idle-ms', type=int, default=15000,
                        help='Fallback when AP retains stale station after unplug')
    parser.add_argument('--reconnect-fresh-ms', type=int, default=4000)
    parser.add_argument('--allow-idle-inference', action='store_true',
                        help='Opt in: treat sustained Wi-Fi inactivity as weak disconnect evidence')
    parser.add_argument('--retry-delay', type=float, default=10,
                        help='Delay before retrying recovery check after FAIL; block persists')
    parser.add_argument('--enable-block', action='store_true')
    parser.add_argument('--log', default=None, help='Optional legacy event CSV path (unique by default)')
    parser.add_argument('--evaluation-dir', default='evaluation', help='Append run data to CSVs here')
    parser.add_argument('--live-state-file', default=None,
                        help='JSON status for Flask; default: sibling runtime/live_state.json next to evaluation dir')
    parser.add_argument('--normal-only', action='store_true', help='Collect NORMAL windows only; no injection, firewall or recovery')
    parser.add_argument('--real-block-test', action='store_true', help='Test real traffic Z>3 -> iptables BLOCK without injection; stops after BLOCK')
    parser.add_argument('--real-recovery-test', action='store_true',
                        help='Real Z > 4 triggers iptables BLOCK, then original fail-closed Wi-Fi/Recovery sequence; no injection')
    parser.add_argument('--real-test-duration', type=float, default=300, help='Seconds to observe after warmup before exiting if no real anomaly')
    parser.add_argument('--normal-duration', type=float, default=3600, help='Seconds for --normal-only')
    args = parser.parse_args()

    if os.geteuid() != 0:
        parser.error('Run with sudo')
    try:
        ipaddress.IPv4Address(args.bulb_ip)
    except ipaddress.AddressValueError:
        parser.error('Invalid bulb IP')
    if not re.fullmatch(r'(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}', args.bulb_mac):
        parser.error('Invalid bulb MAC')
    if any(v <= 0 for v in (args.inject, args.multiplier, args.window,
                            args.disconnect_timeout,
                            args.reconnect_timeout, args.station_poll, args.recovery_check_timeout)) or args.warmup < 0 or args.recovery_wait < 0:
        parser.error('Invalid time or multiplier')
    if args.normal_duration <= 0:
        parser.error('--normal-duration must be > 0')
    if args.retry_delay < 0:
        parser.error('Invalid retry delay')
    if args.injection_min_real < 0 or args.injection_wait_timeout <= 0:
        parser.error('Invalid injection wait settings')
    if args.recovery_z_confirmations < 1:
        parser.error('--recovery-z-confirmations must be >= 1')
    if args.station_confirmations < 1:
        parser.error('--station-confirmations must be >= 1')
    if args.normal_only and args.enable_block:
        parser.error('--normal-only must not be combined with --enable-block')
    if args.real_block_test and args.real_recovery_test:
        parser.error('Choose only one of --real-block-test or --real-recovery-test')
    if (args.real_block_test or args.real_recovery_test) and (args.normal_only or not args.enable_block):
        parser.error('Real Z BLOCK/RECOVERY test requires --enable-block and must not use --normal-only')
    if (args.real_block_test or args.real_recovery_test) and args.real_test_duration <= 0:
        parser.error('--real-test-duration must be > 0')
    if args.enable_block and chain_exists():
        parser.error(f'Chain {CHAIN} already exists. It may be a persistent quarantine from a prior run; inspect and manually clear only when safe.')
    if command(['iw', 'dev', args.iface, 'info'], check=False).returncode != 0:
        parser.error(f'{args.iface} is not a recognized wireless interface')
    if command(['iw', 'dev', args.iface, 'station', 'dump'], check=False).returncode != 0:
        parser.error('Cannot query Wi-Fi stations: check iw, interface, sudo')
    if not wifi_station_present(args.iface, args.bulb_mac):
        parser.error('Bulb MAC not currently associated with AP. Verify MAC and connect bulb first.')

    byte_count = 0
    lock = threading.Lock()
    def on_packet(packet):
        nonlocal byte_count
        if IP in packet and (packet[IP].src == args.bulb_ip or packet[IP].dst == args.bulb_ip):
            with lock:
                byte_count += len(packet)

    sniffer = AsyncSniffer(iface=args.iface, filter=f'ip and host {args.bulb_ip}',
                           prn=on_packet, store=False)
    own_chain = False
    state = 'NORMAL'
    start = time.monotonic()
    last_tick = start
    last_bytes = 0
    blocked_at = None
    injection_started_at = None
    injection_wait_started_at = None

    run_id = datetime.datetime.now().strftime('%Y%m%dT%H%M%S') + '_' + uuid.uuid4().hex[:8]
    evdir = Path(args.evaluation_dir).expanduser().resolve()
    evdir.mkdir(parents=True, exist_ok=True)
    live_path = (Path(args.live_state_file).expanduser().resolve() if args.live_state_file
                 else evdir.parent / 'runtime' / 'live_state.json')
    live_path.parent.mkdir(parents=True, exist_ok=True)
    latest_real = None
    latest_input = None
    latest_z = None
    station_label = 'PRESENT'  # Verified during startup; updated on station events.
    recovery_confirmation = 0
    recovery_attempt = 0

    def publish_live(event=None):
        # Read-only dashboard: never change detection, Wi-Fi, or firewall here.
        # Do not let an I/O failure in the dashboard disable the security logic.
        display_state = state
        if event in ('DISCONNECTED_INFERRED', 'RECONNECTED_INFERRED', 'UNBLOCK'):
            display_state = {'UNBLOCK': 'UNBLOCKED'}.get(event, event)
        elif event == 'RECOVERY_CHECK_FAILED':
            display_state = 'RETRY'
        data = {
            'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'run_id': run_id, 'device': 'Tapo L520E',
            'ip': args.bulb_ip, 'mac': args.bulb_mac, 'iface': args.iface,
            'state': display_state, 'event': event,
            'real_Bps': latest_real, 'input_Bps': latest_input,
            'z_score': latest_z, 'threshold': THRESHOLD,
            'station': station_label,
            'firewall': 'BLOCKED' if own_chain else 'UNBLOCKED',
            'firewall_mode': 'ENABLED' if args.enable_block else 'DRY_RUN',
            'recovery_confirmation': recovery_confirmation,
            'recovery_required': args.recovery_z_confirmations,
            'recovery_attempt': recovery_attempt,
            'simulation_multiplier': 1.0 if (args.real_block_test or args.real_recovery_test) else args.multiplier,
        }
        tmp = None
        try:
            with tempfile.NamedTemporaryFile('w', encoding='utf-8',
                                             dir=live_path.parent, prefix='.live_',
                                             suffix='.tmp', delete=False) as f:
                tmp = f.name
                json.dump(data, f, ensure_ascii=False)
                f.flush()
                os.fchmod(f.fileno(), 0o644)  # Flask runs without sudo.
            os.replace(tmp, live_path)
        except OSError as exc:
            print(f'LIVE_DASHBOARD_WARNING: {exc}', file=sys.stderr, flush=True)
        finally:
            if tmp and os.path.exists(tmp):
                os.unlink(tmp)
    if args.log is None:
        args.log = str(evdir / f'run_{run_id}_events.csv')

    def append_csv(name, header, row):
        path = evdir / name
        with open(path, 'a', newline='', encoding='utf-8') as f:
            writer_ = csv.writer(f)
            if f.tell() == 0:
                writer_.writerow(header)
            writer_.writerow(row)

    def iso():
        return datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat(timespec='milliseconds')

    def record_event(event, detail=''):
        append_csv('recovery_events.csv', ['run_id','timestamp','elapsed_s','event','detail'],
                   [run_id, iso(), round(time.monotonic()-start, 3), event, detail])

    def record_latency(metric, seconds, note=''):
        append_csv('latency_results.csv', ['run_id','timestamp','metric','seconds','note'],
                   [run_id, iso(), metric, f'{seconds:.6f}', note])

    resource_stop = threading.Event()
    def sample_resources():
        prev_cpu = time.process_time()
        prev_wall = time.monotonic()
        while not resource_stop.is_set():
            now_cpu = time.process_time()
            now_wall = time.monotonic()
            cpu_pct = 100.0 * (now_cpu-prev_cpu) / max(now_wall-prev_wall, 1e-6)
            prev_cpu, prev_wall = now_cpu, now_wall
            rss_kb = ''
            try:
                for line in Path('/proc/self/status').read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        rss_kb = int(line.split()[1]); break
            except OSError:
                pass
            append_csv('resource_usage.csv', ['run_id','timestamp','elapsed_s','state','cpu_percent_one_core','rss_kb'],
                       [run_id, iso(), round(now_wall-start, 3), state, f'{cpu_pct:.3f}', rss_kb])
            resource_stop.wait(1.0)

    resource_thread = threading.Thread(target=sample_resources, daemon=True)
    resource_thread.start()
    run_result = 'INCOMPLETE'
    detected_at = None
    with open(args.log, 'w', newline='', encoding='utf-8') as output:
        writer = csv.writer(output)
        writer.writerow(['timestamp', 'phase', 'state', 'real_Bps', 'input_Bps', 'z', 'detail'])
        def log_event(event, detail=''):
            nonlocal station_label, recovery_confirmation, recovery_attempt
            if event == 'DISCONNECTED_INFERRED':
                station_label = 'DISCONNECTED_INFERRED'
            elif event in ('RECONNECTED_INFERRED', 'RECONNECTED'):
                station_label = 'PRESENT'
            elif event == 'RECOVERY_Z':
                match = re.search(r'confirmation=(\d+)/', detail)
                if match:
                    recovery_confirmation = int(match.group(1))
                station_match = re.search(r'station=(PRESENT|ABSENT)', detail)
                if station_match:
                    station_label = station_match.group(1)
            elif event == 'RECOVERY_CHECK':
                match = re.search(r'Attempt (\d+)', detail)
                if match:
                    recovery_attempt = int(match.group(1))
                recovery_confirmation = 0
            print(f'{event}: {detail}', flush=True)
            writer.writerow([datetime.datetime.now().isoformat(timespec='seconds'), '', event, '', '', '', detail])
            output.flush()
            record_event(event, detail)
            publish_live(event)
        def log_sample(phase, real, scaled, z):
            nonlocal latest_real, latest_input, latest_z
            latest_real, latest_input, latest_z = real, scaled, z
            print(f'{phase:12s} real={real:8.2f} input={scaled:9.2f} Z={z:7.2f} state={state}', flush=True)
            writer.writerow([datetime.datetime.now().isoformat(timespec='seconds'), phase,
                             state, f'{real:.2f}', f'{scaled:.2f}', f'{z:.3f}', ''])
            output.flush()
            append_csv('traffic_windows.csv',
                       ['run_id','timestamp','phase','state','real_Bps','input_Bps','z','predicted_anomaly','ground_truth','false_positive'],
                       [run_id, iso(), phase, state, f'{real:.6f}', f'{scaled:.6f}', f'{z:.6f}',
                        int(z > THRESHOLD), 'NORMAL' if (args.normal_only or phase in ('NORMAL','INJECTION_WAIT')) else 'SIMULATED_ANOMALY' if phase == 'INJECTION' else 'OTHER',
                        int((args.normal_only or phase in ('NORMAL','INJECTION_WAIT')) and z > THRESHOLD)])
            publish_live()

        try:
            sniffer.start()
            log_event('START', f'run_id={run_id} ip={args.bulb_ip} mac={args.bulb_mac} iface={args.iface} '
                                 f'firewall={"ENABLED" if args.enable_block else "DRY RUN"}')
            if args.real_block_test:
                log_event('REAL_BLOCK_TEST', 'NO INJECTION: real_Bps used for Z; BLOCK on real Z > 4; stops after BLOCK')
            elif args.real_recovery_test:
                log_event('REAL_RECOVERY_TEST', 'NO INJECTION: real_Bps used for Z; real Z > 4 triggers BLOCK then fail-closed RECOVERY')
            else:
                log_event('NOTICE', 'xN changes Z-score input only; no real attack traffic is generated')
            log_event('NOTICE', 'MAC rule matches routed IPv4 source MAC; return uses destination IP; same-AP isolation not guaranteed')
            log_event('NOTICE', 'Wi-Fi link loss/rejoin is not proof of clean boot')
            log_event('FIREWALL_POLICY', 'FAIL-CLOSED: blocked rules persist after Ctrl+C/errors; manual unblock required')
            if args.normal_only:
                state = 'NORMAL_EVALUATION'
                log_event('NORMAL_EVALUATION_START', f'duration={args.normal_duration}s; injection disabled')
                end_normal = time.monotonic() + args.normal_duration
                while time.monotonic() < end_normal:
                    time.sleep(min(args.window, max(0.0, end_normal - time.monotonic())))
                    now = time.monotonic()
                    with lock:
                        current_bytes = byte_count
                    real = (current_bytes-last_bytes)/max(now-last_tick, 0.001)
                    last_bytes, last_tick = current_bytes, now
                    z = (real-MU)/SIGMA
                    log_sample('NORMAL', real, real, z)
                run_result = 'NORMAL_COMPLETE'
                log_event('NORMAL_EVALUATION_COMPLETE', 'No simulated injection or block was performed')
                return
            while True:
                time.sleep(args.window)
                now = time.monotonic()
                with lock:
                    current_bytes = byte_count
                real = (current_bytes - last_bytes) / max(now - last_tick, 0.001)
                last_bytes, last_tick = current_bytes, now
                elapsed = now - start
                if (args.real_block_test or args.real_recovery_test) and elapsed >= args.warmup + args.real_test_duration:
                    run_result = 'REAL_TEST_NO_BLOCK'
                    state = 'NORMAL'
                    log_event('REAL_TEST_COMPLETE', 'No real Z > 4 after warmup within test duration; no BLOCK')
                    return
                if args.real_block_test or args.real_recovery_test or elapsed < args.warmup:
                    phase = 'NORMAL'
                elif injection_started_at is None:
                    if injection_wait_started_at is None:
                        injection_wait_started_at = now
                        log_event('INJECTION_WAIT',
                                  f'Waiting for real_Bps > {args.injection_min_real:.2f}; '
                                  f'timeout={args.injection_wait_timeout:.1f}s')
                    if real > args.injection_min_real:
                        injection_started_at = now
                        phase = 'INJECTION'
                        log_event('INJECTION_START',
                                  f'real_Bps={real:.2f} > {args.injection_min_real:.2f}; '
                                  f'multiplier=x{args.multiplier:g}')
                    else:
                        phase = 'INJECTION_WAIT'
                elif now - injection_started_at < args.inject:
                    phase = 'INJECTION'
                else:
                    phase = 'POST_INJECTION'
                scaled = real * args.multiplier if phase == 'INJECTION' else real
                z = (scaled - MU) / SIGMA
                log_sample(phase, real, scaled, z)
                if ((phase == 'INJECTION') or
                    ((args.real_block_test or args.real_recovery_test) and elapsed >= args.warmup)) and z > THRESHOLD:
                    state = 'ANOMALY'
                    detected_at = time.monotonic()
                    if injection_started_at is not None:
                        record_latency('injection_to_detection', detected_at-injection_started_at, 'Software xN injection; window-aligned start')
                    log_event('ANOMALY', f'Z={z:.2f} > {THRESHOLD}')
                    if args.enable_block:
                        install_block(args.bulb_ip, args.bulb_mac, args.iface)
                        own_chain = True
                        blocked_at = time.monotonic()
                        if detected_at is not None:
                            record_latency('detection_to_block', blocked_at-detected_at, 'iptables commands returned successfully')
                        if injection_started_at is not None:
                            record_latency('injection_to_block', blocked_at-injection_started_at, 'Software xN injection')
                        state = 'BLOCKED'
                        log_event('BLOCKED', f'iptables FORWARD: source MAC={args.bulb_mac} on {args.iface}; return traffic to IP={args.bulb_ip}')
                        if args.real_block_test:
                            run_result = 'REAL_TEST_BLOCKED'
                            log_event('REAL_TEST_STOP', 'Firewall remains BLOCKED for verification; recovery not attempted')
                            return
                    else:
                        state = 'BLOCK_SIMULATED'
                        log_event('BLOCK_SIMULATED', 'No firewall rule installed')
                    break
                if (phase == 'INJECTION_WAIT' and
                        now - injection_wait_started_at >= args.injection_wait_timeout):
                    run_result = 'INJECTION_WAIT_TIMEOUT'
                    state = 'INJECTION_WAIT_TIMEOUT'
                    log_event(state, 'No qualifying real traffic detected; no injection or block')
                    return
                if phase == 'POST_INJECTION':
                    run_result = 'NO_ANOMALY'
                    state = 'NO_ANOMALY'
                    log_event('NO_ANOMALY', 'Injection ended without Z > 4')
                    return

            # Wi-Fi link transitions are evidence only; physical power cycle is NOT provable.
            recovery_start = time.monotonic()
            state = 'DISCONNECT_WAIT'
            log_event(state, 'UNPLUG L520E now; detection is automatic (no Enter). '
                             'Station absence is required unless --allow-idle-inference is enabled')
            unplug_seen = wait_for_unplug(
                args.iface, args.bulb_mac, args.disconnect_timeout,
                args.station_confirmations, args.station_poll,
                args.disconnect_idle_ms, log_event, args.allow_idle_inference)
            if not unplug_seen:
                state = 'BLOCKED'
                log_event('DISCONNECT_TIMEOUT', 'No confirmed link loss; keeping BLOCKED and waiting for another observation')
                # Retry observing disconnection instead of exiting and clearing firewall.
                while not unplug_seen:
                    time.sleep(args.retry_delay)
                    log_event('BLOCKED_RETRY', 'Retrying Wi-Fi disconnect observation; firewall remains installed')
                    unplug_seen = wait_for_unplug(
                        args.iface, args.bulb_mac, args.disconnect_timeout,
                        args.station_confirmations, args.station_poll,
                        args.disconnect_idle_ms, log_event, args.allow_idle_inference)

            state = 'RECOVERY_WAIT'
            log_event(state, f'Keep L520E unplugged for {args.recovery_wait:.1f}s; firewall stays BLOCKED')
            time.sleep(args.recovery_wait)
            state = 'RECONNECT_WAIT'
            log_event(state, 'PLUG L520E back in now; detecting station activity automatically')
            reconnect_seen = wait_for_replug(
                args.iface, args.bulb_mac, args.reconnect_timeout,
                args.station_confirmations, args.station_poll,
                args.reconnect_fresh_ms, log_event)
            if not reconnect_seen:
                state = 'BLOCKED'
                log_event('RECONNECT_TIMEOUT', 'No confirmed Wi-Fi reconnect; firewall remains installed')
                while not reconnect_seen:
                    time.sleep(args.retry_delay)
                    log_event('BLOCKED_RETRY', 'Retrying Wi-Fi reconnect observation; firewall remains installed')
                    reconnect_seen = wait_for_replug(
                        args.iface, args.bulb_mac, args.reconnect_timeout,
                        args.station_confirmations, args.station_poll,
                        args.reconnect_fresh_ms, log_event)

            state = 'RECONNECTED'
            log_event(state, 'Wi-Fi station active again; firewall remains BLOCKED')
            recovered = False
            attempt = 0
            while not recovered:
                attempt += 1
                state = 'RECOVERY_CHECK'
                log_event(state, f'Attempt {attempt}: REAL unscaled B/s, Z <= {THRESHOLD}, '
                                 f'{args.recovery_z_confirmations} consecutive nonzero windows; '
                                 f'timeout={args.recovery_check_timeout}s')
                with lock:
                    last_bytes = byte_count
                last_tick = time.monotonic()
                deadline = time.monotonic() + args.recovery_check_timeout
                streak = 0
                while time.monotonic() < deadline:
                    time.sleep(min(args.window, max(0.0, deadline - time.monotonic())))
                    now = time.monotonic()
                    with lock:
                        current_bytes = byte_count
                    real = (current_bytes - last_bytes) / max(now - last_tick, 0.001)
                    last_bytes, last_tick = current_bytes, now
                    z = (real - MU) / SIGMA
                    log_sample('RECOVERY_CHECK', real, real, z)
                    present, idle, rx, tx = station_snapshot(args.iface, args.bulb_mac)
                    good = present and real > 0 and z <= THRESHOLD
                    streak = streak + 1 if good else 0
                    log_event('RECOVERY_Z', f'Z={z:.2f}, real_Bps={real:.2f}, '
                                            f'station={"PRESENT" if present else "ABSENT"}, '
                                            f'confirmation={streak}/{args.recovery_z_confirmations}')
                    if streak >= args.recovery_z_confirmations:
                        recovered = True
                        break
                if recovered:
                    break
                state = 'BLOCKED'
                log_event('RECOVERY_CHECK_FAILED', 'FAIL: not enough consecutive valid samples; BLOCKED persists; retry scheduled')
                log_event('BLOCKED', 'Firewall remains installed; next RECOVERY_CHECK after retry delay')
                time.sleep(args.retry_delay)

            log_event('RECOVERY_Z_PASSED', 'Z <= 3 with nonzero real traffic confirmed; now UNBLOCK')
            if own_chain:
                remove_block()
                own_chain = False
                log_event('UNBLOCK', 'iptables rules removed AFTER RECOVERY_CHECK')
                record_latency('block_to_unblock', time.monotonic()-blocked_at, 'Includes manual power cycle and recovery checks')
                record_latency('recovery_stage_to_unblock', time.monotonic()-recovery_start, 'Includes human power cycle time')
            state = 'APP_CHECK'
            log_event(state, 'Test ON/OFF in Tapo app AFTER UNBLOCK; then answer yes/no')
            try:
                answer = input('Can you control the bulb in Tapo app? [y/N]: ').strip().lower()
            except EOFError:
                answer = ''
            if answer in ('y', 'yes'):
                state = 'RECOVERY'
                run_result = 'RECOVERY_SUCCESS'
                log_event(state, 'Z normalized, firewall unblocked, Tapo app control confirmed')
            else:
                state = 'RECOVERY_UNVERIFIED'
                run_result = 'RECOVERY_UNVERIFIED'
                log_event(state, 'Z normalized and unblocked but Tapo control not confirmed')
        except KeyboardInterrupt:
            run_result = 'INTERRUPTED'
            log_event('INTERRUPTED', 'Ctrl+C; firewall remains BLOCKED if installed')
        except Exception as exc:
            run_result = 'ERROR'
            log_event('ERROR', f'{type(exc).__name__}: {exc}; firewall remains BLOCKED if installed')
            raise
        finally:
            try:
                if sniffer.running:
                    sniffer.stop()
            finally:
                if own_chain:
                    log_event('BLOCKED_PERSISTENT', 'Rule retained after exit; manually remove only when safe: sudo iptables -D FORWARD -j L520E_DROP; sudo iptables -F L520E_DROP; sudo iptables -X L520E_DROP')
                log_event('END', f'final_state={state}')
                resource_stop.set()
                resource_thread.join(timeout=3)
                append_csv('run_summary.csv', ['run_id','timestamp','result','final_state','normal_only','window_s','multiplier','mu','sigma','threshold','firewall_persistent','event_log'],
                           [run_id, iso(), run_result, state, int(args.normal_only), args.window, args.multiplier, MU, SIGMA, THRESHOLD, int(own_chain), args.log])


if __name__ == '__main__':
    main()
