import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).resolve().parent / 'runtime' / 'firewall_events.db'

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=10)
    conn.execute('PRAGMA busy_timeout=10000')
    return conn

def init_db():
    with connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS firewall_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            device_ip TEXT NOT NULL,
            device_mac TEXT NOT NULL,
            action TEXT NOT NULL CHECK(action IN ('BLOCK','UNBLOCK')),
            state TEXT NOT NULL,
            detail TEXT NOT NULL
        )""")

def add_event(device_ip, device_mac, action, state, detail):
    init_db()
    with connect() as conn:
        conn.execute('INSERT INTO firewall_events (timestamp,device_ip,device_mac,action,state,detail) VALUES (?,?,?,?,?,?)',
                     (datetime.now().astimezone().isoformat(timespec='seconds'),device_ip,device_mac,action,state,detail))
