#!/usr/bin/env python3
"""Summarize L520E evaluation CSVs. Only completed NORMAL runs count for FPR."""
import argparse, csv, statistics
from collections import defaultdict
from pathlib import Path

def rows(path):
    if not path.exists(): return []
    with path.open(newline='', encoding='utf-8') as f: return list(csv.DictReader(f))

def describe(values):
    if not values: return 'N/A'
    return f'n={len(values)} mean={statistics.mean(values):.4f} min={min(values):.4f} max={max(values):.4f} median={statistics.median(values):.4f}'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--evaluation-dir',default='evaluation')
    args=ap.parse_args(); d=Path(args.evaluation_dir)
    runs=rows(d/'run_summary.csv'); windows=rows(d/'traffic_windows.csv')
    lat=rows(d/'latency_results.csv'); resources=rows(d/'resource_usage.csv')
    finished={r['run_id'] for r in runs if r['result']=='NORMAL_COMPLETE'}
    normal=[w for w in windows if w['run_id'] in finished and w['phase']=='NORMAL']
    fp=sum(int(w['false_positive']) for w in normal)
    print('=== L520E EVALUATION ===')
    print('Runs:',len(runs),'Completed NORMAL:',len(finished), 'RECOVERY_SUCCESS:',sum(r['result']=='RECOVERY_SUCCESS' for r in runs))
    print('NORMAL windows:',len(normal),'False positives:',fp,
          'FPR:',f'{100*fp/len(normal):.3f}%' if normal else 'N/A')
    bymetric=defaultdict(list)
    for r in lat:
        try: bymetric[r['metric']].append(float(r['seconds']))
        except (ValueError,TypeError): pass
    for metric in ['injection_to_detection','detection_to_block','injection_to_block','block_to_unblock','recovery_stage_to_unblock']:
        print(metric,'seconds:',describe(bymetric[metric]))
    cpus=[]; rss=[]
    for r in resources:
        try: cpus.append(float(r['cpu_percent_one_core']))
        except (ValueError,TypeError): pass
        try: rss.append(float(r['rss_kb'])/1024)
        except (ValueError,TypeError): pass
    print('CPU percent of one core:',describe(cpus))
    print('RSS MiB:',describe(rss))
    print('Note: FPR is per 5-second window, not per packet. Injection latency is software-simulation latency.')
    print('Note: Recovery success fraction is only meaningful if attempted/failed runs are also recorded.')
if __name__=='__main__': main()
