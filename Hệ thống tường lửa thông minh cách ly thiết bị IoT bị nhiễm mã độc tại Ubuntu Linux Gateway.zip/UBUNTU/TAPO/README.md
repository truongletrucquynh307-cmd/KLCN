# IoT Security Gateway – Tapo L520E

Hệ thống thử nghiệm giám sát lưu lượng mạng của bóng đèn thông minh **Tapo L520E** qua **Ubuntu Linux Gateway/Hotspot**, phát hiện bất thường bằng **Z-Score**, cách ly lưu lượng bằng **iptables** và kiểm tra điều kiện phục hồi trước khi gỡ chặn. Dashboard Flask có hai tab **Live Monitoring** và **Evaluation**, hiển thị cảnh báo Firewall và lưu lịch sử BLOCK/UNBLOCK bằng SQLite.

> **Phạm vi:** Môi trường mạng thử nghiệm có quyền quản trị. Chương trình sử dụng *software traffic injection* để đánh giá cơ chế phát hiện, **không phải mã độc hay một cuộc tấn công thực tế**. Nhận diện DISCONNECT/RECONNECT dựa trên quan sát Wi-Fi Station không chứng minh thiết bị đã được khởi động sạch.

## 1. Cấu trúc dự án

```text
iot_gateway_demo/
├── l520e_gateway_MAC_EVALUATION_DASHBOARD.py  # Giám sát, Z-Score, iptables, Recovery, ghi Live/SQLite
├── l520e_gateway_MAC_EVALUATION.py            # Phiên bản chương trình Evaluation khác
├── firewall_history.py                       # Ghi sự kiện BLOCK/UNBLOCK vào SQLite
├── summarize_l520e_evaluation.py             # Tổng hợp số liệu Evaluation
├── dashboard/
│   ├── app.py                                # Flask và API
│   ├── eval_data.py                          # Đọc chi tiết các phiên CSV
│   ├── templates/index.html                  # Hai tab Dashboard
│   └── static/
│       ├── dashboard.js                      # Cập nhật giao diện, cảnh báo 10 giây
│       └── style.css
├── evaluation/                               # CSV các phiên thực nghiệm
├── runtime/
│   ├── live_state.json                       # Trạng thái Live gần nhất
│   └── firewall_events.db                    # SQLite lịch sử Firewall
└── .venv/                                    # Môi trường Python cục bộ (nếu có)
```

## 2. Môi trường và tham số thử nghiệm

| Thành phần | Giá trị trong cấu hình thử nghiệm |
|---|---|
| Gateway | Ubuntu Linux, giao diện Wi-Fi AP `ap0` |
| Thiết bị | TP-Link Tapo L520E |
| IP thiết bị | `10.42.0.21` |
| MAC thiết bị | `20:e1:5d:9f:0b:04` |
| Baseline trung bình (μ) | `39.54 B/s` |
| Độ lệch chuẩn (σ) | `207.80 B/s` |
| Ngưỡng phát hiện | `Z > 3.0` theo mã nguồn |
| Cửa sổ đo | `5 giây` trong các lệnh mẫu |
| iptables chain | `L520E_DROP` |
| Dashboard | `http://127.0.0.1:5000` |

Các địa chỉ và tham số trên là cấu hình của môi trường thử nghiệm trong dự án; cần thay khi dùng thiết bị hoặc mạng khác. Mã nguồn tính Z-Score theo baseline cố định, không tự học lại μ/σ trong mỗi phiên.

## 3. Chuẩn bị

Yêu cầu Ubuntu đã cấu hình Wi-Fi Hotspot trên `ap0`, định tuyến ra Internet và thiết bị Tapo L520E đã kết nối vào Hotspot. Cần có Python 3, `iptables`, `iw`, Flask và Scapy. Chỉ dùng trong mạng bạn có quyền quản lý.

Tại thư mục dự án:

```bash
cd ~/iot_gateway_demo
python3 -m venv .venv
.venv/bin/python -m pip install flask scapy
mkdir -p evaluation runtime
```

Nếu `.venv` đã có sẵn và hoạt động, không cần tạo lại. Việc cấu hình Hotspot/NAT phụ thuộc máy Ubuntu; dự án không tự cấu hình toàn bộ hạ tầng mạng.

## 4. Chạy Dashboard

Mở **Terminal 1**:

```bash
cd ~/iot_gateway_demo
.venv/bin/python dashboard/app.py
```

Truy cập **http://127.0.0.1:5000** trên chính Gateway. Flask chỉ lắng nghe `127.0.0.1:5000` theo cấu hình trong `dashboard/app.py`.

### Tab Live Monitoring

- Hiển thị State, Firewall, Real traffic (B/s), Z-Score, thông tin thiết bị và Recovery.
- Đọc `runtime/live_state.json` qua `/api/live`, làm mới giao diện mỗi 2 giây.
- Hiển thị thông báo **BLOCK màu đỏ** hoặc **UNBLOCK màu xanh** từ sự kiện SQLite. Cả hai tự ẩn sau **10 giây tính từ thời điểm ghi sự kiện**; cảnh báo biến mất **không có nghĩa** Firewall đã được gỡ chặn.
- Hiển thị bảng **Lịch sử BLOCK/UNBLOCK** và liên kết **Xuất CSV**.

### Tab Evaluation

- Đọc kết quả trong `evaluation/` qua script `summarize_l520e_evaluation.py`.
- Hiển thị KPI, đồ thị độ trễ/tài nguyên, danh sách phiên và chi tiết theo `run_id`.
- Tab này đọc dữ liệu Evaluation hiện có; không cần xóa hay tạo lại CSV khi cập nhật Dashboard.

## 5. Chạy giám sát NORMAL (không Injection, không BLOCK)

Mở **Terminal 2**:

```bash
cd ~/iot_gateway_demo
sudo .venv/bin/python l520e_gateway_MAC_EVALUATION_DASHBOARD.py \
  --iface ap0 \
  --bulb-ip 10.42.0.21 \
  --bulb-mac 20:e1:5d:9f:0b:04 \
  --window 5 \
  --normal-only \
  --normal-duration 1800 \
  --evaluation-dir /home/ubuntu/iot_gateway_demo/evaluation
```

Phiên này thu thập lưu lượng bình thường trong 30 phút, phục vụ tính **False Positive Rate (FPR)**. Đường dẫn `/home/ubuntu/...` giả định tài khoản Ubuntu là `ubuntu`; nếu khác, thay bằng đường dẫn thực tế. `--normal-only` không kích hoạt Injection, BLOCK hay Recovery.

## 6. Chạy phiên Injection – BLOCK – Recovery

**Chỉ chạy khi đã chuẩn bị môi trường thử nghiệm và biết cách kiểm tra quy tắc Firewall.** Mở Terminal 2:

```bash
cd ~/iot_gateway_demo
sudo .venv/bin/python l520e_gateway_MAC_EVALUATION_DASHBOARD.py \
  --iface ap0 \
  --bulb-ip 10.42.0.21 \
  --bulb-mac 20:e1:5d:9f:0b:04 \
  --warmup 30 \
  --inject 40 \
  --multiplier 10 \
  --window 5 \
  --injection-min-real 66.3 \
  --injection-wait-timeout 120 \
  --disconnect-timeout 90 \
  --disconnect-idle-ms 15000 \
  --recovery-wait 10 \
  --reconnect-timeout 120 \
  --reconnect-fresh-ms 4000 \
  --recovery-check-timeout 90 \
  --recovery-z-confirmations 3 \
  --station-confirmations 3 \
  --station-poll 2 \
  --retry-delay 10 \
  --allow-idle-inference \
  --enable-block \
  --evaluation-dir /home/ubuntu/iot_gateway_demo/evaluation
```

Quy trình dự kiến:

1. Thu thập cửa sổ lưu lượng và tính Z-Score.
2. Injection phần mềm tạo giá trị lưu lượng đầu vào để kiểm thử phát hiện.
3. Khi vượt ngưỡng, Gateway kích hoạt iptables `L520E_DROP` và ghi sự kiện `BLOCK` nếu lệnh thành công.
4. Chờ dấu hiệu DISCONNECT/RECONNECT qua Wi-Fi Station.
5. Kiểm tra Recovery với **3 cửa sổ liên tiếp** có lưu lượng thực khác 0 và Z-Score đạt điều kiện.
6. Khi đạt điều kiện, Gateway gỡ chặn, ghi `UNBLOCK`, sau đó yêu cầu xác nhận điều khiển bóng đèn qua ứng dụng Tapo.
7. Nếu Recovery không đạt điều kiện hoặc timeout, Gateway tiếp tục giữ chặn và chuyển sang RETRY (**fail-closed**).

**Quan trọng:** `--enable-block` tác động lên Firewall thật. Không chạy nhiều phiên đồng thời trên cùng chain. Khi nhấn `Ctrl+C`, quy tắc BLOCK có thể **vẫn tồn tại**; đừng mặc định việc thoát chương trình đã mở chặn.

## 7. SQLite – Lịch sử BLOCK/UNBLOCK

Mô-đun `firewall_history.py` tạo bảng `firewall_events` trong:

```text
runtime/firewall_events.db
```

Các trường gồm `id`, `timestamp`, `device_ip`, `device_mac`, `action`, `state`, `detail`. Chỉ có hai hành động lịch sử Firewall là `BLOCK` và `UNBLOCK`. Chương trình ghi sự kiện sau thao tác iptables thành công; nếu ghi SQLite lỗi, lỗi được báo trên Terminal để người vận hành kiểm tra.

Các API Flask:

| Endpoint | Chức năng |
|---|---|
| `/api/live` | Trạng thái giám sát mới nhất |
| `/api/evaluation` | Tổng hợp Evaluation |
| `/api/evaluation/detail` | Chi tiết các phiên Evaluation |
| `/api/firewall-events` | Tối đa 100 sự kiện Firewall gần nhất, dạng JSON |
| `/api/firewall-events/export` | Xuất toàn bộ lịch sử Firewall thành `firewall_events.csv` |

Có thể kiểm tra số bản ghi SQLite:

```bash
cd ~/iot_gateway_demo
python3 - <<'PY'
from firewall_history import connect
with connect() as conn:
    rows = conn.execute(
        'SELECT timestamp, action, device_ip, detail '
        'FROM firewall_events ORDER BY id DESC LIMIT 10'
    ).fetchall()
for row in rows:
    print(*row)
PY
```

Nếu chưa từng chạy phiên BLOCK/UNBLOCK từ khi tích hợp SQLite, bảng lịch sử có thể rỗng. Các sự kiện CSV cũ **không được tự động nhập** vào SQLite.

## 8. Tổng hợp kết quả Evaluation

```bash
cd ~/iot_gateway_demo
.venv/bin/python summarize_l520e_evaluation.py \
  --evaluation-dir /home/ubuntu/iot_gateway_demo/evaluation
```

Các nhóm chỉ số gồm số phiên, số phiên NORMAL, Recovery thành công, số cửa sổ NORMAL, false positives, FPR, độ trễ Injection → Detection, Detection → BLOCK, Injection → BLOCK, BLOCK → UNBLOCK, CPU và RAM.

**Cách diễn giải:**

- FPR được tính **theo cửa sổ thời gian**, không phải theo từng gói tin.
- Độ trễ Injection → Detection/BLOCK là **độ trễ của mô phỏng phần mềm**, không phải thời gian từ khi thiết bị bị nhiễm mã độc thật.
- `RECOVERY_SUCCESS` là số phiên ghi nhận thành công; không được suy ra tỷ lệ thành công nếu thiếu số lần thử/thất bại.
- Thống kê tài nguyên CPU/RAM phản ánh tiến trình chạy trong điều kiện thử nghiệm.

## 9. Kiểm thử Recovery thất bại (có chủ đích)

Để đánh giá nhánh `RECOVERY_CHECK_FAILED` trong mạng thử nghiệm, có thể dùng cấu hình cố tình không thể đủ số cửa sổ xác nhận trong timeout:

```text
--recovery-check-timeout 20 --recovery-z-confirmations 100
```

Các tham số này **chỉ dùng để kiểm thử nhánh FAIL**, không dùng thay cho cấu hình Recovery bình thường hoặc để tính tỷ lệ thành công thực tế. Khi FAIL, Firewall tiếp tục BLOCKED và chương trình thử lại theo `--retry-delay`.

## 10. Kiểm tra và xử lý Firewall an toàn

Kiểm tra trước khi chạy hoặc sau khi dừng chương trình:

```bash
sudo iptables -S FORWARD
sudo iptables -S L520E_DROP
```

Nếu chain còn tồn tại, hãy xác minh thiết bị, các quy tắc và tình trạng mạng trước khi can thiệp. **Không dùng `iptables -F` toàn hệ thống** vì có thể ảnh hưởng các quy tắc bảo mật/NAT khác. Chỉ gỡ các quy tắc thuộc dự án khi bạn đã xác nhận an toàn và chủ động muốn mở chặn.

## 11. Dữ liệu, sao lưu và bảo mật

- `evaluation/`: dữ liệu thực nghiệm; giữ lại khi cập nhật code/Dashboard.
- `runtime/firewall_events.db`: lịch sử BLOCK/UNBLOCK; nên sao lưu trước khi chuyển máy hoặc làm lại thử nghiệm.
- `runtime/live_state.json`: trạng thái gần nhất; không phải lịch sử đầy đủ.
- `.venv/`, `__pycache__/`: thành phần môi trường/cache, không cần đưa vào gói mã nguồn phát hành.
- Không đưa thông tin mạng nội bộ, nhật ký nhạy cảm hoặc file SQLite lên kho công khai khi chưa rà soát.

## 12. Giới hạn của hệ thống

- Chỉ kiểm thử trên cấu hình thiết bị và mạng nêu trên; chưa chứng minh hiệu quả cho mọi loại thiết bị IoT.
- Phát hiện dựa trên Z-Score của lưu lượng B/s, không nhận diện trực tiếp mã độc hoặc xác nhận nguyên nhân bất thường.
- Dấu hiệu Wi-Fi Station và hoạt động lại sau khi cắm điện **không đủ để chứng minh thiết bị đã sạch mã độc**.
- SQLite phục vụ lưu sự kiện Firewall; các thống kê Evaluation vẫn được lưu trong CSV.
- Flask được cấu hình phục vụ cục bộ, không phải một hệ thống quản trị công khai có xác thực.

---

**Tóm tắt:** Gateway giám sát Tapo L520E → Z-Score phát hiện bất thường → iptables BLOCK → kiểm tra Recovery → UNBLOCK khi đạt điều kiện; Dashboard cung cấp quan sát thời gian gần thực, cảnh báo 10 giây, lịch sử SQLite và báo cáo CSV.
