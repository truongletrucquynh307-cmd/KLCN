#!/usr/bin/env python3
"""Bao cao Evaluation Tapo tu CSV: chi DOC, in Terminal, khong gioi han so phien.

Phan loai dua tren dau vet su kien, khong suy doan muc dich cua nguoi thu.
NORMAL: normal_only=1.
RECOVERY: co su kien RECOVERY_CHECK / UNBLOCK / RECOVERY_Z_PASSED / RECOVERY_CHECK_FAILED.
BLOCK: co BLOCKED nhung chua co dau vet RECOVERY_CHECK.
KHAC: khong du dau vet de phan loai.
"""
import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean

FILES = ('run_summary.csv', 'traffic_windows.csv', 'recovery_events.csv',
         'latency_results.csv', 'resource_usage.csv')


def read(root, file):
    p = root / file
    if not p.exists():
        print(f'[CANH BAO] Thieu {file}: bang lien quan co the khong day du.')
        return []
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def group_by_run(rows):
    out = defaultdict(list)
    for r in rows:
        if r.get('run_id'):
            out[r['run_id']].append(r)
    return out


def num(v):
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def f(v, n=2):
    return '-' if v is None else f'{v:.{n}f}'


def avg(items):
    nums = [v for v in items if v is not None]
    return mean(nums) if nums else None


def table(columns, records):
    if not records:
        print('  (Khong co phien nao)')
        return
    lines = [[str(a) for a in row] for row in records]
    widths = [max(len(name), *(len(row[i]) for row in lines)) for i, name in enumerate(columns)]
    def print_row(row):
        print('  '.join(str(x).ljust(w) for x, w in zip(row, widths)))
    print_row(columns)
    print('  '.join('-' * w for w in widths))
    for row in lines:
        print_row(row)


def main():
    p = argparse.ArgumentParser(description='Loc TAT CA phien Evaluation theo NORMAL/BLOCK/RECOVERY; chi hien Terminal.')
    p.add_argument('--dir', default=str(Path.home() / 'iot_gateway_demo' / 'evaluation'),
                   help='Thu muc CSV Evaluation; mac dinh ~/iot_gateway_demo/evaluation')
    p.add_argument('--window', type=float, help='Tuy chon: chi xem phien 5s (--window 5) hoac 1s (--window 1); mac dinh xem TAT CA')
    p.add_argument('--group', choices=['all', 'normal', 'block', 'recovery', 'other', 'summary'], default='all')
    p.add_argument('--list', action='store_true', help='In danh sach moi run_id va nhom tu dong phan loai')
    args = p.parse_args()
    root = Path(args.dir).expanduser()
    if not root.is_dir():
        p.error(f'Khong tim thay thu muc: {root}')

    summary = read(root, 'run_summary.csv')
    tw = group_by_run(read(root, 'traffic_windows.csv'))
    events = group_by_run(read(root, 'recovery_events.csv'))
    latency = group_by_run(read(root, 'latency_results.csv'))
    resources = group_by_run(read(root, 'resource_usage.csv'))
    # Duplicate IDs: keep last summary row only.
    runs = {r['run_id']: r for r in summary if r.get('run_id')}
    runs = sorted(runs.values(), key=lambda r: (r.get('timestamp', ''), r['run_id']))
    if args.window is not None:
        runs = [r for r in runs if num(r.get('window_s')) == args.window]

    def evset(rid):
        return {r.get('event', '').strip() for r in events[rid]}

    def classify(r):
        if r.get('normal_only', '').strip().lower() in ('1', 'true', 'yes'):
            return 'NORMAL'
        e = evset(r['run_id'])
        if e & {'RECOVERY_CHECK', 'RECOVERY_Z_PASSED', 'RECOVERY_CHECK_FAILED', 'UNBLOCK', 'UNBLOCKED'}:
            return 'RECOVERY'
        if 'BLOCKED' in e:
            return 'BLOCK'
        return 'KHAC'

    groups = defaultdict(list)
    for r in runs:
        groups[classify(r)].append(r)

    def metrics(rid):
        vals = defaultdict(list)
        for r in latency[rid]:
            s = num(r.get('seconds'))
            if s is not None:
                vals[r.get('metric', '')].append(s)
        return {k: v[-1] for k, v in vals.items()}

    def usage(rid):
        cpu = avg(num(x.get('cpu_percent_one_core')) for x in resources[rid])
        ram = avg(num(x.get('rss_kb')) for x in resources[rid])
        return cpu, (ram / 1024 if ram is not None else None)

    print('=' * 100)
    print('TAPO L520E - BAO CAO EVALUATION THEO NHOM | CHI DOC CSV')
    print('Nguon:', root)
    print('Cua so:', 'TAT CA' if args.window is None else f'{args.window:g} giay')
    print('Tong phien:', len(runs), '| NORMAL:', len(groups['NORMAL']), '| BLOCK:', len(groups['BLOCK']),
          '| RECOVERY:', len(groups['RECOVERY']), '| KHAC:', len(groups['KHAC']))
    print('=' * 100)

    if args.list or args.group == 'summary':
        print('\n[0] DANH SACH TOAN BO PHIEN')
        table(['#', 'run_id', 'Nhom', 'result', 'final_state'], [
            (i, r['run_id'], classify(r), r.get('result', '-'), r.get('final_state', '-'))
            for i, r in enumerate(runs, 1)])
        if args.list:
            return

    if args.group in ('all', 'normal'):
        print('\n[1] NORMAL | SO CUA SO, FALSE POSITIVE RATE, CPU/RAM')
        rows = []; total = false = 0
        for i, r in enumerate(groups['NORMAL'], 1):
            rid = r['run_id']
            windows = [w for w in tw[rid] if w.get('ground_truth', '').strip() == 'NORMAL']
            fp = sum(w.get('false_positive', '').strip().lower() in ('1', 'true') for w in windows)
            total += len(windows); false += fp
            cpu, ram = usage(rid)
            rows.append((f'N{i:02}', rid,
                         f(fp * 100 / len(windows), 2) + '%' if windows else '-', f(cpu), f(ram), r.get('result', '-')))
        table(['Phien', 'run_id', 'FPR', 'CPU%', 'RAM(MB)', 'Ket qua'], rows)
        print('FPR gop NORMAL:', f'{false}/{total} = {f(false * 100 / total)}%' if total else 'Khong co cua so NORMAL')

    if args.group in ('all', 'block'):
        print('\n[2] BLOCK | PHAT HIEN VA CACH LY (KHONG CO RECOVERY_CHECK)')
        rows = []
        for i, r in enumerate(groups['BLOCK'], 1):
            rid = r['run_id']; m = metrics(rid); cpu, ram = usage(rid)
            rows.append((f'B{i:02}', rid,
                         f(m.get('injection_to_detection'), 3), f(m.get('detection_to_block'), 3),
                         f(m.get('injection_to_block'), 3), f(cpu), f(ram), r.get('result', '-')))
        table(['Phien', 'run_id', 'I->D(s)', 'D->B(s)', 'I->B(s)', 'CPU%', 'RAM(MB)', 'Ket qua'], rows)
    
    if args.group in ('all', 'recovery'):
        print('\n[3] UNBLOCK / RECOVERY | DA VAO KIEM TRA PHUC HOI HOAC DA GO CHAN')
        rows = []
        for i, r in enumerate(groups['RECOVERY'], 1):
            rid = r['run_id']; m = metrics(rid); cpu, ram = usage(rid)
            rows.append((f'R{i:02}', rid,
                         f(m.get('injection_to_detection'), 3), f(m.get('detection_to_block'), 3),
                         f(m.get('injection_to_block'), 3), f(m.get('block_to_unblock'), 3),
                         f(cpu), f(ram), r.get('result', '-')))
        table(['Phien', 'run_id', 'I->D(s)', 'D->B(s)', 'I->B(s)', 'B->U(s)', 'CPU%', 'RAM(MB)', 'Ket qua'], rows)
    
    if args.group in ('all', 'other'):
        print('\n[4] KHAC | CHUA DU SU KIEN DE GAN NHOM BLOCK/RECOVERY')
        table(['#', 'run_id', 'Ket qua', 'Trang thai'], [
            (i, r['run_id'], r.get('result', '-'), r.get('final_state', '-'))
            for i, r in enumerate(groups['KHAC'], 1)])

    if args.group in ('all', 'summary'):
        print('\n[5] TONG HOP | TOAN BO PHIEN')
        rows = []
        for i, r in enumerate(runs, 1):
            rid = r['run_id']; cpu, ram = usage(rid)
            rows.append((i, rid, classify(r), f(cpu), f(ram), r.get('result', '-')))
        table(['#', 'run_id', 'Nhom', 'CPU%', 'RAM(MB)', 'Ket qua'], rows)



if __name__ == '__main__':
    main()
