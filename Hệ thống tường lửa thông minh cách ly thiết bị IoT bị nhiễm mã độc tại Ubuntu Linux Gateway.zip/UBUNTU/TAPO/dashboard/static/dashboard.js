const $ = id => document.getElementById(id);

const fmt = (x, d = 3) =>
  typeof x === 'number' && Number.isFinite(x)
    ? x.toLocaleString('vi-VN', { maximumFractionDigits: d })
    : '—';

const safe = s => String(s ?? '—');

let detailData = null;

// ============================================================
// TAB NAVIGATION
// ============================================================

for (const b of document.querySelectorAll('nav button')) {
  b.addEventListener('click', () => {
    document.querySelectorAll('nav button').forEach(x => {
      x.classList.remove('selected');
    });

    b.classList.add('selected');

    $('live').hidden = b.dataset.tab !== 'live';
    $('evaluation').hidden = b.dataset.tab !== 'evaluation';

    if (b.dataset.tab === 'evaluation') {
      loadEvaluation();
    }
  });
}

function txt(id, value) {
  const element = $(id);
  if (element) {
    element.textContent = value ?? '—';
  }
}

// ============================================================
// LIVE MONITORING
// ============================================================

const LIVE_LABELS = {
  NORMAL_EVALUATION: 'NORMAL',
  NORMAL: 'NORMAL',
  ANOMALY: 'ANOMALY',
  BLOCKED: 'BLOCKED',
  BLOCK_SIMULATED: 'BLOCKED (SIM)',
  DISCONNECT_WAIT: 'BLOCKED',
  RECOVERY_WAIT: 'DISCONNECT',
  DISCONNECTED_INFERRED: 'DISCONNECTED',
  RECONNECT_WAIT: 'DISCONNECTED',
  RECONNECTED_INFERRED: 'RECONNECTED',
  RECONNECTED: 'RECONNECTED',
  RECOVERY_CHECK: 'RECOVERY_CHECK',
  RECOVERY: 'RECOVERY',
  RECOVERY_UNVERIFIED: 'RECOVERY',
  APP_CHECK: 'UNBLOCK',
  RETRY: 'RETRY',
  UNBLOCKED: 'UNBLOCK'
};

function liveLabel(state) {
  return LIVE_LABELS[state] || state || '—';
}

function liveStation(state) {
  if (state === 'DISCONNECTED_INFERRED' || state === 'ABSENT') {
    return 'DISCONNECT';
  }

  if (state === 'PRESENT') {
    return 'PRESENT';
  }

  return state || '—';
}

function liveNum(value) {
  const number = Number(value);

  return value === null ||
    value === undefined ||
    !Number.isFinite(number)
    ? '—'
    : number.toLocaleString('vi-VN', {
        maximumFractionDigits: 2
      });
}

async function loadLive() {
  try {
    const response = await fetch('/api/live', {
      cache: 'no-store'
    });

    if (!response.ok) {
      throw Error('HTTP ' + response.status);
    }

    const data = await response.json();
    const state = data.state || {};
    const online = !!data.online;

    txt('connection', online ? 'LIVE' : 'OFFLINE');

    $('connection').className =
      'pill' + (online ? ' online' : '');

    txt(
      'state',
      online ? liveLabel(state.state) : 'OFFLINE'
    );

    txt(
      'firewall',
      online ? state.firewall : '—'
    );

    txt(
      'real',
      online && state.real_Bps != null
        ? liveNum(state.real_Bps) + ' B/s'
        : '—'
    );

    txt(
      'z',
      online ? liveNum(state.z_score) : '—'
    );

    txt(
      'details',
      online
        ? `IP: ${state.ip || '—'} | MAC: ${state.mac || '—'} | Station: ${liveStation(state.station)} | Recovery: ${state.recovery_confirmation ?? '—'}/${state.recovery_required ?? '—'}`
        : (data.reason || 'Không có dữ liệu mới.')
    );

  } catch (error) {
    txt('connection', 'API ERROR');
    txt('state', 'OFFLINE');
    txt('details', String(error));
  }
}

// ============================================================
// EVALUATION - METRICS
// ============================================================

function metric(raw, key) {
  const value = raw?.[key] || '';
  const match = value.match(/\bmean=([\d.]+)/);

  return match ? Number(match[1]) : null;
}

function makeKpi(label, value, sub = '') {
  const article = document.createElement('article');
  const small = document.createElement('small');
  const strong = document.createElement('strong');
  const paragraph = document.createElement('p');

  small.textContent = label;
  strong.textContent = value;
  paragraph.textContent = sub;
  paragraph.className = 'hint';

  article.append(small, strong, paragraph);

  return article;
}

function barChart(id, items) {
  const element = $(id);
  element.replaceChildren();

  const max = Math.max(
    0.001,
    ...items.map(item => item.value || 0)
  );

  for (const item of items) {
    const row = document.createElement('div');
    row.className = 'bar-row';

    const label = document.createElement('div');
    label.className = 'bar-label';
    label.textContent = item.label;

    const track = document.createElement('div');
    track.className = 'bar-track';

    const fill = document.createElement('div');
    fill.className = 'bar-fill';

    fill.style.width =
      `${Math.max(0, Math.min(100, (item.value || 0) / max * 100))}%`;

    track.append(fill);

    const value = document.createElement('span');

    value.textContent =
      item.value == null
        ? '—'
        : fmt(item.value, 3) + (item.unit || '');

    row.append(label, track, value);
    element.append(row);
  }
}

function renderKpis(metrics) {
  const container = $('kpis');
  container.replaceChildren();

  const runs =
    (metrics.Runs || '').match(/^\d+/)?.[0] || '—';

  const normal =
    (metrics.Runs || '').match(
      /Completed NORMAL:\s*(\d+)/
    )?.[1] || '—';

  const recovery =
    (metrics.Runs || '').match(
      /RECOVERY_SUCCESS:\s*(\d+)/
    )?.[1] || '—';

  const fpr =
    (metrics['NORMAL windows'] || '').match(
      /FPR:\s*([\d.]+%)/
    )?.[1] || '—';

  const falsePositives =
    (metrics['NORMAL windows'] || '').match(
      /False positives:\s*(\d+)/
    )?.[1] || '—';

  const kpis = [
    ['Tổng số phiên', runs, ''],

    [
      'NORMAL hoàn thành',
      normal,
      'FPR theo cửa sổ 5 giây'
    ],

    [
      'FPR',
      fpr,
      `${falsePositives} false positives`
    ],

    [
      'Recovery SUCCESS',
      recovery,
      'Chỉ các phiên được ghi nhận PASS'
    ],

    [
      'Detection → BLOCK',
      fmt(
        metric(metrics, 'detection_to_block seconds') * 1000,
        2
      ) + ' ms',
      'Độ trễ xử lý sau khi có cửa sổ'
    ],

    [
      'BLOCK → UNBLOCK',
      fmt(
        metric(metrics, 'block_to_unblock seconds'),
        2
      ) + ' s',
      'Bao gồm chờ ngắt/cắm và tái kết nối'
    ],

    [
      'CPU trung bình',
      fmt(
        metric(metrics, 'CPU percent of one core'),
        4
      ) + '%',
      'Theo một lõi CPU'
    ],

    [
      'RAM trung bình',
      fmt(
        metric(metrics, 'RSS MiB'),
        2
      ) + ' MiB',
      'RSS của tiến trình'
    ]
  ];

  for (const [label, value, sub] of kpis) {
    container.append(makeKpi(label, value, sub));
  }

  barChart('latency-chart', [
    {
      label: 'Injection → Detection',
      value:
        metric(metrics, 'injection_to_detection seconds') * 1000,
      unit: ' ms'
    },
    {
      label: 'Detection → BLOCK',
      value:
        metric(metrics, 'detection_to_block seconds') * 1000,
      unit: ' ms'
    },
    {
      label: 'Injection → BLOCK',
      value:
        metric(metrics, 'injection_to_block seconds') * 1000,
      unit: ' ms'
    }
  ]);

  barChart('resources-chart', [
    {
      label: 'CPU (%)',
      value: metric(metrics, 'CPU percent of one core'),
      unit: '%'
    },
    {
      label: 'RAM (MiB)',
      value: metric(metrics, 'RSS MiB'),
      unit: ' MiB'
    }
  ]);
}

// ============================================================
// EVALUATION - RUN TABLE
// ============================================================

function cell(row, value) {
  const td = document.createElement('td');
  td.textContent = safe(value);
  row.append(td);
}

function renderRuns() {
  if (!detailData) return;

  const filter = $('run-filter').value.toLowerCase();

  const runs = detailData.runs.filter(item =>
    JSON.stringify(item).toLowerCase().includes(filter)
  );

  txt(
    'run-count',
    `${runs.length}/${detailData.run_count} phiên có run_id`
  );

  const columns = [
    ['run_id', 'run_id'],
    ['real_Bps_mean', 'Traffic TB (B/s)'],
    ['z_max', 'Z tối đa'],
    ['detection_to_block_mean_s', 'Detect → Block (ms)'],
    ['cpu_mean_percent', 'CPU TB (%)'],
    ['rss_mean_mib', 'RSS TB (MiB)'],
    ['events', 'Recovery events']
  ];

  const head = $('runs-head');
  const body = $('runs-body');

  head.replaceChildren();
  body.replaceChildren();

  const headerRow = document.createElement('tr');

  for (const [, name] of columns) {
    const th = document.createElement('th');
    th.textContent = name;
    headerRow.append(th);
  }

  head.append(headerRow);

  for (const item of runs) {
    const row = document.createElement('tr');
    row.tabIndex = 0;

    const values = [
      item.run_id,
      fmt(item.stats.real_Bps_mean),
      fmt(item.stats.z_max),

      item.stats.detection_to_block_mean_s == null
        ? '—'
        : fmt(
            item.stats.detection_to_block_mean_s * 1000
          ),

      fmt(item.stats.cpu_mean_percent),
      fmt(item.stats.rss_mean_mib),

      item.sources['recovery_events.csv'] ?? '—'
    ];

    for (const value of values) {
      cell(row, value);
    }

    row.addEventListener('click', () => showRun(item));

    row.addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        showRun(item);
      }
    });

    body.append(row);
  }

  if (!runs.length) {
    const row = document.createElement('tr');
    const td = document.createElement('td');

    td.colSpan = columns.length;
    td.textContent =
      'Không có run_id phù hợp. Kiểm tra cảnh báo schema CSV bên trên.';

    row.append(td);
    body.append(row);
  }
}

function showRun(item) {
  const element = $('run-detail');

  element.hidden = false;
  element.replaceChildren();

  const heading = document.createElement('h3');
  heading.textContent =
    'Chi tiết run_id: ' + item.run_id;

  element.append(heading);

  const table = document.createElement('table');

  for (const [key, value] of Object.entries(item.summary)) {
    const row = document.createElement('tr');

    cell(row, key);
    cell(row, value);

    table.append(row);
  }

  for (const [key, value] of Object.entries(item.stats)) {
    const row = document.createElement('tr');

    cell(row, key);
    cell(row, fmt(value, 5));

    table.append(row);
  }

  element.append(table);
}

async function loadEvaluation() {
  txt('eval-status', 'Đang đọc CSV…');

  try {
    const [summaryResponse, detailResponse] =
      await Promise.all([
        fetch('/api/evaluation', {
          cache: 'no-store'
        }),

        fetch('/api/evaluation/detail', {
          cache: 'no-store'
        })
      ]);

    const metrics = await summaryResponse.json();
    const details = await detailResponse.json();

    if (!metrics.ok || !details.ok) {
      throw Error(
        metrics.error ||
        details.error ||
        'Không thể tải'
      );
    }

    txt('eval-status', 'Dữ liệu từ CSV hiện có');
    txt('raw', metrics.raw);

    renderKpis(metrics.metrics);

    detailData = details;

    const warnings = $('warnings');
    warnings.replaceChildren();

    for (const warning of details.warnings) {
      const paragraph = document.createElement('p');

      paragraph.className = 'warning';
      paragraph.textContent = warning;

      warnings.append(paragraph);
    }

    renderRuns();

  } catch (error) {
    txt('eval-status', 'Lỗi: ' + error.message);
  }
}

$('refresh-eval').addEventListener('click', loadEvaluation);
$('run-filter').addEventListener('input', renderRuns);

// ============================================================
// FIREWALL HISTORY + 10-SECOND ALERTS
// ============================================================

// BLOCK và UNBLOCK đều chỉ hiển thị cảnh báo trong 10 giây.
// Dữ liệu lịch sử SQLite không bị xóa.

const FIREWALL_ALERT_DURATION_MS = 10000;

let lastFirewallEventId = null;
let firewallAlertTimer = null;

function hideFirewallAlert() {
  const alertBox = $('firewall-alert');

  if (alertBox) {
    alertBox.hidden = true;
  }

  if (firewallAlertTimer !== null) {
    clearTimeout(firewallAlertTimer);
    firewallAlertTimer = null;
  }
}

function displayFirewallAlert(event) {
  const alertBox = $('firewall-alert');

  if (!alertBox || !event) {
    return;
  }

  // Hủy timer cũ nếu có sự kiện mới.
  if (firewallAlertTimer !== null) {
    clearTimeout(firewallAlertTimer);
    firewallAlertTimer = null;
  }

  const isBlock = event.action === 'BLOCK';

  // Thời gian bắt đầu tính từ lúc SQLite ghi sự kiện.
  const eventTime = Date.parse(event.timestamp);

  // Không hiển thị lại sự kiện có timestamp không hợp lệ.
  if (!Number.isFinite(eventTime)) {
    hideFirewallAlert();
    return;
  }

  const elapsed = Date.now() - eventTime;

  const remaining = Math.max(
    0,
    FIREWALL_ALERT_DURATION_MS - elapsed
  );

  // Sự kiện quá 10 giây: ẩn ngay.
  if (remaining <= 0) {
    hideFirewallAlert();
    return;
  }

  txt(
    'firewall-alert-title',
    isBlock
      ? 'CẢNH BÁO: iptables đã BLOCK thiết bị'
      : 'THÔNG BÁO: iptables đã UNBLOCK thiết bị'
  );

  txt(
    'firewall-alert-text',
    `${event.timestamp} · ${event.device_ip} · ${event.detail}`
  );

  // Màu đỏ cho BLOCK, màu xanh cho UNBLOCK.
  alertBox.style.borderColor =
    isBlock ? '#c24141' : '#21845b';

  alertBox.style.background =
    isBlock ? '#fff1f1' : '#eaf8ef';

  alertBox.style.color =
    isBlock ? '#831b1b' : '#14532d';

  alertBox.hidden = false;

  // Tự động ẩn khi đủ 10 giây kể từ sự kiện.
  firewallAlertTimer = setTimeout(() => {
    hideFirewallAlert();
  }, remaining);
}

let firewallSearchActive = false;
let firewallSearchSequence = 0;

function firewallQueryParams() {
  const params = new URLSearchParams();
  const action = $('fw-action').value;
  const ip = $('fw-ip').value.trim();
  const start = $('fw-start').value;
  const end = $('fw-end').value;
  if (action) params.set('action', action);
  if (ip) params.set('ip', ip);
  if (start) params.set('start', start);
  if (end) params.set('end', end);
  return params;
}

function renderFirewallHistory(events, status) {
  const body = $('firewall-history-body');
  if (!body) return;
  body.replaceChildren();
  for (const event of events) {
    const row = document.createElement('tr');
    for (const value of [event.timestamp, event.action, event.device_ip, event.detail]) {
      const td = document.createElement('td');
      td.textContent = value ?? '—';
      row.append(td);
    }
    body.append(row);
  }
  txt('firewall-history-status', status);
}

async function searchFirewallHistory() {
  const sequence = ++firewallSearchSequence;
  firewallSearchActive = true;
  const params = firewallQueryParams();
  $('firewall-export').href = '/api/firewall-events/export' + (params.toString() ? '?' + params : '');
  try {
    const response = await fetch('/api/firewall-events/search?' + params, { cache: 'no-store' });
    const data = await response.json();
    if (!response.ok || !data.ok) throw Error(data.error || 'HTTP ' + response.status);
    if (sequence !== firewallSearchSequence || !firewallSearchActive) return;
    const events = data.events || [];
    renderFirewallHistory(events, `Tìm thấy ${events.length} sự kiện` + (data.truncated ? ' (đang hiển thị tối đa 500; CSV có đầy đủ)' : ''));
  } catch (error) {
    if (sequence === firewallSearchSequence) txt('firewall-history-status', 'Lỗi truy vấn: ' + error.message);
  }
}

$('firewall-search-form').addEventListener('submit', event => {
  event.preventDefault();
  searchFirewallHistory();
});
$('fw-clear').addEventListener('click', () => {
  $('firewall-search-form').reset();
  firewallSearchActive = false;
  ++firewallSearchSequence;
  $('firewall-export').href = '/api/firewall-events/export';
  loadFirewallEvents();
});

async function loadFirewallEvents() {
  try {
    const response = await fetch('/api/firewall-events', {
      cache: 'no-store'
    });

    if (!response.ok) {
      throw Error('HTTP ' + response.status);
    }

    const data = await response.json();

    if (!data.ok) {
      throw Error(data.error || 'API error');
    }

    const events = data.events || [];

    // Filtering is independent of the live 10-second BLOCK/UNBLOCK alerts.
    if (!firewallSearchActive) {
      renderFirewallHistory(events.slice(0, 20), events.length
        ? `Hiển thị ${Math.min(events.length, 20)} sự kiện mới nhất`
        : 'Chưa có sự kiện BLOCK/UNBLOCK trong SQLite.');
    }

    // --------------------------------------------------------
    // BLOCK / UNBLOCK ALERT
    // --------------------------------------------------------

    const latest = events[0];

    if (!latest) {
      hideFirewallAlert();
      return;
    }

    // Chỉ xử lý khi có sự kiện mới.
    if (lastFirewallEventId !== latest.id) {
      lastFirewallEventId = latest.id;

      displayFirewallAlert(latest);
    }

  } catch (error) {
    if (!firewallSearchActive) txt('firewall-history-status', 'Không đọc được lịch sử: ' + error.message);
  }
}

// ============================================================
// INITIALIZATION
// ============================================================

loadLive();
setInterval(loadLive, 2000);

loadFirewallEvents();
setInterval(loadFirewallEvents, 2000);

