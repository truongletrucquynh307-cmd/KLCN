import csv, io, json, os, re, sqlite3, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, jsonify, render_template, Response, request
from eval_data import build_detail

ROOT = Path(os.environ.get('IOT_PROJECT_DIR', str(Path.home() / 'iot_gateway_demo'))).expanduser()
EVAL = ROOT / 'evaluation'
LIVE = ROOT / 'runtime' / 'live_state.json'
SUMMARY = ROOT / 'summarize_l520e_evaluation.py'
FIREWALL_DB = ROOT / 'runtime' / 'firewall_events.db'
app = Flask(__name__)

@app.get('/')
def index():
    return render_template('index.html')

@app.get('/api/evaluation')
def evaluation():
    if not SUMMARY.is_file():
        return jsonify(ok=False, error=f'Không tìm thấy {SUMMARY}'), 404
    try:
        p = subprocess.run([sys.executable, str(SUMMARY), '--evaluation-dir', str(EVAL)], capture_output=True, text=True, timeout=20, cwd=str(ROOT))
        if p.returncode:
            return jsonify(ok=False, error=(p.stderr or p.stdout)[-1500:]), 500
        lines = p.stdout.splitlines()
        metrics = {}
        for line in lines:
            if ':' in line:
                key, val = line.split(':', 1)
                metrics[key.strip()] = val.strip()
        return jsonify(ok=True, metrics=metrics, raw=p.stdout)
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500

@app.get('/api/evaluation/detail')
def evaluation_detail():
    return jsonify(build_detail(EVAL))

@app.get('/api/live')
def live():
    if not LIVE.is_file():
        return jsonify(ok=True, online=False, reason='Chưa có live_state.json; cần tích hợp script giám sát.')
    try:
        state = json.loads(LIVE.read_text(encoding='utf-8'))
        ts = state.get('timestamp')
        age = None
        if ts:
            t = datetime.fromisoformat(ts.replace('Z', '+00:00'))
            if t.tzinfo is not None:
                age = (datetime.now(timezone.utc) - t).total_seconds()
        # If timestamp is absent, never claim live data.
        online = age is not None and -5 <= age <= 300
        return jsonify(ok=True, online=online, age_seconds=age, state=state)
    except Exception as exc:
        return jsonify(ok=False, online=False, error=str(exc)), 500

def read_firewall_events(limit=None):
    if not FIREWALL_DB.is_file():
        return []
    uri = f'file:{FIREWALL_DB}?mode=ro'
    with sqlite3.connect(uri, uri=True, timeout=5) as conn:
        conn.row_factory = sqlite3.Row
        query = 'SELECT id,timestamp,device_ip,device_mac,action,state,detail FROM firewall_events ORDER BY id DESC'
        if limit is not None:
            return [dict(r) for r in conn.execute(query + ' LIMIT ?', (limit,))]
        return [dict(r) for r in conn.execute(query)]

def query_firewall_events(filters, limit=None):
    """Read-only, parameterized search; no changes to firewall event records."""
    if not FIREWALL_DB.is_file():
        return []
    clauses, values = [], []
    action = (filters.get('action') or '').strip().upper()
    ip = (filters.get('ip') or '').strip()
    start = (filters.get('start') or '').strip()
    end = (filters.get('end') or '').strip()
    if action and action not in ('BLOCK', 'UNBLOCK'):
        raise ValueError('Hành động không hợp lệ.')
    if action:
        clauses.append('action = ?')
        values.append(action)
    if ip:
        if len(ip) > 64:
            raise ValueError('Địa chỉ IP quá dài.')
        clauses.append('device_ip = ?')
        values.append(ip)
    for field, value, operator in [('start', start, '>='), ('end', end, '<=')]:
        if value:
            try:
                datetime.fromisoformat(value.replace('Z', '+00:00'))
            except ValueError as exc:
                raise ValueError(f'Thời gian {field} không hợp lệ.') from exc
            clauses.append(f'timestamp {operator} ?')
            values.append(value)
    sql = 'SELECT id,timestamp,device_ip,device_mac,action,state,detail FROM firewall_events'
    if clauses:
        sql += ' WHERE ' + ' AND '.join(clauses)
    sql += ' ORDER BY id DESC'
    if limit is not None:
        sql += ' LIMIT ?'
        values.append(limit)
    with sqlite3.connect(f'file:{FIREWALL_DB}?mode=ro', uri=True, timeout=5) as conn:
        conn.row_factory = sqlite3.Row
        return [dict(row) for row in conn.execute(sql, values)]

@app.get('/api/firewall-events')
def firewall_events():
    try:
        # Keep this unfiltered feed for live BLOCK/UNBLOCK alerts.
        return jsonify(ok=True, events=read_firewall_events(100))
    except (sqlite3.Error, OSError) as exc:
        return jsonify(ok=False, error=str(exc)), 500

@app.get('/api/firewall-events/search')
def firewall_events_search():
    try:
        rows = query_firewall_events(request.args, limit=500)
        return jsonify(ok=True, events=rows, truncated=len(rows) == 500)
    except ValueError as exc:
        return jsonify(ok=False, error=str(exc)), 400
    except (sqlite3.Error, OSError) as exc:
        return jsonify(ok=False, error=str(exc)), 500

@app.get('/api/firewall-events/export')
def firewall_events_export():
    try:
        rows = query_firewall_events(request.args)
        output = io.StringIO()
        writer = csv.writer(output)
        cols = ['id','timestamp','device_ip','device_mac','action','state','detail']
        writer.writerow(cols)
        for row in reversed(rows):
            writer.writerow([row.get(c, '') for c in cols])
        return Response('\ufeff' + output.getvalue(), mimetype='text/csv; charset=utf-8',
                        headers={'Content-Disposition': 'attachment; filename="firewall_events.csv"'})
    except ValueError as exc:
        return jsonify(ok=False, error=str(exc)), 400
    except (sqlite3.Error, OSError) as exc:
        return jsonify(ok=False, error=str(exc)), 500

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=False)
