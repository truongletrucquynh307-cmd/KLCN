import csv
import math
import re
from collections import defaultdict
from pathlib import Path

FILES = ('run_summary.csv','traffic_windows.csv','latency_results.csv','resource_usage.csv','recovery_events.csv')
ID_KEYS = ('run_id','runid','run','session_id','trial_id')

def read_csv(path):
    if not path.is_file():
        return [], [], f'Thiếu {path.name}'
    try:
        with path.open(encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames or []
            return [{k:(v or '').strip() for k,v in row.items() if k is not None} for row in reader], headers, None
    except (OSError, UnicodeError, csv.Error) as exc:
        return [], [], f'Không đọc được {path.name}: {exc}'

def normalize(s):
    return re.sub(r'[^a-z0-9]+','_',str(s).lower()).strip('_')

def id_column(headers):
    mapping = {normalize(h):h for h in headers}
    return next((mapping[k] for k in ID_KEYS if k in mapping), None)

def number(value):
    try:
        x = float(str(value).strip())
        return x if math.isfinite(x) else None
    except (ValueError, TypeError):
        return None

def find_col(headers, aliases):
    mapping = {normalize(h):h for h in headers}
    return next((mapping[a] for a in aliases if a in mapping), None)

def build_detail(directory):
    directory=Path(directory)
    sources={}
    warnings=[]
    for filename in FILES:
        rows,headers,error=read_csv(directory/filename)
        sources[filename]={'rows':rows,'headers':headers,'id_col':id_column(headers),'count':len(rows)}
        if error: warnings.append(error)
    base=sources['run_summary.csv']
    runs={}
    if base['id_col']:
        for row in base['rows']:
            rid=row.get(base['id_col'],'')
            if rid:
                runs[rid]={'run_id':rid,'summary':row,'sources':{'run_summary.csv':1},'stats':{}}
    else:
        warnings.append('run_summary.csv không có cột run_id: chưa thể tạo bảng theo từng phiên từ file tổng hợp.')
    definitions={
        'traffic_windows.csv':[('real_Bps_mean',('real_bps','real_bytes_per_second','bps_real','bytes_per_second')),('z_max',('z_score','z','zscore'))],
        'latency_results.csv':[],  # Long format: metric + seconds; handled below
        'resource_usage.csv':[('cpu_mean_percent',('cpu_percent_one_core','cpu_percent','cpu_percent_of_one_core','cpu_pct')),('rss_mean_mib',('rss_mib','rss_mb','rss_kb','rss'))],
    }
    for filename,fields in definitions.items():
        src=sources[filename]
        if not src['id_col']:
            if src['rows']: warnings.append(f'{filename} không có run_id; không thể ghép thống kê theo phiên.')
            continue
        groups=defaultdict(list)
        for row in src['rows']:
            rid=row.get(src['id_col'],'')
            if rid: groups[rid].append(row)
        for rid,group in groups.items():
            if rid not in runs:
                runs[rid]={'run_id':rid,'summary':{},'sources':{},'stats':{}}
            runs[rid]['sources'][filename]=len(group)
            for out,aliases in fields:
                col=find_col(src['headers'],aliases)
                if col:
                    vals=[number(row.get(col)) for row in group]
                    vals=[v for v in vals if v is not None]
                    if vals:
                        val = max(vals) if out=='z_max' else sum(vals)/len(vals)
                        if out == 'rss_mean_mib' and normalize(col) == 'rss_kb':
                            val /= 1024
                        runs[rid]['stats'][out] = val
    # Latency is stored as long-form rows: run_id, metric, seconds.
    latency = sources['latency_results.csv']
    metric_col = find_col(latency['headers'], ('metric',))
    seconds_col = find_col(latency['headers'], ('seconds',))
    if metric_col and seconds_col and latency['id_col']:
        lat_groups = defaultdict(lambda: defaultdict(list))
        for row in latency['rows']:
            rid = row.get(latency['id_col'], '')
            metric = normalize(row.get(metric_col, ''))
            val = number(row.get(seconds_col))
            if rid and val is not None:
                lat_groups[rid][metric].append(val)
        for rid, metrics in lat_groups.items():
            runs.setdefault(rid, {'run_id': rid, 'summary': {}, 'sources': {}, 'stats': {}})
            for metric, out in (
                ('detection_to_block', 'detection_to_block_mean_s'),
                ('injection_to_block', 'injection_to_block_mean_s'),
                ('injection_to_detection', 'injection_to_detection_mean_s'),
                ('block_to_unblock', 'block_to_unblock_mean_s'),
            ):
                values = metrics.get(metric, [])
                if values:
                    runs[rid]['stats'][out] = sum(values) / len(values)
    elif latency['rows']:
        warnings.append('latency_results.csv: thiếu cột metric hoặc seconds.')
    # Count recovery events without interpreting PASS/FAIL semantics from unknown schema.
    recovery=sources['recovery_events.csv']
    if recovery['id_col']:
        for row in recovery['rows']:
            rid=row.get(recovery['id_col'],'')
            if rid:
                runs.setdefault(rid,{'run_id':rid,'summary':{},'sources':{},'stats':{}})
                runs[rid]['sources']['recovery_events.csv']=runs[rid]['sources'].get('recovery_events.csv',0)+1
    # Avoid claiming that an unclassified 14th run is definitely a forced-fail trial.
    result=[]
    for rid,item in runs.items():
        summary=item['summary']
        result.append({**item,'summary_display':[{ 'key':k,'value':v } for k,v in summary.items() if normalize(k) not in ID_KEYS]})
    result.sort(key=lambda x:x['run_id'])
    return {'ok':True,'runs':result,'columns':{name:{'count':s['count'],'headers':s['headers'],'has_run_id':bool(s['id_col'])} for name,s in sources.items()},'warnings':warnings,'run_count':len(result)}
