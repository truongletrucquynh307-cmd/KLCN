#!/usr/bin/env python3
"""Thu BASELINE/NORMAL TEST dung phep do cua Gateway L520E.
Scapy AsyncSniffer(iface=ap0, filter='ip and host <ip>'); dem len(packet)
cho IPv4 hai chieu; chia delta bytes cho delta thoi gian monotonic.
Khong Injection, khong iptables, khong thay doi CSV Evaluation/Tab 2.
"""
import argparse
import csv
import math
import statistics
import threading
import time
from datetime import datetime
from pathlib import Path

from scapy.all import AsyncSniffer, IP

DEFAULT_DIR = Path('/home/ubuntu/iot_gateway_demo/baseline_scapy')
THRESHOLDS = (2.0, 2.5, 3.0, 3.5, 4.0)
COLUMNS = ('timestamp', 'sample', 'elapsed_s', 'window_elapsed_s', 'bytes', 'real_Bps', 'z', 'normal_label')


def get_baseline(file):
    with file.open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    if not rows or 'real_Bps' not in rows[0]:
        raise SystemExit(f'Baseline khong hop le: {file}')
    try:
        xs = [float(r['real_Bps']) for r in rows]
    except (ValueError, TypeError) as exc:
        raise SystemExit(f'Loi doc baseline: {exc}')
    if len(xs) < 2 or not all(math.isfinite(x) and x >= 0 for x in xs):
        raise SystemExit('Baseline can >= 2 gia tri B/s hop le.')
    mu = statistics.mean(xs)
    sigma = statistics.pstdev(xs)
    if sigma <= 0:
        raise SystemExit('Do lech chuan bang 0; khong the tinh Z-Score.')
    return len(xs), mu, sigma


def main():
    p = argparse.ArgumentParser(description='Thu Baseline va NORMAL TEST 5s bang Scapy, giong Gateway')
    p.add_argument('--mode', choices=('baseline', 'test'), required=True)
    p.add_argument('--iface', default='ap0')
    p.add_argument('--bulb-ip', default='10.42.0.21')
    p.add_argument('--window', type=float, default=5.0)
    p.add_argument('--duration', type=float, default=None)
    p.add_argument('--output-dir', type=Path, default=DEFAULT_DIR)
    args = p.parse_args()
    if args.window <= 0:
        p.error('--window phai > 0')
    if args.duration is None:
        args.duration = 1800.0 if args.mode == 'baseline' else 900.0
    if args.duration < args.window:
        p.error('--duration phai >= --window')

    args.output_dir.mkdir(parents=True, exist_ok=True)
    baseline_file = args.output_dir / 'l520_normal_baseline_scapy.csv'
    test_file = args.output_dir / 'l520_normal_test_scapy.csv'
    if args.mode == 'test':
        n_baseline, mu, sigma = get_baseline(baseline_file)
        print(f'BASELINE da doc: {n_baseline} cua so, mu={mu:.6f} B/s; sigma={sigma:.6f} B/s', flush=True)
        out_file = test_file
    else:
        mu, sigma = None, None
        out_file = baseline_file

    if out_file.exists():
        raise SystemExit(f'Tep da ton tai, KHONG ghi de: {out_file}\nHay sao luu/doi ten tep cu truoc khi thu lai.')

    byte_count = 0
    lock = threading.Lock()

    def on_packet(packet):
        nonlocal byte_count
        if IP in packet and (packet[IP].src == args.bulb_ip or packet[IP].dst == args.bulb_ip):
            with lock:
                byte_count += len(packet)

    sniffer = AsyncSniffer(iface=args.iface,
                          filter=f'ip and host {args.bulb_ip}',
                          prn=on_packet, store=False)
    print(f'{args.mode.upper()} | Scapy {args.iface} | bulb {args.bulb_ip} | window={args.window:g}s | duration={args.duration:g}s', flush=True)
    print(f'Output: {out_file}', flush=True)
    start = None
    samples = []
    try:
        # Cau hinh Scapy giong Gateway: bat sniffer truoc khi khoi dong bo dem.
        sniffer.start()
        start = time.monotonic()
        last_tick = start
        last_bytes = 0
        target_windows = int(args.duration // args.window)
        with out_file.open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=COLUMNS)
            writer.writeheader()
            i = 0
            while i < target_windows:
                time.sleep(args.window)
                now = time.monotonic()
                with lock:
                    current_bytes = byte_count
                delta_bytes = current_bytes - last_bytes
                delta_t = max(now - last_tick, 0.001)
                real = delta_bytes / delta_t
                last_bytes, last_tick = current_bytes, now
                i += 1
                z = '' if mu is None else (real - mu) / sigma
                writer.writerow({'timestamp': datetime.now().isoformat(timespec='milliseconds'),
                                 'sample': i, 'elapsed_s': f'{now-start:.6f}',
                                 'window_elapsed_s': f'{delta_t:.6f}', 'bytes': delta_bytes,
                                 'real_Bps': f'{real:.6f}', 'z': '' if z == '' else f'{z:.6f}',
                                 'normal_label': 'NORMAL'})
                f.flush()
                samples.append((real, z))
                print(f'[{i:04d}] {delta_bytes:7d} bytes / {delta_t:.3f}s = {real:9.2f} B/s' +
                      ('' if z == '' else f' | Z={z:7.3f}'), flush=True)
    except KeyboardInterrupt:
        print('\nDA NGAT GIUA CHUNG. Khong su dung tep dang do lam ket qua chinh thuc.', flush=True)
        raise SystemExit(130)
    except Exception:
        # Anh huong den du lieu: bao loi thay vi im lang bo qua.
        raise
    finally:
        if sniffer.running:
            sniffer.stop()

    print('\n=== KET QUA ' + args.mode.upper() + ' ===')
    print(f'So cua so hop le: {len(samples)}')
    print(f'Tep: {out_file}')
    if args.mode == 'baseline' and len(samples) >= 2:
        xs = [x for x, _ in samples]
        print(f'mu = {statistics.mean(xs):.6f} B/s')
        print(f'sigma = {statistics.pstdev(xs):.6f} B/s (population)')
    if args.mode == 'test' and samples:
        print(f'{"Nguong":>8} {"FP":>7} {"N":>7} {"FPR(%)":>10}')
        for threshold in THRESHOLDS:
            fp = sum(z > threshold for _, z in samples)
            print(f'{threshold:8g} {fp:7d} {len(samples):7d} {100*fp/len(samples):10.2f}')


if __name__ == '__main__':
    main()
